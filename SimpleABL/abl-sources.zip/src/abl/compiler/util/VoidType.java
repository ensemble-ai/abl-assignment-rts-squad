package abl.compiler.util;

/**
 * To provide functors a way to return nothing, specifically.
 * 
 */
public class VoidType {

   public static final VoidType VOID = new VoidType();

   /**
    * Singleton.
    */
   private VoidType() {
   }

}
