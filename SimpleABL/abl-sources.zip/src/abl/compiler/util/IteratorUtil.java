package abl.compiler.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class IteratorUtil {

   /**
    * Turn an iterator into an {@link ArrayList}.
    * 
    * @return a fresh {@link ArrayList}, with elements in the order they are
    *         returned by <code>ts</code>
    */
   public static <T> List<T> list(Iterator<T> ts) {
      List<T> ret = new ArrayList<>();
      while (ts.hasNext()) {
         ret.add(ts.next());
      }

      return ret;
   }

}
