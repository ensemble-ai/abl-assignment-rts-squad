package abl.compiler.astchecks;

import abl.compiler.AblParseNode;
import abl.compiler.CompileException;
import abl.compiler.Node;

/**
 * A visitor which returns its input in every case.
 * 
 */
public class IdentityASTVisitor {

   public Node visit(AblParseNode a)
         throws CompileException {
      return a;
   }
}
