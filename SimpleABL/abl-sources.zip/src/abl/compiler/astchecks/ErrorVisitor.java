package abl.compiler.astchecks;

import abl.compiler.ASTAblExpression;
import abl.compiler.ASTAblVariableDecl;
import abl.compiler.ASTActionRegistration;
import abl.compiler.ASTAnonymousStep;
import abl.compiler.ASTBehaviorDefinition;
import abl.compiler.ASTBehaviorUnit;
import abl.compiler.ASTConditionalExpression;
import abl.compiler.ASTConstantDeclaration;
import abl.compiler.ASTFailStep;
import abl.compiler.ASTGoalStep;
import abl.compiler.ASTImportDeclaration;
import abl.compiler.ASTJavaName;
import abl.compiler.ASTJavaStatement;
import abl.compiler.ASTJavaType;
import abl.compiler.ASTMentalActAssert;
import abl.compiler.ASTMentalStep;
import abl.compiler.ASTModifyStep;
import abl.compiler.ASTPrimitiveStep;
import abl.compiler.ASTPropertyDeclaration;
import abl.compiler.ASTRule;
import abl.compiler.ASTSucceedStep;
import abl.compiler.ASTTestExpression;
import abl.compiler.ASTVariableDeclaratorID;
import abl.compiler.ASTVariableInitializer;
import abl.compiler.ASTVisitor;
import abl.compiler.ASTWMEAssert;
import abl.compiler.ASTWMEAssertExpression;
import abl.compiler.ASTWMEAssertSequence;
import abl.compiler.ASTWMEDecl;
import abl.compiler.ASTWMEFieldTest;
import abl.compiler.ASTWMERegistration;
import abl.compiler.ASTWMETest;
import abl.compiler.ASTWaitStep;
import abl.compiler.CompileException;
import abl.compiler.Node;

/**
 * A visitor which errors in every case. This is useful for implementing subtree
 * visitors, where you only expect certain types of nodes, and want immediate
 * errors if other types of nodes show up.
 */
public class ErrorVisitor
      implements ASTVisitor {

   @Override
   public Node visit(ASTBehaviorUnit a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTAblExpression a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTAblVariableDecl a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTActionRegistration a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTAnonymousStep a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTBehaviorDefinition a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTConditionalExpression a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTConstantDeclaration a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTFailStep a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTGoalStep a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTImportDeclaration a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTJavaName a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTJavaStatement a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTJavaType a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTMentalStep a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTModifyStep a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTPrimitiveStep a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTPropertyDeclaration a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTRule a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTSucceedStep a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTTestExpression a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTVariableDeclaratorID a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTVariableInitializer a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTWaitStep a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTWMEDecl a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTWMEFieldTest a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTWMERegistration a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTWMETest a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   /* Immerse visitors */
   @Override
   public Node visit(ASTMentalActAssert a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTWMEAssert a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTWMEAssertExpression a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }

   @Override
   public Node visit(ASTWMEAssertSequence a)
         throws CompileException {
      throw new UnsupportedOperationException();
   }
}
