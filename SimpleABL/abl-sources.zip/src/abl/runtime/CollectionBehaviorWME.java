// WME wrapper for CollectionBehavior

package abl.runtime;

public class CollectionBehaviorWME
      extends MultiStepBehaviorWME {
   public CollectionBehaviorWME(CollectionBehavior b, GoalStepWME parent) {
      super(b, parent);
   }
}
