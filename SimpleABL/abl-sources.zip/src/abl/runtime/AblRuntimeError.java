package abl.runtime;

import java.io.PrintWriter;
import java.io.StringWriter;

public class AblRuntimeError
      extends Error {
   public AblRuntimeError() {
      super();
      // fixme: comment back in?
      // breakCharactersNextDecisionCycle();
   }

   public AblRuntimeError(String s) {
      super(s);
      // fixme: comment back in?
      // breakCharactersNextDecisionCycle();
   }

   public AblRuntimeError(String s, Throwable t) {
      super(fullErrorString(s, t));
      // fixme: comment back in?
      // breakCharactersNextDecisionCycle();
   }

   public AblRuntimeError(Throwable t) {
      super(fullErrorString("", t));
      // fixme: comment back in?
      // breakCharactersNextDecisionCycle();
   }

   // fixme: Consolidate with idential code in CompileError
   private static String fullErrorString(String s, Throwable t) {
      StringWriter tempWriter = new StringWriter();
      PrintWriter stackTrace = new PrintWriter(tempWriter);
      t.printStackTrace(stackTrace);
      return s + t.getMessage() + tempWriter;
   }
}
