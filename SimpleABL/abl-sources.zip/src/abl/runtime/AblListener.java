// AblListener is a notification interface for abl events.
package abl.runtime;

import java.util.EventListener;

public interface AblListener
      extends EventListener {
   public void eventHappened(AblEvent e);
}
