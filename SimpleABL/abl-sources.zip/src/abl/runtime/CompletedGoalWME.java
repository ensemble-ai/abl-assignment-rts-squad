// WME for abl subgoal steps
// fixme: change this into EpisodicGoalWME when temporal intervals are supported

package abl.runtime;

public class CompletedGoalWME
      extends CompletedExecutableStepWME {

   public CompletedGoalWME(String signature, int completionStatus, String behaviorSignature, String agent, long timestamp) {
      super(signature, completionStatus, behaviorSignature, agent, timestamp);
   }

   public CompletedGoalWME(String signature, int completionStatus, String behaviorSignature, String agent) {
      super(signature, completionStatus, behaviorSignature, agent);
   }
}
