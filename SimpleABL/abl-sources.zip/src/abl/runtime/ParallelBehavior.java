// Parallel behaviors
package abl.runtime;

import java.lang.reflect.Method;

public class ParallelBehavior
      extends MultiStepBehavior {

   // Initialize behaviorType as a static variable shared by all parallel
   // behaviors.
   protected static short behaviorType = Behavior.PARALLEL;

   public ParallelBehavior(GoalStep arg_parent, Rulegroup arg_descriptionRulegroup, Method arg_contextCondition, Method arg_contextConditionSensorFactory,
                           Method arg_successCondition, Method arg_successConditionSensorFactory, boolean arg_isAtomic,
                           String arg_signature, short arg_specificity, int arg_behaviorID, Object[] arg_behaviorVariableFrame,
                           __StepDesc[] arg_stepDescs, int arg_numberNeededForSuccess) {
      super(arg_parent,
            arg_descriptionRulegroup,
            arg_contextCondition,
            arg_contextConditionSensorFactory,
            arg_successCondition,
            arg_successConditionSensorFactory,
            arg_isAtomic,
            arg_signature,
            arg_specificity,
            arg_behaviorID,
            arg_behaviorVariableFrame,
            arg_stepDescs,
            arg_numberNeededForSuccess);
   }

   public ParallelBehavior(GoalStep arg_parent, Rulegroup arg_descriptionRulegroup, Method arg_contextCondition, Method arg_contextConditionSensorFactory,
                           Method arg_successCondition, Method arg_successConditionSensorFactory, boolean arg_isAtomic,
                           String arg_signature, short arg_specificity, int arg_behaviorID, Object[] arg_behaviorVariableFrame,
                           __StepDesc[] arg_stepDescs, int arg_numberNeededForSuccess, BehavingEntity[] arg_teamMembers) {
      super(arg_parent,
            arg_descriptionRulegroup,
            arg_contextCondition,
            arg_contextConditionSensorFactory,
            arg_successCondition,
            arg_successConditionSensorFactory,
            arg_isAtomic,
            arg_signature,
            arg_specificity,
            arg_behaviorID,
            arg_behaviorVariableFrame,
            arg_stepDescs,
            arg_numberNeededForSuccess,
            arg_teamMembers);
   }

   // Public accessor for behaviorType.
   @Override
   final short getBehaviorType() {
      return behaviorType;
   }
}
