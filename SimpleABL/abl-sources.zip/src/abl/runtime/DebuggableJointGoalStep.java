package abl.runtime;

interface DebuggableJointGoalStep
      extends DebuggableStep {
   void traceAblNegotiationEvent(int type, JointGoalNegotiatorDebug.JointGoalNegotiationInfo info);
}
