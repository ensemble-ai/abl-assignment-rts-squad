package abl.runtime;

import java.io.Serializable;

public class __ValueTypes {
   static public class IntVar implements Serializable {
      public int i;

      public IntVar(int i) {
         this.i = i;
      }

      public IntVar(Integer iObj) {
         i = iObj;
      }

      public IntVar() {
      }

      @Override
      public String toString() {
         return Integer.toString(i);
      }
   }

   static public class LongVar implements Serializable {
      public long l;

      public LongVar(long l) {
         this.l = l;
      }

      public LongVar(Long lObj) {
         l = lObj;
      }

      public LongVar() {
      }

      @Override
      public String toString() {
         return Long.toString(l);
      }
   }

   static public class ShortVar implements Serializable {
      public short s;

      public ShortVar(short s) {
         this.s = s;
      }

      public ShortVar(Short sObj) {
         s = sObj;
      }

      public ShortVar() {
      }

      @Override
      public String toString() {
         return Short.toString(s);
      }
   }

   static public class ByteVar implements Serializable {
      public byte b;

      public ByteVar(byte b) {
         this.b = b;
      }

      public ByteVar(Byte bObj) {
         b = bObj;
      }

      public ByteVar() {
      }

      @Override
      public String toString() {
         return Byte.toString(b);
      }
   }

   static public class FloatVar implements Serializable {
      public float f;

      public FloatVar(float f) {
         this.f = f;
      }

      public FloatVar(Float fObj) {
         f = fObj;
      }

      public FloatVar() {
      }

      @Override
      public String toString() {
         return Float.toString(f);
      }
   }

   static public class DoubleVar implements Serializable {
      public double d;

      public DoubleVar(double d) {
         this.d = d;
      }

      public DoubleVar(Double dObj) {
         d = dObj;
      }

      public DoubleVar() {
      }

      @Override
      public String toString() {
         return Double.toString(d);
      }
   }

   static public class BooleanVar implements Serializable {
      public boolean b;

      public BooleanVar(boolean b) {
         this.b = b;
      }

      public BooleanVar(Boolean bObj) {
         b = bObj;
      }

      public BooleanVar() {
      }

      @Override
      public String toString() {
         return Boolean.toString(b);
      }
   }

   static public class CharVar implements Serializable {
      public char c;

      public CharVar(char c) {
         this.c = c;
      }

      public CharVar(Character cObj) {
         c = cObj;
      }

      public CharVar() {
      }

      @Override
      public String toString() {
         return Character.toString(c);
      }
   }

   static public class ObjectVar implements Serializable {
      public Serializable o;

      public ObjectVar(Serializable arg_o) {
         o = arg_o;
      }

      public ObjectVar() {
      }

      @Override
      public String toString() {
         return o.toString();
      }
   }
}
