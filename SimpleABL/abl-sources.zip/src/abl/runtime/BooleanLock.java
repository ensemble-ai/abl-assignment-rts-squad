package abl.runtime;

import java.io.Serializable;

class BooleanLock implements Serializable {
   boolean state;

   BooleanLock(boolean initialState) {
      state = initialState;
   }

   boolean isEnabled() {
      return state;
   }

   synchronized void setEnabled(boolean newState) {
      state = newState;
      notifyAll();
   }

}
