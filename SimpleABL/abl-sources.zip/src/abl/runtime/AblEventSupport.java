// Provides support for registering AblListeners and firing AblEvents
package abl.runtime;

import java.util.ArrayList;
import java.util.List;

class AblEventSupport {
   private List<AblListener> listeners = new ArrayList<>();

   private Object source;

   AblEventSupport() {
      source = null;
   }

   // source - the Object to be given as the source of this abl event
   AblEventSupport(Object source) {
      this.source = source;
   }

   void addAblListener(AblListener listener) {
      listeners.add(listener);
   }

   void removeAblListener(AblListener listener) {
      listeners.remove(listener);
   }

   void setSource(Object source) {
      this.source = source;
   }

   void fireAblEvent(int type, Object obj) {
      AblEvent e = new AblEvent(source, type, obj);
      for (Object listener : listeners) {
         ((AblListener) listener).eventHappened(e);
      }
   }

   void fireAblEvent(int type, Object obj, int nestLevel) {
      AblEvent e = new AblEvent(source, type, obj, nestLevel);
      for (Object listener : listeners) {
         ((AblListener) listener).eventHappened(e);
      }
   }

   void fireAblEvent(int type, Object src, Object obj, int nestLevel) {
      AblEvent e = new AblEvent(src, type, obj, nestLevel);
      for (Object listener : listeners) {
         ((AblListener) listener).eventHappened(e);
      }
   }
}
