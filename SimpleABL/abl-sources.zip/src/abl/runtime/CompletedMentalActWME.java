// WME for abl mental acts
// fixme: change this into EpisodicMentalActWME when temporal intervals are supported

package abl.runtime;

public class CompletedMentalActWME
      extends CompletedStepWME {

   public CompletedMentalActWME(String behaviorSignature, String agent, long timestamp) {
      super(behaviorSignature, agent, timestamp);
   }

   public CompletedMentalActWME(String behaviorSignature, String agent) {
      super(behaviorSignature, agent);
   }
}
