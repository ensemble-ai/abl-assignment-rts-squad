/**
 * Copyright 2014 UCSC
 */
package abl.runtime;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import wm.WME;

/**
 * The Rulegroup collects rules by the Rule data structure. It can be used as a
 * List or a Set.
 * 
 * List ops: (e.g. add, remove) allow redundant entries and order specification
 * 
 * Set ops: (e.g. union, intersection) will output a valid set, with all
 * redundant entries removed
 */
public class Rulegroup
      extends WME
      implements Iterable<Integer> {

   private String name;

   /**
    * Uses a list to enforce order until we have a means of keeping a sorted set
    */
   private List<Integer> ruleIDs = new ArrayList<>();

   public Rulegroup(String nameToSet, Rule... rulesToAdd) {
      name = nameToSet;
      addRules(Arrays.asList(rulesToAdd));
   }
   
   public Rulegroup(String nameToSet, Integer... ruleIDsToAdd) {
      name = nameToSet;
      ruleIDs.addAll(Arrays.asList(ruleIDsToAdd));
   }

   public Rulegroup(String nameToSet, List<Integer> ruleIDsToAdd) {
      name = nameToSet;
      ruleIDs.addAll(ruleIDsToAdd);
   }
   
   /**
    * @param ruleID Rule ID to add.
    */
   public synchronized void add(int ruleID) {
      ruleIDs.add(ruleID);
   }

   /**
    * @param rule Rule to add.
    */
   public synchronized void add(Rule rule) {
      add(rule.getId());
   }

   /**
    * @param index Index for addition.
    * @param rule Rule to add
    */
   public synchronized void add(int index, Rule rule) {
      ruleIDs.add(index, rule.getId());
   }
   
   private void addRules(Collection<Rule> rulesToAdd) {
      rulesToAdd.stream().map(rule -> rule.getId()).forEach(ruleID -> ruleIDs.add(ruleID));
   }

   /**
    * @param rulesToAdd Collection of Rules to add
    */
   public synchronized void addAll(Collection<Rule> rulesToAdd) {
      addRules(rulesToAdd);
   }

   /**
    * @param rule The rule to remove, if present. Removes all instances that share the rule's ID
    */
   public synchronized void remove(Rule rule) {
      while (ruleIDs.contains(rule.getId())) {
         /* Must cast to Integer object to get remove based on object equality vs. index position */
         ruleIDs.remove((Integer) rule.getId());
      }
   }

   /**
    * @param index The rule index to remove
    */
   public synchronized void removeIndex(int index) {
      ruleIDs.remove(index);
   }

   /**
    * Clear the entries in the group
    */
   public synchronized void clear() {
      ruleIDs.clear();
   }

   /**
    * @param index The index to get
    * @return The rule at the index
    */
   public synchronized int getIndex(int index) {
      return ruleIDs.get(index);
   }

   /**
    * @param ruleID the ruleID to check for
    * @return does group contain ID?
    */
   public synchronized boolean contains(int ruleID) {
      return ruleIDs.contains(ruleID);
   }
   
   /**
    * @param r rule to check for
    * @return does group contain rule r
    */
   public synchronized boolean contains(Rule rule) {
      return contains(rule.getId());
   }

   public synchronized String getName() {
      return name;
   }

   public synchronized void setName(String name) {
      this.name = name;
   }
   
   public synchronized int getSize() {
      return ruleIDs.size();
   }

   /*
    * ----- set operators - will always result in a valid set ------
    */
   /**
    * Destructively unions the other rulegroup into this one
    * 
    * @param otherRss A rule group.
    */
   public synchronized void union(Rulegroup otherRg) {
      for (int ruleID : otherRg) {
         if (!contains(ruleID)) {
            add(ruleID);
         }
      }
      // Enforce rule uniqueness
      pruneDuplicates();
   }

   /**
    * Returns a new Rulegroup that contains all Rules from a and b with no
    * duplicates.
    * 
    * @param a First group.
    * @param b Second group.
    * @return New Rulegroup set with the union of a and b.
    */
   public synchronized static Rulegroup union(Rulegroup a, Rulegroup b) {
      /* Start with set a's rules, and then destructively union in set b's */
      Rulegroup ab = new Rulegroup("Union_" + a.getName() + "_" + b.getName(), a.ruleIDs);
      ab.union(b);
      return ab;
   }

   /**
    * Destructively removes all rules that are not also in the Rulegroup
    * parameter.
    * 
    * @param otherRs A rule group.
    */
   public synchronized void intersection(Rulegroup otherRg) {
      Iterator<Integer> it = iterator();

      while (it.hasNext()) {
         int ruleInThisSet = it.next();
         if (!otherRg.contains(ruleInThisSet)) {
            it.remove();
         }
      }
      // Enforce rule uniqueness
      pruneDuplicates();
   }

   /**
    * Returns a new Rulegroup set that contains the intersection of a and b
    * 
    * @param a First set.
    * @param b Second set.
    * @return New Rulegroup set with the intersection of a and b.
    */
   public synchronized static Rulegroup intersection(Rulegroup a, Rulegroup b) {
      /* Start with set a's rules, and then destructively intersect in set b's */
      Rulegroup ab = new Rulegroup("Intersection_" + a.getName() + "_" + b.getName(), a.ruleIDs);
      ab.intersection(b);
      return ab;
   }

   /**
    * Helper method which removes any duplicate entries
    */
   private synchronized void pruneDuplicates() {
      List<Integer> uniqueRuleList = new ArrayList<>();
      for (int ruleId : ruleIDs) {
         if (!uniqueRuleList.contains(ruleId)) {
            uniqueRuleList.add(ruleId);
         }
      }
      ruleIDs = uniqueRuleList;
   }

   /**
    * @return the rules
    */
   @Override
   public synchronized Iterator<Integer> iterator() {
      return ruleIDs.iterator();
   }

   @Override
   public String toString() {
      String out = new String();
      out += this.name + " { ";
      for (int ruleID : ruleIDs) {
         out += ruleID + " ";
      }
      out += "}";
      return out;
   }

}
