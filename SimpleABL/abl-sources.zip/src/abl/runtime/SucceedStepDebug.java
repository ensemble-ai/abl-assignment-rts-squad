// Class for debug succeed steps. 

package abl.runtime;

import java.lang.reflect.Method;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;

public class SucceedStepDebug
      extends SucceedStep
      implements DebuggableStep {

   // Constructor for SucceedStep calls the super constructor.
   // It is not legal to associate persistence properties, ignore failure, or
   // success tests with a succeed step.
   public SucceedStepDebug(int stepID, Method arg_stepFactory, Behavior arg_parent, boolean arg_effectOnly, boolean arg_teamEffectOnly, short arg_priority,
                           short arg_priorityModifier, boolean arg_post, String arg_postMemory,
                           AblNamedPropertySupport arg_propertyTable) {
      super(stepID,
            arg_stepFactory,
            arg_parent,
            arg_effectOnly,
            arg_teamEffectOnly,
            arg_priority,
            arg_priorityModifier,
            arg_post,
            arg_postMemory,
            arg_propertyTable);
   }

   // fixme: add trace support for suspend.

   @Override
   final void execute() {
      ((DebuggableBehavior) parent).traceAblExecutionEvent(AblEvent.SUCCEEDSTEP_EXECUTION, this, null, getNestLevel());
      super.execute();
   }

   @Override
   final void succeedStep() {
      ((DebuggableBehavior) parent).traceAblExecutionEvent(AblEvent.SUCCEEDSTEP_COMPLETION, this, true, getNestLevel());
      super.succeedStep();
   }

   @Override
   final void failStep() {
      ((DebuggableBehavior) parent).traceAblExecutionEvent(AblEvent.SUCCEEDSTEP_COMPLETION, this, false,
                                                           getNestLevel());
      super.failStep();
   }

   @Override
   final boolean successTest() {
      final boolean ret = super.successTest();
      if (ret) {
         ((DebuggableBehavior) parent).traceAblExecutionEvent(AblEvent.SUCCESS_TEST_SUCCESS, this, null, getNestLevel());
      }

      return ret;
   }

   // Returns a tree node which wraps the subtree rooted at this node in the
   // ABT.
   @Override
   public final MutableTreeNode getTree() {
      return new DefaultMutableTreeNode(this);
   }

   // fixme: change this from a recursive call to an accessor for the nest level
   // (see Behavior).
   // to do this, will need to reset the nest level when a goal spawns.
   @Override
   public final int getNestLevel() {
      return ((DebuggableBehavior) parent).getNestLevel() + 1;
   }

}
