package abl.runtime;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.logging.Logger;

import javax.swing.tree.DefaultTreeModel;

import debug.ABTViewer;
import debug.DependencyTree;
import wm.TrackedWorkingMemory;
import wm.WME;
import wm.WorkingMemory;
import wm.WorkingMemoryDebugger;
import wm.WorkingMemorySet;
import abl.compiler.AblDebuggerConstants;
import abl.runtime.statistics.DynamicStatisticsSnapshot;
import abl.runtime.statistics.StatisticsCollector;

// fixme: remove. For debugging purposes only.
// import facade.nativeinterface.NativeAnimationInterface;

/** All behaving entities are subclasses of BehavingEntity. */
public abstract class BehavingEntity
      implements AblDebuggerConstants, Serializable {

   /**
    * Listen for changes in the pause state by adding a PropertyChangeListener
    * on this property
    */
   public static final String PAUSED_PROPERTY = "paused";

   private static final int SLEEP_DURATION_BETWEEN_PAUSE_CHECKS = 17;

   private static final Logger logger = Logger.getLogger(BehavingEntity.class.getName());

   /**
    * Use this as an argument to {@link #startBehaving()} if you want the
    * agent's behavior thread and asynchronous sensor thread to run as fast as
    * possible, without ever yielding unless no execution step is selected.
    */
   public static final int UNYIELDING = -1;

   /**
    * If the user doesn't specify whether to bring up the developer behavior
    * selection GUI, what is the default behavior? (This should probably be
    * false; true for now because that's how it was originally coded and I don't
    * know if anyone cares. TODO review.)
    */
   private static final boolean SHOW_BEHAVIOR_LAUNCHER_GUI_DEFAULT = false;

   /** Constants for use in findConflictsWithCurrentlyExecutingSteps() */
   // fixme: suspendOnInstantiate appears to be unused
   public final static int suspendOnInstantiate = 0;

   public final static int suspendOnExecute = 1;

   private static final Map<String, BehavingEntity> entityTable = new HashMap<>();

   // Behavior specificity comparator used in chooseBehavior().
   private static BehaviorSpecificityComparator behComparator = new BehaviorSpecificityComparator();

   // Step priority comparator used in chooseStep().
   private static StepPriorityComparator stepPriorityComparator = new StepPriorityComparator();

   // Step expansion comparator (current line of expansion) used in
   // chooseStep().
   private static StepExpansionComparator stepExpansionComparator = new StepExpansionComparator();

   // Instance of Object[] used for retrieving the Class instance of Object[].
   static Object[] tempObjArray = new Object[1];

   /*
    * Reference to this behaving entity. Made an InheritableThreadLocal because
    * each behaving entity runs in its own thread; two different behaving
    * entities will each have the correct self reference. Must be inheritable
    * because a single behaving entity has multiple child threads.
    */
   protected final static InheritableThreadLocal<BehavingEntity> entity = new InheritableThreadLocal<>();

   private transient StatisticsCollector stats;

   // Holds WMEs
   protected WorkingMemory workingMemory;

   // Top node of ABT.
   protected CollectionBehavior ABT;

   // Leaf steps that can currently be choosen for execution.
   // protected HashSet leafSteps = new HashSet();
   // fixme: why am I synchronizing the leafSteps collection?
   // recently sychronized all ABT modification and access routines on
   // BehavingEntity (e.g. behave(), resetStep(), etc.)
   // so there is probably no reason to synchronize the set.
   protected Set<Step> leafSteps = Collections.synchronizedSet(new HashSet<Step>());

   // Atomic steps than can currently be choosen for
   // execution. Any leaf step of the ABT is either in the set
   // leafSteps or the set atomicSteps.
   protected Set<Step> atomicSteps = new HashSet<>();

   // Primitive steps that are currently executing.
   protected Set<Step> executingPrimitiveSteps = new HashSet<>();

   // Executing steps with success tests (goals and primitive acts).
   protected Set<Step> successTestStepsNoSensing = new HashSet<>();

   // Behaviors in ABT with context condtions.
   protected Set<Behavior> contextConditionBehaviorsNoSensing = new HashSet<>();

   // Behaviors in ABT with success conditions that don't require sensing.
   final protected Set<Behavior> successConditionBehaviorsNoSensing = new HashSet<>();

   // Executing steps with success tests (goals and primitive acts).
   protected Set<Step> successTestStepsSensing = new HashSet<>();

   // Behaviors in ABT with context condtions.
   protected Set<Behavior> contextConditionBehaviorsSensing = new HashSet<>();

   // Behaviors in ABT with success conditions that do require sensing
   final protected Set<Behavior> successConditionBehaviorsSensing = new HashSet<>();

   // Steps in ABT that are currently executing (goals and primitive acts).
   protected Map<String, Set<Step>> executingSteps = new HashMap<>();

   // The behavior libraries are initialized in the constructor of the concrete
   // BehavingEntity.
   protected BehaviorLibrary individualBehaviorLibrary;

   protected BehaviorLibrary jointBehaviorLibrary;
   
   // fixme: There must be a better way to get the fully qualified name
   protected String packagename;

   protected final String name = this.getBehavingEntityShortName();

   // Random number generator for use in step and behavior selection.
   Random randomGen = new Random();

   // Set to true to turn on the current line of expansion heuristic. Defaults
   // to true. Can be turned off by an ABL command
   // line switch.
   protected boolean bCurrentLineOfExpansion = true;

   // Set to true to turn on step conflict maintainance.
   protected boolean bStepConflicts = true;

   // Emotional state hash table (add later).

   // Set to true to debug the behaving entity.
   protected byte debugLevel;
   // Set to true to activate the behavior dependency tree
   protected boolean depTreeFlag;
   // set to true to active the ABT Viewer
   protected boolean abtViewerFlag;
   
   // If code is compiled with the debug flag, the concrete BehavingEntity
   // class creates a Debugger.
   protected transient Debugger debuggerGUI;

   public transient debug.BehaviorTestBed behaviorTestBedGUI;

   protected boolean bDecisionCycleSMCall; // true if the behaving

   protected boolean asynchronousSenseCycle;

   // entity has a decision
   // cycle callback

   // Map of current entry negotiators - unique id (Integer) is key,
   // negotiator is value
   private final Map<Long, JointGoalStep> currentEntryNegotiators = new HashMap<>();

   // List of active negotiation threads
   private transient List<JointGoalNegotiationThread> activeNegotiationThreads;

   // Reference to the thread running the decision cycle. Used to check that
   // methods are being called by
   // appropriate threads.
   private transient Thread decisionCycleThread;

   private boolean negotiatorCommittedDuringNegotiation;

   private long continuousConditionTime;

   private transient ShutdownHook shutdownHook;

   private CollectionBehaviorWME rootCollectionBehaviorWME;

   private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);

   /**
    * Note: added by Ben Weber
    * 
    * This is set to false when stopBehaving is called.
    */
   private final BooleanLock behaving = new BooleanLock(true);

   private final BooleanLock paused = new BooleanLock(false);

   /**
    * Note: Ben Weber
    * 
    * List of behaving listeners
    */
   private List<BehavingListener> behavingListeners;

   /**
    * The step chosen by the BehavingEntity.
    */

   private Step lastChosenStep;

   SensedConditionMonitor senseMonitor = new SensedConditionMonitor();

   private ActiveContinuousSensors activeSensors;

   private transient ThreadGroup timeCheckThreads;
   private transient DynamicStatisticsSnapshot conflictSetSuspend;
   private transient DynamicStatisticsSnapshot conflictSetTopPrioritySteps;
   private transient DynamicStatisticsSnapshot conflictSetLineOfExpansionSteps;

   private final List<File> persistLock = new ArrayList<>(1);

   // The name of the working memory is the short name of the concrete behaving
   // entity class.

   public BehavingEntity() {
      startThreads();
      String pack;
      behavingListeners = new ArrayList<>();
      String longName = this.getClass().getName();
      // fixme: behaving entity's shouldn't automatically have
      // publically-accessible memories
      workingMemory = new WorkingMemory(longName.substring(longName.lastIndexOf('.') + 1) + "Memory");
      // fixme
      final Package[] packages = Package.getPackages();
      final String className = this.getBehavingEntityShortName();
      pack = null;
      for (final Package p : packages) {
         pack = p.getName();
         final String tentative = pack + "." + className;
         try {
            Class.forName(tentative);
         } catch (final ClassNotFoundException e) {
            continue;
         }

         break;
      }
      this.packagename = pack;
      activeSensors = new ActiveContinuousSensors();
      createStatisticsSnapshots();
      BehavingEntity.registerEntity(name, this);
   }

   /*
    * Invoked on deserialization
    */
   private void readObject(ObjectInputStream in)
         throws ClassNotFoundException, IOException {
      in.defaultReadObject();
      startThreads();
   }

   public void addPropertyChangeListener(PropertyChangeListener listener) {
      this.pcs.addPropertyChangeListener(listener);
   }

   public void removePropertyChangeListener(PropertyChangeListener listener) {
      this.pcs.removePropertyChangeListener(listener);
   }

   private void startThreads() {
      timeCheckThreads = new ThreadGroup("TimeCheckThreads");
      activeNegotiationThreads = Collections.synchronizedList(new LinkedList<JointGoalNegotiationThread>());
   }

   private void createStatisticsSnapshots() {
      stats = new StatisticsCollector();
      conflictSetSuspend = new DynamicStatisticsSnapshot("conflictSetSuspend");
      conflictSetTopPrioritySteps = new DynamicStatisticsSnapshot("conflictSetTopPrioritySteps");
      conflictSetLineOfExpansionSteps = new DynamicStatisticsSnapshot("conflictSetLineOfExpansionSteps");

      stats.addSnapshot(conflictSetSuspend);
      stats.addSnapshot(conflictSetTopPrioritySteps);
      stats.addSnapshot(conflictSetLineOfExpansionSteps);
      stats.addSnapshot("executingPrimitiveSteps", executingPrimitiveSteps);
      stats.addSnapshot("atomicSteps", atomicSteps);
      stats.addSnapshot("successTestStepsSensing", successTestStepsSensing);
      stats.addSnapshot("successTestStepsNoSensing", successTestStepsNoSensing);
      stats.addSnapshot("leafSteps", leafSteps);
      stats.addSnapshot("contextConditionBehaviorsSensing", contextConditionBehaviorsSensing);
      stats.addSnapshot("contextConditionBehaviorsNoSensing", contextConditionBehaviorsNoSensing);
      stats.addSnapshot("successConditionBehaviorsSensing", successConditionBehaviorsSensing);
      stats.addSnapshot("successConditionBehaviorsNoSensing", successConditionBehaviorsNoSensing);
      stats.init();
   }

   // Called when a primitive act is aborted.
   void abortStep(PrimitiveStep s) // { abt.abortStep(s); }
   {
      // Remove any success test associated with the aborting step
      removeSuccessTest(s);

      executingPrimitiveSteps.remove(s);

      // Remove from the table of executing steps.
      removeExecutingStep(s);
   }

   /**
    * Note: Ben Weber
    * 
    * Adds a behaving listener to this behaving entity.
    */
   public void addBehavingListener(BehavingListener listener) {
      behavingListeners.add(listener);
   }
   
   /**
    * Note: April Grow
    * 
    * Initializes current set of listeners based on args passed in to the agent
    */
   private void initializeBehaviorListeners(){
      // Runs Weber's Behavior Tree vis with the agent
      if(abtViewerFlag) {
         addBehavingListener(new ABTViewer()); 
      }
      // Runs April's dependency tree viewer with the agent
      if(depTreeFlag) {
         addBehavingListener(new DependencyTree());
      }
      
      for (BehavingListener listener : behavingListeners) {
         listener.onLoad(individualBehaviorLibrary, jointBehaviorLibrary);
      }
   }

   // Called when a behavior is added to the ABT.
   void addBehavior(Behavior b) {
      if (b.getHasContextCondition()) {
         // If the behavior has a context condition, add it to the set of
         // behaviors with context conditions.
         final SensorActivation[] activations = b.getContextConditionSensorActivations();
         if (activations != null) {
            contextConditionBehaviorsSensing.add(b);
         } else {
            contextConditionBehaviorsNoSensing.add(b);
         }

         /*
          * If there are sensor activations associated with the context
          * condition, add them to the set of active sensors.
          */
         if (activations != null) {
            activeSensors.activateSensors(activations);

            // fixme: remove
            /*
             * for(int i = 0; i < activations.length; i++) if
             * (activations[i].activeSensor
             * .getClass().getName().equals("facade.sensor.GraceAnimationCueSensor"
             * )) System.out.println("Activating sensors for behavior " +
             * b.getClass().getName());
             */
         }
      }
      if (b.getHasSuccessCondition()) {
         // If the behavior has a success condition, add it to the set of
         // behaviors with success conditions
         final SensorActivation[] activations = b.getSuccessConditionSensorActivations();
         if (activations != null) {
            successConditionBehaviorsSensing.add(b);
         } else {
            successConditionBehaviorsNoSensing.add(b);
         }

         // If there are sensor activations associated with the success
         // condition, hadd them to the set of active
         // sensors.
         if (activations != null) {
            activeSensors.activateSensors(activations);
         }
      }

   }

   // Called when a new step is added to the ABT.
   void addStep(Step s) // {abt.addStep(s); }
   {
      if (s.getStepType() != Step.WAIT) {
         // If not a wait step, make it available for execution.
         if (s.getIsAtomic()) {
            atomicSteps.add(s);
         } else {
            leafSteps.add(s);
         }
      }

      addSuccessTest(s);
   }

   private void addSuccessTest(Step s) {
      if (s.getHasSuccessTest()) {
         // The step has a success test. Add it to the set of steps with
         // success tests.
         SensorActivation[] activations = s.getSuccessTestSensorActivations();
         if (activations != null) {
            successTestStepsSensing.add(s);
         } else {
            successTestStepsNoSensing.add(s);
         }

         /*
          * If there are sensor activations associated with the success test,
          * add them to the set of active sensors.
          */
         if (activations != null) {
            activeSensors.activateSensors(activations);
         }
      }

   }

   // Adds WME to working memory.
   public void addWME(WME w) {
      workingMemory.addWME(w);
   }

   public void addWMEs(WME... ws) {
      for (WME w : ws) {
         workingMemory.addWME(w);
      }
   }

   /**
    * Add a collection of WMEs to working memory.
    */
   public void addWMEs(Collection<WME> ws) {
      for (WME w : ws) {
         workingMemory.addWME(w);
      }
   }

   private void behave() {
      /**
       * Note: Ben Weber
       * 
       * Notify listens that behave is being invoked.
       */

      for (BehavingListener listener : behavingListeners) {
         listener.onBehave(executingSteps, leafSteps);
      }

      // For joint behaviors
      // Loop through all threads waiting on a negotiation condition checking
      // if any can run
      shutdownHook.shutdownMessage = getBehavingEntityShortName() + " was running negotiation threads";
      runNegotiationThreads();

      // fixme: remove?
      // Make sure that all negotiation threads are waiting.
      /*
       * final int originalPriority = Thread.currentThread().getPriority();
       * Thread.currentThread().setPriority(Thread.MAX_PRIORITY); final Iterator
       * iter = new ArrayList(activeNegotiationThreads).iterator();
       * while(iter.hasNext()) { final JointGoalNegotiationThread t =
       * (JointGoalNegotiationThread)iter.next(); // Thread must either not be
       * started, be waiting, or not be alive. // assert !t.getIsStarted() ||
       * t.getIsWaiting() || !t.isAlive(): t.shortToString() + " is still
       * running: isStarted = " + t.getIsStarted() + // " isWaiting = " +
       * t.getIsWaiting() + " isAlive = " + t.isAlive(); }
       * Thread.currentThread().setPriority(originalPriority);
       */

      if (bDecisionCycleSMCall) {
         shutdownHook.shutdownMessage = getBehavingEntityShortName() + " was in the decision cycle SM call";
         decisionCycleSMCall();
      }

      workingMemory.deleteMarkedTransientWMEs();

      // First check if any executing PrimitiveStep has completed.
      shutdownHook.shutdownMessage = getBehavingEntityShortName() + " was checking for completed primitive actions";
      Iterator<Step> primStepIterator = executingPrimitiveSteps.iterator();
      PrimitiveStep primStep;
      while (primStepIterator.hasNext()) {
         primStep = (PrimitiveStep) primStepIterator.next();

         if (primStep.getCompletionStatus() == PrimitiveAction.SUCCESS) {
            primStep.succeedStep();
            return;
         } else if (primStep.getCompletionStatus() == PrimitiveAction.FAILURE) {
            primStep.failStep();
            return;
         }
      }

      // Now check if there are any atomic steps to
      // execute. If there are atomic steps, skip sensing
      // and choose one of the steps, otherwise process as usual.
      shutdownHook.shutdownMessage = getBehavingEntityShortName() + " was checking continuously monitored conditions";
      if (atomicSteps.isEmpty()) {
         // No atomic steps

         /*
          * Now check the sensors associated with any continuously monitored
          * conditions (i.e. success tests and context conditions). This
          * prepares working memory for testing the monitored conditions.
          */
         if (!asynchronousSenseCycle) {
            activeSensors.sense();
            runSuccessTests(true); // run the sensing success tests
            runContextConditions(true); // run the sensing context
            // conditions
            runSuccessConditions(true); // run the sensing success
            // conditions
            workingMemory.markTransientWMEs();
         }

         long continuousConditionStartTime = System.currentTimeMillis();

         runSuccessTests(false); // run the no-sensing success tests
         runContextConditions(false); // run the no-sensing context
         // conditions
         runSuccessConditions(false); // run the no-sensing success
         // conditions

         // fixme: currently only measuring the amount of time spent testing
         // no-sensing continuous conditions.
         // fixme: current time measurements don't take account of the time
         // the thread is actually scheduled to
         // run - only measures elapsed system time.
         continuousConditionTime = System.currentTimeMillis() - continuousConditionStartTime;

         if (asynchronousSenseCycle && senseMonitor.sensedConditionsReadyToRun()) {
            runSuccessTests(true); // run the sensing success tests
            runContextConditions(true); // run the sensing context
            // conditions
            runSuccessConditions(true); // run the sensing success
            // conditions
            workingMemory.markTransientWMEs();
         }

         /*
          * Adjust which goals are marked as suspended because of conflicts.
          * Because of successes and failures occuring above, some currently
          * suspended goals may be unsuspended and some currently unsuspended
          * goals may be suspended. When a goal is suspended, if it is not a
          * leaf step, then all leaf steps below the goal must be marked as
          * suspended (but not the goals along the way). When unsuspending a
          * goal, if it is not a leaf step, all leaf steps below the goal are
          * unsuspended, except for leaf steps of subtrees rooted at a goal
          * marked as suspended. These adjustments are handled by methods
          * defined on ExecutableStep.
          */

      }

      // while running atomically a behaving entity with
      // asynchronous sensing continues to sense - this is all right
      // since the continuous conditions aren't being run.

      shutdownHook.shutdownMessage = getBehavingEntityShortName() + " was selecting a step";
      // Else, pick a leaf step and execute it.
      Step stepToExecute = chooseStep();

      this.lastChosenStep = stepToExecute;

      // If the debug flag has been set, update the debugger GUI
      if (debugLevel == GUI_DEBUGGER) {
         debuggerGUI.debug(continuousConditionTime);
      }

      if (stepToExecute != null) {
         // If there was a step to choose for execution, execute it.
         shutdownHook.shutdownMessage =
               getBehavingEntityShortName() + " was executing step " + stepToExecute + " of behavior " + stepToExecute.getParent();

         stepToExecute.execute();
      } else {
         // there were no steps to choose - wait 1/60 of a second
         try {
            shutdownHook.shutdownMessage = getBehavingEntityShortName() + " was waiting because there was no step to execute";
            Thread.sleep(17);
         } catch (InterruptedException exception) {
            throw new RuntimeError("Unexpected interruption");
         }
      }
      if (stats != null) {
         stats.sample();
      }
      persistIfNeeded();

   }

   public void behaviorWakeUp() {
      synchronized (behaving) {
         behaving.setEnabled(true);
      }
   }

   // If the behaving entity is running with the debugger, breaks.
   public void breakNextDecisionCycle() {
      if (debugLevel == GUI_DEBUGGER) {
         debuggerGUI.breakNextDecisionCycle();
      }
   }

   // A debugging utility for use in mental acts. Breaks immediately (during
   // the current mental act) and displays the tree.
   public void breakNow() {
      if (debugLevel == GUI_DEBUGGER) {
         debuggerGUI.breakNextDecisionCycle();
         debuggerGUI.debug(0); // Pass 0 for the continuousConditionTime.
      }
   }

   /*
    * Given a behavior signature, args and a set of failed behaviors, returns a
    * behavior whose precondition is satisfied by the args and which is not in
    * the set of failedBehaviors. If no behavior is found, returns null.
    * Implements the behavior arbitration algorithm defined in Bryan Loyall's
    * thesis.
    */
   private Behavior chooseBehavior(Object[] args, Set<Integer> failedBehaviors, GoalStep g, boolean findJointBehaviors,
                                   Set<BehavingEntity> teamMembers) {

      // Illegal to specify teammates if you aren't looking for joint
      // behaviors.
      assert !findJointBehaviors && teamMembers == null || findJointBehaviors;

      List<__BehaviorDesc> behList;
      final String signature = g.getSignature();

      // First find behaviors with matching signature.
      if (findJointBehaviors) {
         // looking for joint behaviors
         behList = jointBehaviorLibrary.lookupBehavior(signature);

         if (behList.isEmpty()) {
            // No behaviors were found matching the signature. Return
            // immediately with null.
            return null;
         } else if (teamMembers != null) {
            // filter behList so it only contains behaviors with the
            // specified teamMembers
            final Iterator<__BehaviorDesc> iter = behList.iterator();
            while (iter.hasNext()) {
               final __BehaviorDesc behDesc = iter.next();
               final Set<BehavingEntity> behTeamMembers = new HashSet<>(behDesc.teamMembers.length * 2);
               for (int i = 0; i < behDesc.teamMembers.length; i++) {
                  behTeamMembers.add(getBehavingEntity(behDesc.teamMembers[i]));
               }
               if (!behTeamMembers.equals(teamMembers)) {
                  iter.remove();
               }
            }
         }
      } else {
         // looking for individual behaviors
         behList = individualBehaviorLibrary.lookupBehavior(signature);
         if (behList == null) {
            // No behaviors were found matching the signature. Return
            // immediately with null.
            return null;
         }
      }

      // debug: print out the list of behaviors to choose from
      /*
       * System.err.println("Choosing from behaviors for signature: " +
       * signature); for (Object b : behList) { System.err.println("\t" +
       * ((__BehaviorDesc) b).signature); System.err.flush(); }
       */

      // Now filter out all failed behaviors
      Iterator<__BehaviorDesc> iter = behList.iterator();
      while (iter.hasNext()) {
         final __BehaviorDesc behDesc = iter.next();
         if (failedBehaviors.contains(behDesc.behaviorID)) {
            iter.remove();
         }
      }

      // If there are no candidate behaviors left after removing the failed
      // behaviors, return null.
      if (behList.isEmpty()) {
         return null;
      }

      // List of satisfied behavior classes.
      final List<SatisfiedBehavior> satisfiedBeh = new ArrayList<>(100);

      // Before running the preconditions, accumulate all sensor
      // activations referred to by any precondition of any behavior
      // with this signature, and call senseOneShot() on each of
      // these sensors.
      iter = behList.iterator();
      Set<SensorActivation> sensors = new HashSet<>();
      try {
         while (iter.hasNext()) {
            final __BehaviorDesc behDesc = iter.next();
            if (behDesc.preconditionSensorFactory != null) {
               // Behavior has a precondition sensor factory.

               final Object[] sensorFactoryArgs = {
                  behDesc.behaviorID
               };
               final SensorActivation[] activations =
                     (SensorActivation[]) behDesc.preconditionSensorFactory.invoke(null, sensorFactoryArgs);
               Collections.addAll(sensors, activations);
            }
         }
      } catch (Exception e) {
         throw new AblRuntimeError("Reflection error", e);
      }

      // invoke the sensors - senseOneShot
      if (!sensors.isEmpty()) {
         runSensors(new ArrayList<>(sensors), false);
      }

      // Now test preconditions, ignoring any behaviors in the set
      // failedBehaviors.
      iter = behList.iterator();

      try {
         while (iter.hasNext()) {
            final __BehaviorDesc behDesc = iter.next();
            if (behDesc.precondition != null) {
               // Behavior has a precondition
               HashMap<Object, Object> map = new HashMap<>();
               Object[] argArray = {
                  behDesc.behaviorID,
                  args,
                  map,
                  this
               };
               // Method invoked with null instance since it is static.
               final Boolean b = (Boolean) behDesc.precondition.invoke(null, argArray);
               if (debugLevel == GUI_DEBUGGER) {
                  debuggerGUI.traceAblExecutionEvent(AblEvent.PRECONDITION_EXECUTION, behDesc, b,
                                                     ((DebuggableStep) g).getNestLevel() + 1, behDesc.behaviorID);
               }

               if (b) {
                  // Precondition satisifed; store the satisfied behavior
                  // and the hash table of variables
                  // bound by the precondition.
                  satisfiedBeh.add(new SatisfiedBehavior(behDesc, map));
               }
            } else {
               // Add behaviors without preconditions to satisfiedBeh (null
               // precondition is always true)
               if (debugLevel == GUI_DEBUGGER) {
                  debuggerGUI.traceAblExecutionEvent(AblEvent.PRECONDITION_EXECUTION, behDesc, true,
                                                     ((DebuggableStep) g).getNestLevel() + 1, behDesc.behaviorID);
               }

               satisfiedBeh.add(new SatisfiedBehavior(behDesc, null));
            }
         }

         if (!satisfiedBeh.isEmpty()) {
            // Behaviors with satisfied preconditions were found.

            // Now sort the satisfied behaviors by specificity.
            SatisfiedBehavior[] behArray = satisfiedBeh.toArray(new SatisfiedBehavior[satisfiedBeh.size()]);
            Arrays.sort(behArray, behComparator);

            // Now create a List consisting of all most-specific behaviors.
            List<SatisfiedBehavior> mostSpecificBeh = new ArrayList<>(satisfiedBeh.size());
            mostSpecificBeh.add(behArray[0]); // The first behavior is
            // always most-specific.
            for (int j = 1; j < behArray.length; j++) {
               if (behComparator.compare(behArray[0], behArray[j]) == 0) {
                  mostSpecificBeh.add(behArray[j]);
               }
            }

            // Now randomly return an instantiated behavior from among the
            // most specific behaviors.
            __BehaviorDesc winningBeh;
            Map<?, ?> preconditionBoundVariables;
            if (mostSpecificBeh.size() == 1) {
               winningBeh = mostSpecificBeh.get(0).behDesc;
               preconditionBoundVariables = mostSpecificBeh.get(0).preconditionBoundVariables;
            } else if (mostSpecificBeh.size() > 1) {
               int randomIndex = randomGen.nextInt(mostSpecificBeh.size());
               winningBeh = mostSpecificBeh.get(randomIndex).behDesc;
               preconditionBoundVariables = mostSpecificBeh.get(randomIndex).preconditionBoundVariables;
            } else {
               throw new RuntimeError("Expected mostSpecificBeh >= 1, instead < 1");
            }

            // Construct the winning behavior
            Object[] behFactoryArgs;
            if (debugLevel == GUI_DEBUGGER) {
               behFactoryArgs = new Object[] {
                  winningBeh.behaviorID,
                  args,
                  preconditionBoundVariables,
                  g,
                  winningBeh.signature,
                  this,
                  winningBeh
               };
            } else {
               behFactoryArgs = new Object[] {
                  winningBeh.behaviorID,
                  args,
                  preconditionBoundVariables,
                  g,
                  winningBeh.signature,
                  this
               };
            }
            return (Behavior) winningBeh.factory.invoke(null, behFactoryArgs);
         } else {
            return null;
         }
      } catch (Exception e) {
         e.printStackTrace();
         String goalArgsDescription = "goal with signature " + g.getSignature() + " passed in args of types: ";
         for (Object o : args) {
            goalArgsDescription += o.getClass() + ", ";
         }
         throw new RuntimeError("\n\n\nERROR: Reflection error in chooseBehavior(): " + goalArgsDescription + "\n\n");
      }
   }

   // Return a behavior that was synthesized by the compiler and guaranteed to
   // be unique
   Behavior getUniqueSynthesizedBehavior(String behaviorSignature, GoalStep parentStep, Object[] args) {
      List<__BehaviorDesc> behList = individualBehaviorLibrary.lookupBehavior(behaviorSignature);
      if (behList.size() < 1) {
         throw new AblRuntimeError("\n\n\nERROR: getUniqueSynthesizedBehavior() found no behaviors with signature "
               + behaviorSignature + "\n\n");

      } else if (behList.size() > 1) {
         throw new AblRuntimeError("\n\n\nERROR: getUniqueSynthesizedBehavior() found more than one behavior with signature "
               + behaviorSignature + "\n\n");
      }
      __BehaviorDesc b = behList.get(0);
      // Construct the behavior
      Object[] behFactoryArgs;
      if (debugLevel == GUI_DEBUGGER) {
         behFactoryArgs = new Object[] {
            b.behaviorID,
            args,
            null,
            parentStep,
            behaviorSignature,
            this,
            b
         };
      } else {
         behFactoryArgs = new Object[] {
            b.behaviorID,
            args,
            null,
            parentStep,
            behaviorSignature,
            this
         };
      }

      try {
         return (Behavior) b.factory.invoke(null, behFactoryArgs);
      } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
         e.printStackTrace();
         throw new AblRuntimeError("\n\n\nERROR in getUniqueSynthesizedBehavior() with behavior signature : " + behaviorSignature
               + "\n\n");
      }
   }

   // Entry point for choosing an individual behavior.
   Behavior chooseIndividualBehavior(Object[] args, Set<Integer> failedBehaviors, GoalStep g) {
      return chooseBehavior(args, failedBehaviors, g, false, null);
   }

   // Entry point for choosing a joint behavior.
   Behavior chooseJointBehavior(Object[] args, Set<Integer> failedBehaviors, GoalStep g) {
      return chooseBehavior(args, failedBehaviors, g, true, null);
   }

   // Entry point for choosing a joint behavior with a specific set of team
   // members
   Behavior chooseJointBehavior(Object[] args, Set<Integer> failedBehaviors, GoalStep g, Set<BehavingEntity> teamMembers) {
      return chooseBehavior(args, failedBehaviors, g, true, teamMembers);
   }

   /*
    * Given the current ABT, chooses a leaf step (from leafSteps, the set of
    * leaf steps), and executes it. Implements the step arbitration algorithm
    * described in Bryan Loyall's thesis: 1. Never choose wait steps, executing
    * actions, or steps marked suspended. 2. Prefer steps with higher
    * priorities. 3. Prefer to continue the same line of expansion. 4. If
    * multiple steps still remain, randomly choose among them.
    * 
    * In this first implementation, conflicts are not handled; thus there are no
    * suspended steps.
    */
   private Step chooseStep() {
      /*
       * RES: don't care about conflict set size initially, since we already
       * have size of atomicSteps and leafSteps
       */
      if (!leafSteps.isEmpty() || !atomicSteps.isEmpty()) {
         // There are leaf steps to choose from.
         List<Step> conflictSet;
         if (!atomicSteps.isEmpty()) {
            conflictSet = new ArrayList<>(atomicSteps);
         } else {
            conflictSet = new ArrayList<>(leafSteps);
         }

         /*
          * RES: 'conflictSetPostSuspend' - Do care after this block; we'll want
          * to see the reduction from suspension
          */
         // Remove suspended steps.
         if (bStepConflicts) {
            Iterator<Step> iter = conflictSet.iterator();
            while (iter.hasNext()) {
               if (iter.next().isSuspended()) {
                  iter.remove();
               }
            }
         }

         if (conflictSetSuspend != null) {
            conflictSetSuspend.sample(conflictSet.size());
         }
         /* RES: Don't care after this block; not using joint behaviors */
         // Remove steps in the middle of negotiating
         Iterator<Step> iter = conflictSet.iterator();
         while (iter.hasNext()) {
            Step s = iter.next();
            if (s.getStepType() == Step.GOAL && ((GoalStep) s).isJointGoal() && ((JointGoalStep) s).getIsNegotiating()) {
               iter.remove();
            }
         }

         if (!conflictSet.isEmpty()) {
            // if, after removing suspended steps there are still some steps
            // left, choose one

            // Grab an array of all the leaf steps.
            Step[] conflictArray = conflictSet.toArray(new Step[conflictSet.size()]);

            // Sort the array by priority - highest priority first.
            Arrays.sort(conflictArray, stepPriorityComparator);

            conflictSet.clear(); // Clear the conflict set to prepare for
            // constructing the new set.

            /* RES: we will care after this: 'conflictSetTopPrioritySteps' */
            conflictSet.add(conflictArray[0]); // The first step is always
            // highest priority.
            for (int i = 1; i < conflictArray.length; i++) {
               if (stepPriorityComparator.compare(conflictArray[0], conflictArray[i]) == 0) {
                  conflictSet.add(conflictArray[i]);
               } else {
                  break;
               }
            }

            if (conflictSetTopPrioritySteps != null) {
               conflictSetTopPrioritySteps.sample(conflictSet.size());
            }
            if (bCurrentLineOfExpansion && conflictSet.size() > 1) {
               /*
                * If the current line of expansion heuristic is turned on, and
                * there is more than one highest priority step to choose from,
                * sort the conflict set by the current line of expansion.
                */

               conflictArray = conflictSet.toArray(new Step[conflictSet.size()]);
               Arrays.sort(conflictArray, stepExpansionComparator);

               // Remove all non-current line of expansion steps from the
               // conflict set.
               conflictSet.clear();

               /*
                * RES: we will care after this:
                * 'conflictSetLineOfExpansionSteps'
                */
               /*
                * The first step is always on the current line of expansion or
                * no step is on the current line of expansion.
                */
               conflictSet.add(conflictArray[0]);
               for (int i = 1; i < conflictArray.length; i++) {
                  if (stepExpansionComparator.compare(conflictArray[0], conflictArray[i]) == 0) {
                     conflictSet.add(conflictArray[i]);
                  } else {
                     break;
                  }
               }
               if (conflictSetLineOfExpansionSteps != null) {
                  conflictSetLineOfExpansionSteps.sample(conflictSet.size());
               }
            }

            // Now randomly choose among the steps in the conflict set.
            assert conflictSet.size() >= 1;
            if (conflictSet.size() > 1) {
               return conflictSet.get(randomGen.nextInt(conflictSet.size()));
            } else {
               return conflictSet.get(0);
            }
         } else {
            return null; // no unsuspended or non-negotiating steps to
            // choose from
         }
      } else {
         return null; // No leaf steps.
      }
   }

   // The default decision cycle SM call does nothing. Can be overridden on
   // concrete behaving entity classes.
   protected void decisionCycleSMCall() {
   }

   // Deletes all WMEs with a given class name from working
   // memory. If the WME class is not found in working memory, does
   // nothing.
   public void deleteAllWMEClass(String wmeClassName) {
      workingMemory.deleteAllWMEClass(wmeClassName);
   }

   // Removes a WME from working memory. If the wme is not in working
   // memory does nothing (doesn't throw an error).
   public void deleteWME(WME wmeToDelete) {
      workingMemory.deleteWME(wmeToDelete);
   }

   /**
    * Called when a step is executed. Updates BehavingEntity state for the step.
    */
   void executeStep(Step s) {

      // Remove step from set of executable steps.
      if (s.getIsAtomic()) {
         atomicSteps.remove(s);
      } else {
         leafSteps.remove(s);
      }

      int stepType = s.getStepType();
      if (stepType == Step.PRIMITIVE) {
         // s is a primitive act. Add to set of executing primitive acts.
         executingPrimitiveSteps.add(s);
      }

      // Add the step to the table of executing steps (keyed by step name).
      if (stepType == Step.PRIMITIVE || stepType == Step.GOAL) {
         Set<Step> stepSet = executingSteps.get(((ExecutableStep) s).getName());
         if (stepSet != null) {
            stepSet.add(s);
         } else {
            stepSet = new HashSet<>();
            stepSet.add(s);
            executingSteps.put(((ExecutableStep) s).getName(), stepSet);
         }
      }
   }

   // Given an ExecutableStep, determines if any currently executing
   // steps conflict with this step. Calls suspend on the argument
   // step for each conflicting executing step.
   void findConflictsWithCurrentlyExecutingSteps(ExecutableStep step, int comparisonIndex) {
      assert comparisonIndex == BehavingEntity.suspendOnInstantiate || comparisonIndex == BehavingEntity.suspendOnExecute;
      String[] conflictArray = step.getConflicts();
      Set<Step> stepSet;
      for (String aConflictArray : conflictArray) {
         stepSet = executingSteps.get(aConflictArray); // Get
         // the
         // conflict
         // set.
         if (stepSet != null) {
            for (Object aStepSet : stepSet) {
               // Suspend the step with each of the conflicting steps.
               ExecutableStep executingStep = (ExecutableStep) aStepSet;
               switch (comparisonIndex) {
                  case BehavingEntity.suspendOnInstantiate:
                     // fixme: this case appears to be unused
                     if (executingStep.getPriority() >= step.getPriority()) {
                        step.suspend(executingStep);
                     }
                     break;
                  case BehavingEntity.suspendOnExecute:

                     // When a step executes, it suspends any conflicting
                     // executing step
                     // of lower priority than it and in turn is
                     // suspended by any conflicting executing step of
                     // greater
                     // or equal priority to it.

                     if (executingStep.getPriority() < step.getPriority()) {
                        executingStep.suspend(step);
                     } else {
                        step.suspend(executingStep);
                     }
                     break;
               }
            }
         }
      }
   }

   /*
    * Implements the top level ABL execution loop. Implements the loop defined
    * in Bryan's thesis. 1. If needed adjust the active behavior tree for
    * actions that have finished. 2. Else if needed adjust the ABT based on
    * changes in the world (context conditions and success tests). 3. Else if
    * needed adjust suspended goals. 4. Else pick a leaf step to execute and
    * execute it.
    * 
    * Bryan sent an email explaining why each step of the loop is part of a
    * branching if-then-else rather than just running sequentially (longer
    * discussion in HapDesignQ&A.txt). But for now I'm just going to do the test
    * sequentially. Eventually I will need to maintain some kind of flag that
    * keeps track of whether the working memory has been modified. Another flag
    * I'll need is whether a primitive act has succeeded or failed. A third flag
    * I'll need is whether any change has been made to the ABT.
    */

   // Return a DefaultTreeModel containing a representation of the ABT. Used by
   // the debugger.
   DefaultTreeModel getABTTreeModel() {
      return new DefaultTreeModel(((DebuggableBehavior) ABT).getTree());
   }

   public String getBehavingEntityShortName() {
      String longName = this.getClass().getName();
      return longName.substring(longName.lastIndexOf('.') + 1);
   }

   /**
    * Returns the BehaviorWME of the last step chosen for execution.
    */
   public BehaviorWME getCurrentBehaviorWME() {
      return null != this.lastChosenStep ? this.getCurrentStepWME().getParent() : null;
   }

   public StepWME getCurrentStepWME() {
      return null != this.lastChosenStep ? this.lastChosenStep.getReflectionWME() : null;
   }

   // Debug support - gets a reference to the debugger
   // Needed for ensuring that another element of the GUI doesn't steal focus
   // from the debugger
   public Debugger getDebuggerGUI() {
      return debuggerGUI;
   }

   /**
    * Return true if GUI debugger is active
    */
   public boolean isDebuggerGuiActive() {
      return debugLevel == GUI_DEBUGGER;
   }

   Thread getDecisionCycleThread() {
      return decisionCycleThread;
   }

   private InitiatedJointGoalStep getInitiatedJointGoalStep(CollectionBehavior abtRoot, String signature,
                                                            Set<BehavingEntity> teamMembers, Object[] args,
                                                            boolean teamNeededForSuccess) {
      return new InitiatedJointGoalStep(abtRoot, signature, teamMembers, args, teamNeededForSuccess);
   }

   // Return an InitiatedJointGoalStepDebug
   private InitiatedJointGoalStep getInitiatedJointGoalStepDebug(CollectionBehavior abtRoot, String signature,
                                                                 Set<BehavingEntity> teamMembers, Object[] args,
                                                                 boolean teamNeededForSuccess) {
      return new InitiatedJointGoalStepDebug(abtRoot, signature, teamMembers, args, teamNeededForSuccess, debugLevel);
   }

   Set<String> getRegisteredBehaviors() {
      Set<String> fullBehaviorSet = new HashSet<>(individualBehaviorLibrary.getRegisteredBehaviors());
      fullBehaviorSet.addAll(jointBehaviorLibrary.getRegisteredBehaviors());
      return fullBehaviorSet;
   }

   // Returns a Set of registered individual behavior signatures
   Set<String> getRegisteredIndividualBehaviors() {
      return individualBehaviorLibrary.getRegisteredBehaviors();
   }

   // fixme: add back support for WME modification
   /*
    * // Modifies a WME in working memory. public void modifyWME(WME
    * wmeToModify, WME wmeWithNewValues) { try {
    * workingMemory.modifyWME(wmeToModify, wmeWithNewValues); } catch
    * (WorkingMemoryException e) {throw new AblRuntimeError(e);} }
    */

   // Returns a Set of registered joint behavior signatures
   Set<String> getRegisteredJointBehaviors() {
      return jointBehaviorLibrary.getRegisteredBehaviors();
   }

   // Returns a reference to the root of the ABT. Visibility public for debugging
   public CollectionBehavior getRootCollectionBehavior() {
      return ABT;
   }

   // Get a WorkingMemoryDebugger for the behaving entity's working memory.
   public WorkingMemoryDebugger getWMDebugger() {
      return new WorkingMemoryDebugger(workingMemory);
   }

   // Get this entity's working memory
   public WorkingMemory getWorkingMemory() {
      return workingMemory;
   }

   /**
    * Note: Ben Weber
    * 
    * Returns true if ABL is paused
    */
   public boolean isPaused() {
      return paused.isEnabled();
   }

   // Caller commited during negotiation. Sets flag indicating negotiation
   // threads should be rerun.
   void jointGoalNegotiatorCommitted() {
      if (!(Thread.currentThread() instanceof JointGoalNegotiationThread)) {
         throw new AblRuntimeError("Non-negotiation thread " + Thread.currentThread() + " attempted jointGoalNegotiatorCommitted.");
      }
      negotiatorCommittedDuringNegotiation = true;
   }

   // Given the name of a signature bearing reflection WME (e.g. "GoalStepWME")
   // and a signature name, returns a list of all
   // WMEs sharing that signature.
   public List<?> lookupReflectionWMEBySignature(String wmeClassName, String signature) {
      return workingMemory.lookupReflectionWMEBySignature(wmeClassName, signature);
   }

   // Given the name of a reflection WME and a user property, returns a list of
   // all reflection WMEs bearing that property.
   public List<?> lookupReflectionWMEByUserProperty(String wmeClassName, String userPropertyName) {
      return workingMemory.lookupReflectionWMEByUserProperty(wmeClassName, userPropertyName);
   }

   /**
    * @param <T> WME type
    * @param wmeClass WME class
    * 
    * @return correctly genericized list of working memory WMEs of the given
    *         type.
    */
   public <T extends WME> List<T> lookupWME(Class<T> wmeClass) {
      return workingMemory.lookupWME(wmeClass);
   }

   // Given a WME class name, returns the list of WMEs in working memory with
   // that class name.
   public List<?> lookupWME(String wmeClassName) {
      return workingMemory.lookupWME(wmeClassName);
   }

   /**
    * @return Does the working memory contain this WME?
    * @param wme The wme to look for
    */
   public boolean containsThisWME(WME wme) {
      return workingMemory.containsThisWME(wme);
   }

   // Initiates negotiation for synchronizing on a joint goal.
   // g - the joint goal choosen by the initiating entity
   // args - the arguments to use for selecting joint behaviors
   // if negotiation is successful, returns the commit set (as a Map),
   // otherwise returns null
   Map<BehavingEntity, Step> negotiateEntry(JointGoalStep g, Object[] args) {
      if (!(Thread.currentThread() instanceof JointGoalNegotiationThread)) {
         throw new IllegalStateException("Not in JointGoalNegotiationThread ");
      }
      Long uniqueEntryNegotiationID;
      synchronized (currentEntryNegotiators) {
         uniqueEntryNegotiationID = g.negotiator.getUniqueEntryNegotiationID();
         currentEntryNegotiators.put(uniqueEntryNegotiationID, g);
      }
      // blocks on negotiation
      Map<BehavingEntity, Step> commitSet = g.negotiator.negotiateEntry(args, g);
      synchronized (currentEntryNegotiators) {
         currentEntryNegotiators.remove(uniqueEntryNegotiationID);
      }
      return commitSet;
   }

   /**
    * Note: Ben Weber
    * 
    * Pauses ABL
    */
   public void pause() {
      synchronized (paused) {
         boolean oldValue = paused.isEnabled();
         paused.setEnabled(true);
         this.pcs.firePropertyChange(PAUSED_PROPERTY, oldValue, true);
      }
   }

   /**
    * Request persistence at the end of the current
    * {@link BehavingEntity#behave()} cycle
    * 
    * @param file Serialize to this file.
    */
   public void persist(File file) {
      synchronized (persistLock) {
         persistLock.clear();
         persistLock.add(file);
      }
   }

   private void persistIfNeeded() {
      synchronized (persistLock) {
         if (!persistLock.isEmpty()) {
            File file = persistLock.get(0);
            persistLock.clear();
            pause();
            try {
               /* Lock workingMemory while the save is in progress */
               synchronized (workingMemory) {
                  try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
                     out.writeObject(this);
                  }
               }
            } catch (IOException e) {
               logger.severe("Failed to persist hive mind: " + e.toString());
            } finally {
               unpause();
            }
         }
      }
   }

   void printAtomicSteps() {
      Iterator<Step> iter = atomicSteps.iterator();
      System.err.println("Atomic steps for " + getBehavingEntityShortName());
      while (iter.hasNext()) {
         System.err.println("    " + iter.next());
      }
   }

   void printExecutingSteps() {
      Iterator<String> iter = executingSteps.keySet().iterator();
      System.err.println("Executing steps for " + getBehavingEntityShortName());
      while (iter.hasNext()) {
         System.err.println("    " + iter.next());
      }
   }

   void printLeafSteps() {
      Iterator<Step> iter = leafSteps.iterator();
      System.err.println("Leaf steps for " + getBehavingEntityShortName());
      while (iter.hasNext()) {
         System.err.println("    " + iter.next());
      }
   }

   // Prints out the threads in activeNegotiationThreads
   void printNegotiationThreads() {

      synchronized (activeNegotiationThreads) { // synchronize to avoid
         // concurrent modification
         Iterator<JointGoalNegotiationThread> iter = activeNegotiationThreads.iterator();
         if (!iter.hasNext()) {
            System.err.println("No active negotiation threads in " + getBehavingEntityShortName());
         }
         while (iter.hasNext()) {
            System.err.println(iter.next());
         }
      }
   }

   // Queues an intention to enter a joint goal
   // uniqueEntryNegotiationID - a wrapped long which uniquely identifies the
   // negotiation
   // sender - the entity which sent this intention-to-enter
   // args - the arguments to use for selecting a joint behavior
   // teamMembers - the set of team members participating in the joint behavior
   // g - the JointGoalStep chosen by the sender
   public void queueIntentionToEnter(final Long uniqueEntryNegotiationID, final BehavingEntity sender, final Object[] args,
                                     final boolean teamNeededForSuccess, final Set<BehavingEntity> teamMembers,
                                     final JointGoalStep g) {
      JointGoalStep tempGoalStep;
      synchronized (currentEntryNegotiators) {
         tempGoalStep = currentEntryNegotiators.get(uniqueEntryNegotiationID);
         if (tempGoalStep == null) {
            // first receipt of a message associated with this negotiation

            // Construct an initiated joint goal
            if (debugLevel == NO_DEBUG) {
               tempGoalStep =
                     getInitiatedJointGoalStep(this.getRootCollectionBehavior(), g.getSignature(), teamMembers, args,
                                               teamNeededForSuccess);
            } else {
               tempGoalStep =
                     getInitiatedJointGoalStepDebug(this.getRootCollectionBehavior(), g.getSignature(), teamMembers, args,
                                                    teamNeededForSuccess);
            }
            currentEntryNegotiators.put(uniqueEntryNegotiationID, tempGoalStep);
         }
      }
      final JointGoalStep escroedGoalStep = tempGoalStep; // Lock it down for
      // easy reference
      // within inner
      // classes

      // Register the intention to enter.
      // Explicitly set entity so that it doesn't eroneously inherit from
      // sender
      // fixme: come up with a more general solution, probably employing RMI
      // for communication between entities

      final JointGoalNegotiationThread intentionToEnterThread =
            new JointGoalNegotiationThread(escroedGoalStep.negotiator, escroedGoalStep + " queueIntentionToEnter") {
               @Override
               public void run() {
                  // explicitly set the entity in this thread as inheritance
                  // would
                  // have it equal the sender's thread
                  entity.set(BehavingEntity.this);
                  escroedGoalStep.negotiator.processIntentionToEnter(uniqueEntryNegotiationID, sender, args, teamNeededForSuccess,
                                                                     teamMembers, g, escroedGoalStep);
               }
            };
      registerNegotiationThread(intentionToEnterThread);
   }

   // Queues an intention to exit a goal.
   // Also used for unsuspend, which isn't really an exit.
   // sender - the entity which sent this intention-to-succeed
   // g - the JointGoalStep within this entity to succeed
   public void queueIntentionToExit(final BehavingEntity sender, final JointGoalStep g, final int intention) {
      // Explicitly set entity so that it doesn't eroneously inherit from
      // sender
      // fixme: come up with a more general solution, probably employing RMI
      // for communication between entities
      registerNegotiationThread(new JointGoalNegotiationThread(g.negotiator, g + " queueIntentionToExit("
            + JointGoalNegotiator.formatIntention(intention) + ")") {
         @Override
         public void run() {
            if (g.negotiator != null) {
               entity.set(BehavingEntity.this);
               switch (intention) {
                  case JointGoalNegotiator.SUCCEED:
                     g.negotiator.processIntentionToSucceed(sender);
                     break;
                  case JointGoalNegotiator.FAIL:
                     g.negotiator.processIntentionToFail(sender);
                     break;
                  case JointGoalNegotiator.REMOVE:
                     g.negotiator.processIntentionToRemove(sender);
                     break;
                  case JointGoalNegotiator.SUSPEND:
                     g.negotiator.processIntentionToSuspend(sender);
                     break;
                  case JointGoalNegotiator.UNSUSPEND:
                     g.negotiator.processIntentionToUnsuspend(sender);
                     break;
                  default:
                     throw new AblRuntimeError("Unexpected intention");
               }
            }
         }
      });
   }

   // Queues an intention to refuse pursuit of a joint goal
   // uniqueEntryNegotiationID - a wrapped long which uniquely identifies the
   // negotiation
   // sender - the entity which sent this intention-to-refuse-entry
   // teamMembers - the set of team members which must coordinate on refusing
   // entry
   public void queueIntentionToRefuseEntry(final Long uniqueEntryNegotiationID, final BehavingEntity sender,
                                           final Set<BehavingEntity> teamMembers) {
      JointGoalStep tempGoalStep;
      synchronized (currentEntryNegotiators) {
         tempGoalStep = currentEntryNegotiators.get(uniqueEntryNegotiationID);
         if (tempGoalStep == null) {
            // First receipt of a message associated with this negotiation.
            // This strange case could occur if an entity is slow
            // to receive the original entry intention before some
            // other team member refuses entry.
            if (debugLevel == NO_DEBUG) {
               tempGoalStep =
                     getInitiatedJointGoalStep(this.getRootCollectionBehavior(), "_RefuseEntryDummy()", teamMembers, null, false);
            } else {
               tempGoalStep =
                     getInitiatedJointGoalStepDebug(this.getRootCollectionBehavior(), "_RefuseEntryDummy()", teamMembers, null,
                                                    false);
            }
            currentEntryNegotiators.put(uniqueEntryNegotiationID, tempGoalStep);
         }
      }
      final JointGoalStep escroedGoalStep = tempGoalStep; // Lock it down for
      // easy reference
      // within inner
      // classes

      // Register the intention to refuse entry.
      // Explicitly set entity so that it doesn't eroneously inherit from
      // sender
      // fixme: come up with a more general solution, probably employing RMI
      // for communication between entities
      final JointGoalNegotiationThread intentionToRefuseEntryThread =
            new JointGoalNegotiationThread(escroedGoalStep.negotiator, escroedGoalStep + " queueIntentionToRefuseEntry") {
               @Override
               public void run() {
                  // explicitly set the entity in this thread as inheritance
                  // would
                  // have it equal the sender's thread
                  entity.set(BehavingEntity.this);
                  escroedGoalStep.negotiator.processIntentionToRefuseEntry(uniqueEntryNegotiationID, sender);
               }
            };
      registerNegotiationThread(intentionToRefuseEntryThread);
   }

   // Returns true if ABT reflection has been enabled for this BehavingEntity,
   // false otherwise.
   boolean reflectionEnabled() {
      return rootCollectionBehaviorWME != null;
   }

   // register a negotiation thread - package access
   void registerNegotiationThread(JointGoalNegotiationThread t) {
      assert t != null;
      activeNegotiationThreads.add(t);
   }

   // Called when a behavior is removed from the ABT.
   // idempotent (because of behaviorRemoved state maintained on Behavior)
   void removeBehavior(Behavior b) {

      if ((b.getHasContextCondition() || b.getHasSuccessCondition()) && !b.getBehaviorRemoved()) {
         // Remove behavior from context condition and/or success condition
         // behaviors.

         final SensorActivation[] contextConditionActivations = b.getContextConditionSensorActivations();
         if (contextConditionActivations != null) {
            contextConditionBehaviorsSensing.remove(b);
         } else {
            contextConditionBehaviorsNoSensing.remove(b);
         }

         final SensorActivation[] successConditionActivations = b.getSuccessConditionSensorActivations();
         if (successConditionActivations != null) {
            successConditionBehaviorsSensing.remove(b);
         } else {
            successConditionBehaviorsNoSensing.remove(b);
         }

         b.setBehaviorRemoved();

         /*
          * If there are sensor activations associated with the context and/or
          * success conditions, remove them from the set of active sensors.
          */
         if (contextConditionActivations != null) {
            activeSensors.deactivateSensors(contextConditionActivations);

            // fixme: remove
            /*
             * for(int i = 0; i < activations.length; i++) if
             * (activations[i].activeSensor
             * .getClass().getName().equals("facade.sensor.GraceAnimationCueSensor"
             * )) { NativeAnimationInterface.dprintf("Deactivate
             * AnimationCueSensor for behavior " + b.getClass().getName());
             * System.out.println("Deactivating sensors for behavior " +
             * b.getClass().getName()); }
             */
         }
         if (successConditionActivations != null) {
            activeSensors.deactivateSensors(successConditionActivations);
         }
      }

   }

   // Removes a goal or primitive step from the table of executing steps.
   void removeExecutingStep(Step s) {
      if (s.getStepType() == Step.PRIMITIVE || s.getStepType() == Step.GOAL) {
         Set<Step> stepSet = executingSteps.get(((ExecutableStep) s).getName());
         if (stepSet != null) {
            stepSet.remove(s);
         }
      }
   }

   /** Called when a step is removed from the ABT. Idempotent. */
   void removeStep(Step s) {
      removeSuccessTest(s);

      // Removes the step from the set of executing primitive
      // acts. If the step isn't an executing primitive act,
      // does nothing.
      executingPrimitiveSteps.remove(s);

      // Removes the step from the set of steps that can be
      // chosen for execution. If the step isn't in the set,
      // does nothing.
      if (s.getIsAtomic()) {
         atomicSteps.remove(s);
      } else {
         leafSteps.remove(s);
      }

      // Remove the step from the table of executing steps.
      removeExecutingStep(s);
   }

   // Removes a success test.
   void removeSuccessTest(Step s) {
      if (s.getHasSuccessTest() && (successTestStepsSensing.contains(s) || successTestStepsNoSensing.contains(s))) {
         // The step has a success test. Remove it from the set of steps with
         // success tests.
         SensorActivation[] activations = s.getSuccessTestSensorActivations();
         if (activations != null) {
            successTestStepsSensing.remove(s);
         } else {
            successTestStepsNoSensing.remove(s);
         }

         // If there are sensor activations associated with the
         // success test, remove them from the set of active
         // sensors.
         if (activations != null) {
            activeSensors.deactivateSensors(activations);
         }

      }
   }

   // Called when a step already in the ABT is reset.
   void resetStep(Step s) // { abt.resetStep(); }
   {
      /*
       * Removes the step from the set of executing primitive acts. If the step
       * isn't an executing primitive act, does nothing.
       */

      executingPrimitiveSteps.remove(s);

      // Remove from the table of executing steps.
      removeExecutingStep(s);

      // Adds the step to the set of steps that can be chosen for execution.
      if (s.getStepType() != Step.WAIT) {
         if (s.getIsAtomic()) {
            atomicSteps.add(s);
         } else {
            leafSteps.add(s);
         }
      }
   }

   /*
    * Runs the context conditions and modifies the ABT. Returns true if a
    * context condition unfires (becomes false).
    */
   private boolean runContextConditions(boolean runSensedConditions) {

      Iterator<Behavior> contextConditionIterator;

      if (runSensedConditions) {
         contextConditionIterator = contextConditionBehaviorsSensing.iterator();
      } else {
         contextConditionIterator = contextConditionBehaviorsNoSensing.iterator();
      }
      Behavior contextConditionBehavior;
      while (contextConditionIterator.hasNext()) {
         contextConditionBehavior = contextConditionIterator.next();
         if (!contextConditionBehavior.contextCondition()) {
            contextConditionBehavior.failBehavior();
            runContextConditions(runSensedConditions);
            return true;
         }
      }
      return false;
   }

   private void runNegotiationThreads() {
      negotiatorCommittedDuringNegotiation = false;

      JointGoalNegotiationThread[] threads =
            activeNegotiationThreads.toArray(new JointGoalNegotiationThread[activeNegotiationThreads.size()]);
      for (JointGoalNegotiationThread thread : threads) {
         if (!thread.getIsStarted()) {
            // t hasn't been started yet - start it up
            TimeCheckThread tct = new TimeCheckThread(thread);
            tct.start();
            thread.start(); // block until thread completes or waits
            tct.interrupt();
         } else if (!thread.isAlive()) {
            // t is done running - wake waiters and remove it from the
            // activeNegotiationThreads list
            activeNegotiationThreads.remove(thread);
         } else {
            TimeCheckThread tct = new TimeCheckThread(thread);
            tct.start();
            thread.continueNegotiation(); // give thread the go-ahead
            // to continue - block until
            // thread completes or waits
            tct.interrupt();
         }
      }

      if (negotiatorCommittedDuringNegotiation) { // someone committed during
         // negotiation - rerun the
         // negotiators.
         runNegotiationThreads();
      }
   }

   /**
    * Adds a Rule and Rulegroup WME to working memory for every defined rule and
    * rulegroup.
    */
   private void addRuleAndRulegroupWMEs() {

      Rule[] allRules;
      Rulegroup[] allRulegroups;

      try {
         Class<?> bEntityClass = Class.forName(packagename + "." + getBehavingEntityShortName());
         allRules = (Rule[]) bEntityClass.getDeclaredField("__$allRuleArray").get(this);
         allRulegroups = (Rulegroup[]) bEntityClass.getDeclaredField("__$allRulegroupArray").get(this);
      } catch (IllegalArgumentException | IllegalAccessException | ClassNotFoundException | NoSuchFieldException
            | SecurityException e) {
         throw new RuntimeError("Error in addRuleAndRulegroupWMEs() for behaving entity name " + getBehavingEntityShortName() + " "
               + e.toString());
      }

      for (Rule rule : allRules) {
         addWME(rule);
      }

      for (Rulegroup rulegroup : allRulegroups) {
         addWME(rulegroup);
      }
   }

   /**
    * Runs a single rule represented by a Rule WME
    * 
    * @param rule The rule to run.
    * Wrapper which keeps all memory params default (null
    */
   public void runRule(Rule rule) {
      runRule(rule.id);
   }

   /**
    * @param ruleId the id of the rule to run
    * Wrapper which keeps all memory params default (null)
    */
   public void runRule(int ruleId) {
      runRuleExecute(ruleId, null, null, null, null, null, null);
   }
   
   /* Wrapper without enclosing behavior args */
   public void runRule(Rule rule, WorkingMemorySet searchMem, WorkingMemorySet bindMem, WorkingMemory outMem,
                       WorkingMemory touchedMem, WorkingMemory modifiedMem) {
      runRule(rule, searchMem, bindMem, outMem, touchedMem, modifiedMem, null);
   }
   
   void runRule(Rule rule, WorkingMemorySet searchMem, WorkingMemorySet bindMem, WorkingMemory outMem,
                       WorkingMemory touchedMem, WorkingMemory modifiedMem, Object[] enclosingBehaviorArgs) {
      /* searchMem defaults to this entity's workingMemory */
      if (searchMem == null) {
         searchMem = new WorkingMemorySet(workingMemory);
      }
      /* bindMem defaults to searchMem */
      if (bindMem == null) {
         bindMem = searchMem;
      }
      /* outMem defaults to this entity's workingMemory */
      if (outMem == null) {
         outMem = workingMemory;
      }
      TrackedWorkingMemory touchedMemTracking = null;
      if (touchedMem != null) {
         touchedMemTracking = new TrackedWorkingMemory(touchedMem);
      }
      TrackedWorkingMemory modifiedMemTracking = null;
      if (modifiedMem != null) {
         modifiedMemTracking = new TrackedWorkingMemory(modifiedMem);
      }
      runRuleExecute(rule.getId(), searchMem, bindMem, outMem, touchedMemTracking, modifiedMemTracking, enclosingBehaviorArgs);
   }

   /**
    * Private helper method for executing rules - utilizes tracked working memories - called by runRule and runRulegroup
    */
   private void runRuleExecute(int ruleId, WorkingMemorySet searchMem, WorkingMemorySet bindMem, WorkingMemory outMem,
                       TrackedWorkingMemory touchedMemTracking, TrackedWorkingMemory modifiedMemTracking, Object[] enclosingBehviorArgs) {
      String beName = BehavingEntity.getBehavingEntity().getBehavingEntityShortName();
      @SuppressWarnings("rawtypes")
      Class[] types = {
         Object[].class,
         Map.class,
         WorkingMemorySet.class,
         WorkingMemorySet.class,
         WorkingMemory.class,
         TrackedWorkingMemory.class,
         TrackedWorkingMemory.class,
         BehavingEntity.class
      };

       try {
         Class<?> ruleClass = Class.forName(packagename + "." + beName + "_RuleLibrary");
         Method ruleFactoryMethod = ruleClass.getMethod("ruleFactory" + ruleId, types);
         ruleFactoryMethod.invoke(null, enclosingBehviorArgs, null, searchMem, bindMem, outMem, touchedMemTracking, modifiedMemTracking, this);
      } catch (ClassNotFoundException e) {
         System.err.println("The class for this agent was not found. package: " + packagename + " behavingEntity name: " + beName
               + ". Error message: " + e.getMessage());
         e.printStackTrace();
      } catch (NoSuchMethodException e) {
         System.err.println("The ruleFactory method was not found. package: " + "ruleFactory" + ruleId + "(" + types
               + "). Error message: " + e.getMessage());
         e.printStackTrace();
      } catch (SecurityException e) {
         System.err.println("Security exception when accessing ruleFactory method. package: " + "ruleFactory" + ruleId + "("
               + types + "). Error message: " + e.getMessage());
         e.printStackTrace();
      } catch (IllegalAccessException e) {
         System.err.println("The ruleFactory method was access illegally. package: " + "ruleFactory" + ruleId + "(" + types
               + "). Error message: " + e.getMessage());
         e.printStackTrace();
      } catch (IllegalArgumentException e) {
         System.err.println("The ruleFactory method was accessed with illegal arguments. package: " + "ruleFactory" + ruleId + "("
               + types + "). Error message: " + e.getMessage());
         e.printStackTrace();
      } catch (InvocationTargetException e) {
         System.err.println("Invocation exeption when executing ruleFactory method. package: " + "ruleFactory" + ruleId + "("
               + types + "). Error message: " + e.getMessage());
         e.printStackTrace();
      }
   }

   /**
    * Runs a rulegroup by name, if a match exists in Working Memory
    * 
    * @param rulegroupName The rulegroup name
    */
   public void runRulegroupViaWMSearch(String rulegroupName, WorkingMemorySet searchMem, WorkingMemorySet bindMem, WorkingMemory outMem,
                                       WorkingMemory touchedMem, WorkingMemory modifiedMem) {
      List<Rulegroup> rulegroups = lookupWME(Rulegroup.class);
      for (Rulegroup rulegroup : rulegroups) {
         if (rulegroup.getName().equals(rulegroupName)) {
            runRulegroup(rulegroup, searchMem, bindMem, outMem,touchedMem, modifiedMem, null);
            return;
         }
      }
   }

   /**
    * Runs all rules in the Rulegroup parameter.
    * Wrapper which keeps all mem params default (null)
    * 
    * @param rulegroup A collection of rules to run.
    */
   public void runRulegroup(Rulegroup rulegroup) {
      runRulegroup(rulegroup, null, null, null, null, null, null);
   }
   
   /* Wrapper with no enclosing behavior args */
   public void runRulegroup(Rulegroup rulegroup, WorkingMemorySet searchMem, WorkingMemorySet bindMem, WorkingMemory outMem,
                            WorkingMemory touchedMem, WorkingMemory modifiedMem) {
      runRulegroup(rulegroup, searchMem, bindMem, outMem, touchedMem, modifiedMem, null);
   }
   
   public void runRulegroup(Rulegroup rulegroup, WorkingMemorySet searchMem, WorkingMemorySet bindMem, WorkingMemory outMem,
                             WorkingMemory touchedMem, WorkingMemory modifiedMem, Object[] enclosingBehaviorArgs) {
      /* searchMem defaults to this entity's workingMemory */
      if (searchMem == null) {
         searchMem = new WorkingMemorySet(workingMemory);
      }
      /* bindMem defaults to searchMem */
      if (bindMem == null) {
         bindMem = searchMem;
      }
      /* outMem defaults to this entity's workingMemory */
      if (outMem == null) {
         outMem = workingMemory;
      }
      TrackedWorkingMemory touchedMemTracking = null;
      if (touchedMem != null) {
         touchedMemTracking = new TrackedWorkingMemory(touchedMem);
      }
      TrackedWorkingMemory modifiedMemTracking = null;
      if (modifiedMem != null) {
         modifiedMemTracking = new TrackedWorkingMemory(modifiedMem);
      }
      for(int ruleID : rulegroup) {
         runRuleExecute(ruleID, searchMem, bindMem, outMem, touchedMemTracking, modifiedMemTracking, enclosingBehaviorArgs);
      }
   }
   

   void runSensors(List<SensorActivation> sensors, boolean isContinuous) {
      Iterator<SensorActivation> sensorIterator = sensors.iterator();
      SensorActivation activationRecord;
      Sensor s;
      Object[] args;

      List<SensorThread> sensorThreadList = new LinkedList<>();

      while (sensorIterator.hasNext()) {
         activationRecord = sensorIterator.next();
         s = activationRecord.activeSensor;
         args = activationRecord.arguments;
         if (s.canBeParallel()) {
            // Create a parallel thread to run the sensor
            SensorThread st = new SensorThread(s, args, isContinuous);
            st.setPriority(Thread.NORM_PRIORITY); // set priority in case
            // priority of parent
            // has been changed
            sensorThreadList.add(st);
            st.start();
         } else {

            /**
             * Note: Ben Weber, 10-20-2009
             * 
             * A race condition with asynchronous serial sensors was discovered
             * in Spring 2007. There did not appear to be any easy work-around,
             * so Michael advised throwing an exception if this situation
             * arises.
             */
            if (this.asynchronousSenseCycle) {
               throw new AblRuntimeError("Asynchronous serial sensors not currently supported");
            }

            // Run the sensor in series
            if (isContinuous) {
               s.senseContinuous(args);
            } else {
               s.senseOneShot(args);
            }
         }
      }

      // If some sensors have been run in parallel, wait for all the parallel
      // threads to have finished.
      if (!sensorThreadList.isEmpty()) {
         for (Object aSensorThreadList : sensorThreadList) {
            try {
               ((SensorThread) aSensorThreadList).join();
            } catch (InterruptedException e) {
               throw new AblRuntimeError("Sensor thread interrupted");
            }
         }
      }
   }

   // Runs the success conditions and modifies the ABT. Returns true if a
   // success conditions fires (becomes true).
   private boolean runSuccessConditions(boolean runSensedConditions) {
      Iterator<Behavior> successConditionIterator;

      if (runSensedConditions) {
         successConditionIterator = successConditionBehaviorsSensing.iterator();
      } else {
         successConditionIterator = successConditionBehaviorsNoSensing.iterator();
      }
      while (successConditionIterator.hasNext()) {
         final Behavior successConditionBehavior = successConditionIterator.next();
         if (successConditionBehavior.successCondition()) {
            successConditionBehavior.succeedBehavior();
            runSuccessConditions(runSensedConditions);
            return true;
         }
      }
      return false;
   }

   /*
    * Runs the successs tests and modifies the ABT. Returns true if a
    * succcessTest() fired, false otherwise.
    */
   private boolean runSuccessTests(boolean runSensedConditions) {

      Iterator<Step> successStepIterator;
      if (runSensedConditions) {
         successStepIterator = successTestStepsSensing.iterator();
      } else {
         successStepIterator = successTestStepsNoSensing.iterator();
      }

      Step successStep;
      while (successStepIterator.hasNext()) {
         successStep = successStepIterator.next();
         if (successStep.successTest()) {
            /*
             * If a single success test succeeds, modify the tree and exit. If
             * multiple success tests are true, the ABT modifications from these
             * success tests will be processed on successive calls to behave().
             */
            successStep.succeedStep();
            runSuccessTests(runSensedConditions);
            return true;
         }
      }
      return false;
   }

   // If the behaving entity is running with the debugger, set the
   // trace-to-buffer status
   public void setTraceToBuffer(boolean b) {
      if (debugLevel == GUI_DEBUGGER) {
         debuggerGUI.setTraceToBuffer(b);
      }
   }

   // If the behaving entity is running with the debugger, set the
   // trace-to-screen status
   public void setTraceToScreen(boolean b) {
      if (debugLevel == GUI_DEBUGGER) {
         debuggerGUI.setTraceToScreen(b);
      }
   }

   /**
    * Note: Ben Weber
    * 
    * Enable synchronous sensors.
    */
   public void setUseSynchrousSensors() {
      asynchronousSenseCycle = false;
   }

   public void startBehaving() {
      startBehaving(1);
   }

   /**
    * Start the top level execution loop for this behaving entity.
    * (Backward-compatible version that uses default value for
    * showBehaviorLauncherGui.)
    * 
    * @param waitMillis how long to yield between active behavior steps and
    *        sensor cycles, or {@link #UNYIELDING} if no yielding at all.
    */
   public void startBehaving(final long waitMillis) {
      startBehaving(waitMillis, SHOW_BEHAVIOR_LAUNCHER_GUI_DEFAULT);
   }

   /**
    * Start the top level execution loop for this behaving entity.
    * 
    * @param waitMillis how long to yield between active behavior steps and
    *        sensor cycles, or {@link #UNYIELDING} if no yielding at all.
    * @param showBehaviorLauncherGui whether to show the developer behavior
    *        selection GUI.
    */
   public void startBehaving(long waitMillis, boolean showBehaviorLauncherGui) {
      entity.set(this);
      synchronized (paused) {
         if (paused.isEnabled()) {
            /* This should mean we're reloading from a saved state */
            unpause();
         } else {
            ABT.initRootBehavior();
         }
      }
      decisionCycleThread = Thread.currentThread();
      
      // Must wait for the constructor to finish for the args[] to be set
      initializeBehaviorListeners(); 

      if (showBehaviorLauncherGui) {
         behaviorTestBedGUI = new debug.BehaviorTestBed(this);
      }

      if (asynchronousSenseCycle) {
         new SenseCycleThread(waitMillis).start(); // start the parallel sense
                                                   // cycle
      }

      // Add the rules and rulegroups to working memory
      this.addRuleAndRulegroupWMEs();

      shutdownHook = new ShutdownHook();
      Runtime.getRuntime().addShutdownHook(shutdownHook);
      
      

      while (behaving.isEnabled()) {

         /* If we're paused, just sleep a bit and check again... */
         if (isPaused()) {
            try {
               shutdownHook.shutdownMessage = getBehavingEntityShortName() + " was waiting because the agent was paused";
               Thread.sleep(SLEEP_DURATION_BETWEEN_PAUSE_CHECKS);
               continue;
            } catch (InterruptedException exception) {
               // Don't care
            }
         }

         behave();
         if (waitMillis != UNYIELDING) {
            synchronized (behaving) {
               try {
                  // wait for explicit wakeup but no more than waitMillis
                  behaving.wait(waitMillis);
               } catch (InterruptedException e) {
                  // proceed
               }
            }
         }
      }

      /**
       * Note: Ben Weber
       * 
       * Wake of the sense thread so it knows to exit. If this is not called, it
       * is possible that the sensor thread will never exit.
       */
      synchronized (this.activeSensors) {
         this.activeSensors.notifyAll();
      }
   }

   // Starts WME reflection of the ABT. Should be called with the
   // RootCollectionBehavior in the constructor
   // of the concrete behaving entity class.
   protected void startWMEReflection(CollectionBehavior b) {
      final CollectionBehaviorWME root = new CollectionBehaviorWME(b, null);
      addWME(root);
      rootCollectionBehaviorWME = root;
   }

   /**
    * Note: Ben Weber
    * 
    * Tells this class to stop behavior. This causes the main loop to break out
    * and then notifies the asynchronous thread to break out as well.
    */
   public void stopBehaving() {
      synchronized (behaving) {
         behaving.setEnabled(false);
      }
   }

   // Suspends an ExecutableStep
   void suspendStep(ExecutableStep s) {
      boolean inFringe;

      // Remove the success test. Don't want it to be tested while we're
      // suspended.
      removeSuccessTest(s);

      if (s.getStepType() == Step.GOAL) {
         inFringe = !((GoalStep) s).isExpanded();
      } else {
         inFringe = !s.isExecuting();
      }

      if (!inFringe) {
         // The step is not in leaf (or atomic) steps. Remove from appropriate
         // executing sets.
         removeExecutingStep(s);
         if (s.getStepType() == Step.PRIMITIVE) {
            executingPrimitiveSteps.remove(s);
         }
      } else {
         // Step is in fringe, so it's a leaf (or atomic) step.
         if (s.getIsAtomic()) {
            atomicSteps.remove(s);
         } else {
            leafSteps.remove(s);
         }
      }
   }

   /**
    * Suspends WaitSteps. For WaitSteps, suspending only involves removing the
    * success test.
    */
   void suspendStep(WaitStep s) {
      removeSuccessTest(s);
   }

   // Called when entry negotiation is finished. Clears the JointGoalNegotiator
   // from currentEntryNegotiators.
   public void terminateEntryNegotiation(Long uniqueEntryNegotiationID) {
      synchronized (currentEntryNegotiators) {
         assert currentEntryNegotiators.get(uniqueEntryNegotiationID) != null;
         currentEntryNegotiators.remove(uniqueEntryNegotiationID);
      }
   }

   @Override
   public String toString() {
      return getBehavingEntityShortName();
   }

   void traceAblExecutionEvent(int type, __BehaviorDesc source, Object obj, int nestLevel, int behaviorID) {
      debuggerGUI.traceAblExecutionEvent(type, source, obj, nestLevel, behaviorID);
   }

   void traceAblExecutionEvent(int type, Step source, Object obj, int nestLevel, int behaviorID) {
      debuggerGUI.traceAblExecutionEvent(type, source, obj, nestLevel, behaviorID);
   }

   // Given a behavior sig, adds the ids of all behaviors with this sig to the
   // set of traced behaviors.
   void traceBehaviorSignature(String behaviorSig) {
      // grab a list containing the concatentation of all individual and joint
      // behaviors satisfying the signature
      List<__BehaviorDesc> behaviorList = individualBehaviorLibrary.getAnyMatchingBehaviors(behaviorSig);
      behaviorList.addAll(jointBehaviorLibrary.getAnyMatchingBehaviors(behaviorSig));

      for (Object aBehaviorList : behaviorList) {
         __BehaviorDesc behDesc = (__BehaviorDesc) aBehaviorList;
         debuggerGUI.traceBehavior(behDesc.behaviorID);
      }
   }

   /**
    * Note: Ben Weber
    * 
    * Un-pauses ABL
    */
   public void unpause() {
      synchronized (paused) {
         boolean oldValue = paused.isEnabled();
         paused.setEnabled(false);
         pcs.firePropertyChange(PAUSED_PROPERTY, oldValue, false);
      }
   }

   // unregister a negotiation thread = package access
   void unregisterNegotiationThread(JointGoalNegotiationThread t) {
      assert t != null;
      activeNegotiationThreads.remove(t);
   }

   // Unsuspends an executable step.
   void unsuspendStep(ExecutableStep s) {
      if (s.getStepType() == Step.GOAL && ((GoalStep) s).isExpanded()) {
         // The suspended goal step has been expanded; add it back to the
         // executing set
         Set<Step> stepSet = executingSteps.get(s.getName());
         if (stepSet != null) {
            stepSet.add(s);
         } else {
            stepSet = new HashSet<>();
            stepSet.add(s);
            executingSteps.put(s.getName(), stepSet);
         }
      } else {
         // The step is either a primitive step or an unexpanded goal step.
         // Add it back to leafSteps.
         if (s.getIsAtomic()) {
            atomicSteps.add(s);
         } else {
            leafSteps.add(s);
         }
      }

      // Reactivate any success test associated with the step.
      addSuccessTest(s);
   }

   /**
    * Unsuspends a WaitStep. For WaitSteps, unsuspending only involves
    * reactivating the success test.
    */
   void unsuspendStep(WaitStep s) {
      addSuccessTest(s);
   }

   // Given a behavior sig, removes the ids of all behaviors with this sig from
   // the set of traced behaviors.
   void untraceBehaviorSignature(String behaviorSig) {
      // grab a list containing the concatenation of all individual and joint
      // behaviors satisfying the signature
      List<__BehaviorDesc> behaviorList = individualBehaviorLibrary.getAnyMatchingBehaviors(behaviorSig);
      behaviorList.addAll(jointBehaviorLibrary.getAnyMatchingBehaviors(behaviorSig));

      for (Object aBehaviorList : behaviorList) {
         __BehaviorDesc behDesc = (__BehaviorDesc) aBehaviorList;
         debuggerGUI.untraceBehavior(behDesc.behaviorID);
      }
   }

   /**
    * @return true if the signature matches an individual or joint behavior
    * @param the signature to check
    */
   public boolean isValidGoalSignature(String signature) {
      return isValidIndividualGoalSignature(signature) || isValidJointGoalSignature(signature);
   }

   /**
    * @return true if the signature matches an individual behavior
    * @param the signature to check
    */
   public boolean isValidIndividualGoalSignature(String signature) {
      return individualBehaviorLibrary.containsBehaviorSignature(signature);
   }

   /**
    * @return true if the signature matches a joint behavior
    * @param the signature to check
    */
   public boolean isValidJointGoalSignature(String signature) {
      return jointBehaviorLibrary.containsBehaviorSignature(signature);
   }

   public static boolean constantTrue(boolean b) {
      return true;
   }

   public static boolean constantTrue(byte b) {
      return true;
   }

   public static boolean constantTrue(char c) {
      return true;
   }

   public static boolean constantTrue(double d) {
      return true;
   }

   public static boolean constantTrue(float f) {
      return true;
   }

   /*
    * constantTrue() returns true regardless of the value of the argument. Used
    * to force assignment in test expressions.
    */
   public static boolean constantTrue(int i) {
      return true;
   }

   public static boolean constantTrue(long l) {
      return true;
   }

   public static boolean constantTrue(Object o) {
      return true;
   }

   public static boolean constantTrue(short s) {
      return true;
   }

   // Returns a reference to the behaving entity containing a behavior.
   public static BehavingEntity getBehavingEntity() {
      return entity.get();
   }

   // Returns a reference to the named behaving entity. Currently assumes that
   // all entities live in the same
   // process on the same machine.
   // fixme: change this to support fully distributed behaving entities
   public static BehavingEntity getBehavingEntity(String name) {
      synchronized (entityTable) {
         BehavingEntity specifiedEntity = entityTable.get(name);
         if (specifiedEntity == null) {
            throw new AblRuntimeError("No behaving entity found for entity name " + name);
         } else {
            return specifiedEntity;
         }
      }
   }

   // Debug support - given a behavior, walks upwards to the root collection
   // behavior, printing the nodes
   static void printABTBranchUpwards(Behavior b) {
      if (b != null) {
         System.err.println(b);
         Step s = b.getParent();
         while (s != null) {
            System.err.println(s);
            b = s.getParent();
            System.err.println(b);
            s = b.getParent();
         }
      }
   }

   // Debug support - given a step, walks upwards to the root collection
   // behavior, printing the nodes
   static void printABTBranchUpwards(Step s) {
      while (s != null) {
         System.err.println(s);
         final Behavior b = s.getParent();
         System.err.println(b);
         s = b.getParent();
      }
   }

   // Registers a behaving entity with a name.
   // fixme: doesn't check for duplicate names
   protected static void registerEntity(String name, BehavingEntity entityParam) {
      synchronized (entityTable) {
         entityTable.put(name, entityParam);
      }
   }

   // A println which returns true; useful for debugging preconditions
   public static boolean truePrintln(String s) {
      System.out.println(s);
      return true;
   }

   // TimeCheckThread makes sure that no negotiation thread blocks the
   // decision cycle for more than a second.
   // The offending JointGoalNegotiationThread is interrupted and spits out
   // diagnostic information.
   private final class TimeCheckThread
         extends Thread {
      JointGoalNegotiationThread monitoredThread;

      TimeCheckThread(JointGoalNegotiationThread t) {
         super(timeCheckThreads, null, "tct"); // Add the new
         // TimeCheckThread to
         // the TimeCheckThreads
         // group.
         monitoredThread = t;
      }

      @Override
      public void run() {
         try {
            sleep(1000);
            System.err.println("WARNING: a negotiation thread took longer than a second to execute. The thread was interrupted.");
            monitoredThread.interrupt();
         } catch (InterruptedException e) {
         } // Do nothing - thread will be interrupted after negotiation
           // thread returns
      }
   }

   // Thread class for running sensors.
   private final class SensorThread
         extends Thread {
      Sensor threadSensor;

      Object[] threadArgs;

      boolean threadIsContinuous;

      SensorThread(Sensor sToSet, Object[] argsToSet, boolean isContinuousToSet) {
         threadSensor = sToSet;
         threadArgs = argsToSet;
         threadIsContinuous = isContinuousToSet;
      }

      @Override
      public void run() {
         if (threadIsContinuous) {
            threadSensor.senseContinuous(threadArgs);
         } else {
            threadSensor.senseOneShot(threadArgs);
         }
      }
   }

   // thread class for the sense cycle
   private final class SenseCycleThread
         extends Thread {
      private final long waitMillis;

      public SenseCycleThread(long waitMillis) {
         this.waitMillis = waitMillis;
      }

      @Override
      public void run() {
         while (behaving.isEnabled()) {
            activeSensors.sense();
            if (waitMillis != UNYIELDING) {
               synchronized (behaving) {
                  try {
                     behaving.wait(waitMillis);
                  } catch (InterruptedException e) {
                     // proceed
                  }
               }
            }
         }
      }
   }

   // Manages changes to active sensors and the sensing of these active sensors
   /**
    * @author Michael Mateas
    * 
    */
   private class ActiveContinuousSensors
         implements Serializable {
      // Set of sensor activations associated with currently active
      // context conditions and success tests.
      private List<SensorActivation> newActiveSensors = new LinkedList<>();

      // Adds a sensor activation to the set of current sensor
      // activations. Called by addBehavior() for those behaviors
      // with context conditions which return a non-null value from
      // getContextConditionSensorActivations() and those behaviors
      // with success conditions which return a non-null value from
      // getSuccessCondtionSensorActivations(), and called by
      // addStep() for those steps with success tests which return a
      // non-null value from getSuccessTestSensorActivations().
      synchronized void activateSensor(SensorActivation s) {
         SensorActivation currentSensor;
         for (Object sensor : newActiveSensors) {
            currentSensor = (SensorActivation) sensor;

            if (s.equals(currentSensor)) {
               /*
                * This SensorActivation (combination of sensor and arguments)
                * has previously been registered as an active sensor. Increment
                * the reference count.
                */

               currentSensor.referenceCount++;
               return;
            }
         }
         // If got this far, this SensorActivation (combination of
         // sensor and arguments) has not previously been
         // registered as an active sensor. Add it to the set of
         // active sensors.

         newActiveSensors.add(s);
         s.activeSensor.initializeContinuous(s.arguments);
         this.notify();
      }

      synchronized void activateSensors(SensorActivation[] activations) {
         if (activations != null) {
            for (SensorActivation activation : activations) {
               activateSensor(activation);
            }
         }
      }

      /**
       * Removes a sensor activation from the set of current sensor activations.
       * Called by removeBehavior() for those behaviors with context conditions
       * which return a non-null value from
       * getContextConditionSensorActivations() or a non-null value from
       * getSuccessConditionSensorActivations() and called by removeStep() for
       * those steps with success tests which return a non-null value from
       * getSuccessTestSensorActivations().
       */
      synchronized void deactivateSensor(SensorActivation s) {
         Iterator<SensorActivation> iter = newActiveSensors.iterator();
         SensorActivation currentSensor;
         while (iter.hasNext()) {
            currentSensor = iter.next();
            if (s.equals(currentSensor)) {
               // An equivalent SensorActivation was found. If
               // the reference count would go to zero, remove
               // the sensor, otherwise decrement the reference
               // count.
               if (currentSensor.referenceCount == 1) {
                  iter.remove();
               } else {
                  currentSensor.referenceCount--;
               }
               return;
            }
         }
         // If got this far, then deactiveSensor() was called with
         // a SensorActivaiton which is not currently in the set of
         // active sensors.
      }

      synchronized void deactivateSensors(SensorActivation[] activations) {
         if (activations != null) {
            for (SensorActivation activation : activations) {
               deactivateSensor(activation);
            }
         }
      }

      synchronized void sense() {
         if (!newActiveSensors.isEmpty()) {
            runSensors(newActiveSensors, true);
            senseMonitor.setSensedConditionsReadyToRun(true);
         } else {
            if (asynchronousSenseCycle) {
               // we need to wait for sensors to appear in the asynchronous
               // case,
               // otherwise we would spin if we didn't wait
               try {
                  this.wait();
               } // Wait for sensors to be added to activate sensors
               catch (InterruptedException e) {
                  throw new RuntimeError("Sense cycle interrupted");
               }
            }
         }
      }
   }

   public class BehaviorLibrary
         implements Serializable {
      // Map behaviorNames; // Keys are signatures, values are lists of

      // concrete behavior class names.

      /**
       * Hash table of all behaviors. Used by the behavior arbitration mechanism
       * to choose a behavior for a goal. Keys are behavior signitures; values
       * are concrete behavior classes. The hash table is initialized and set to
       * the appropriate behaviors in the constructor of the concrete
       * BehavingEntity.
       */
      Map<String, List<__BehaviorDesc>> behaviors;
      
      // Key: behaviorID's, value: list of signatures that behavior calls as subgoals
      // Used for Dependency Tree
      Map<Integer, List<String>> goalStepMap;

      public BehaviorLibrary(int initialSize) {
         behaviors = new HashMap<>(initialSize);
         goalStepMap = new HashMap<>(initialSize);
      }

      // Returns a set of registered behavior signatures
      private synchronized Set<String> getRegisteredBehaviors() {
         return new HashSet<>(behaviors.keySet());
      }
      
      public synchronized Map<String, List<__BehaviorDesc>> getBehaviorMap(){
         return behaviors;
      }
      
      public synchronized Map<Integer, List<String>> getGoalStepMap(){
         return goalStepMap;
      }

      /** 
       * @return Given a signature, returns a List of __BehaviorDesc 
       * @param signature the signature
       */
      public synchronized List<__BehaviorDesc> lookupBehavior(String signature) {
         List<__BehaviorDesc> behaviorDescList = behaviors.get(signature);
         if (behaviorDescList == null) {
            // no behaviors with this signature have been added yet.
            throw new AblRuntimeError("\n\nERROR: No matching behavior found for signature: " + signature + "\n");
         } else {
            return new ArrayList<>(behaviorDescList);
         }
      }
      
      /** 
       * @return Given a signature, returns a List of __BehaviorDesc or any empty list if no matches exist
       * @param signature the signature
       */
      public synchronized List<__BehaviorDesc> getAnyMatchingBehaviors(String signature) {
         try {
            return lookupBehavior(signature);
         } catch (AblRuntimeError e){
            return new ArrayList<>();
         }
      }

      /**
       * @return true if the library contains a behavior that matches this
       *         signature
       * @param signature The signature to check
       */
      boolean containsBehaviorSignature(String signature) {
         return (behaviors.get(signature) != null);
      }

      /*
       * Modified by Gillian Smith, 07-27-10 to support inheritance.
       * __BehaviorDesc have multiple signatures associated with them. This
       * method iterates over all the signatures for a behavior and adds the
       * behavior to that entry in the behaviors Map.
       * 
       * Modified by April Grow 11-18-14 to support DependencyTree visualization
       * analysisMethod takes a behaviorID and returns the list of goalsteps called by that behavior
       */
      public synchronized void registerBehavior(__BehaviorDesc behDesc, Method analysisMethod) {
         // System.err.println("Registering " + behDesc.signature);
         for (String sig : behDesc.signatures) {
            // System.err.println("\t" + sig);
            List<__BehaviorDesc> behaviorDescList = behaviors.get(sig);

            if (behaviorDescList == null) {
               // No behavior with this signature has yet been
               // registered. Create the list, add behavior
               // name to it, and hash the list under the signature.
               behaviorDescList = new ArrayList<>();
               behaviorDescList.add(behDesc);
               if (debugLevel == GUI_DEBUGGER && sig.equals(behDesc.signature)) {
                  behDesc.uniqueName = behDesc.signature.substring(0, behDesc.signature.indexOf('(')) + "_1";
               }

               behaviors.put(sig, behaviorDescList);
            } else {
               // Behavior with this signature has previously been registered.
               // Add the behavior class name to the list.
               behaviorDescList.add(behDesc);
               if (debugLevel == GUI_DEBUGGER && sig.equals(behDesc.signature)) {
                  behDesc.uniqueName =
                        behDesc.signature.substring(0, behDesc.signature.indexOf('(')) + "_" + behaviorDescList.size();
               }
            }
         }
         // Add the behavior's subgoal links to the goalStepMap. Executed once per id.
         try {
            //System.out.println("Testing behaviorID " + behDesc.behaviorID);
            final Object[] args = {behDesc.behaviorID};
            List<String> temp = (List<String>)analysisMethod.invoke(null, args);
            //System.out.println("Temp list I made " + temp);
            goalStepMap.put(behDesc.behaviorID, temp);
         } catch (InvocationTargetException e) {
            throw new AblRuntimeError("InvocationTargetException executing registerBehavior " + behDesc.signature + ". Error "
                  + e.getCause(), e.getCause());
         } catch (Exception e) {
            throw new AblRuntimeError("Error executing registerBehavior for " + behDesc.signature, e);
         }
      }
   }

   private class SensedConditionMonitor
         implements Serializable {
      private boolean ready;

      synchronized boolean sensedConditionsReadyToRun() {
         boolean readyTemp = ready;
         ready = false;
         return readyTemp;
      }

      synchronized void setSensedConditionsReadyToRun(boolean b) {
         ready = b;
      }
   }

   // for debugging - shutdown hook prints out information about where we were
   // in the decision cycle.
   class ShutdownHook
         extends Thread {

      public String shutdownMessage; // Set by behave()

      @Override
      public void run() {
         System.err.println(shutdownMessage);
         printNegotiationThreads();
         System.err.flush(); // Flush the err PrintStream after writing
         // shutdown info.
      }

   }
}
