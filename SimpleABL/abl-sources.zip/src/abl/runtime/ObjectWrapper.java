// Wraps object references which are bound in preconditions and passed to behaviors.
// Since a Map is used to store references, null values must be wrapped - given this, it's easier just to wrap all object references

package abl.runtime;

public class ObjectWrapper {

   private Object o;

   public ObjectWrapper(Object o) {
      this.o = o;
   }

   public Object objectValue() {
      return o;
   }
}
