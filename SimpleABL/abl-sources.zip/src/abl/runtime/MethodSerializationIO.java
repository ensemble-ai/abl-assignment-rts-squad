/**
 * Copyright 2013 UCSC
 */
package abl.runtime;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;

class MethodSerializationIO {
   
   void writeMethod(Method m, ObjectOutputStream out) throws IOException  {
      out.writeObject(new MethodDescriptor(m));
   }
   
   Method readMethod(ObjectInputStream in) throws IOException {
      try {
         MethodDescriptor descriptor = (MethodDescriptor) in.readObject();
         return descriptor.getMethod();
      } catch (ClassNotFoundException e) {
         throw new IOException(e);
      }
   }
   
   static final class MethodDescriptor
         implements Serializable {
      private String classname;
      private String methodname;
      private Class<?>[] params;
      
      MethodDescriptor(Method m) {
         if (m != null) {
            this.classname = m.getDeclaringClass().getCanonicalName();
            this.methodname = m.getName();
            params = m.getParameterTypes();
         }
      }
      
      Method getMethod() throws ClassNotFoundException, IOException {
         if (classname == null || params == null || methodname == null) {
            return null;
         }
         try {
            Class<?> klass = Class.forName(classname);
            return klass.getMethod(methodname, params);
         } catch (NoSuchMethodException | SecurityException e) {
            throw new IOException(e);
         }
      }
      
   }
}
