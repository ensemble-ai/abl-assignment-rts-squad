/**
 * Copyright 2015 UCSC
 */
package abl.runtime;

import wm.ScorableWME;

/**
 * Interface for steps which can be dynamically constructed and spawned onto behaviors
 */
public abstract class DynamicSpawnWME extends ScorableWME {
   /**
    * Spawn the step at the root
    */
   public void spawn() {
      MultiStepBehaviorWME rootBehaviorWME = (MultiStepBehaviorWME) BehavingEntity.getBehavingEntity().getRootCollectionBehavior().getReflectionWME();
      spawn(rootBehaviorWME);
   }
   
   /**
    * Spawn the step at the behavior reflected by the MultiStepBeahviorWME
    */
   public void spawn(MultiStepBehaviorWME spawnTargetRootBehaviorWME) {
      MultiStepBehavior spawnTargetRootBehavior = null;
      if (spawnTargetRootBehaviorWME != null) {
         spawnTargetRootBehavior = (MultiStepBehavior) spawnTargetRootBehaviorWME.getBehavior();
      }
      spawn(spawnTargetRootBehavior);
   }
   
   /**
    * Spawn the step at the behavior
    */
   public abstract void spawn(MultiStepBehavior spawnTargetRootBehavior);
}
