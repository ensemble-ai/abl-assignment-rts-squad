package abl.runtime;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class ConditionalStep
      extends GoalStep {

   private String ifBehaviorSignature;
   private String elseBehaviorSignature;
   // The conditional test method to invoke
   transient Method conditionalTest;
   // The conditional test sensor factory to use for this step -- null if no
   // sensors
   transient Method conditionalTestSensorFactory;

   // Constructor for ConditionalStep calls the super constructor.
   public ConditionalStep(int stepID, Method arg_stepFactory, Behavior arg_parent, boolean arg_persistent, boolean arg_persistentWhenSucceeds,
                          boolean arg_persistentWhenFails, boolean arg_ignoreFailure, boolean arg_effectOnly,
                          boolean arg_teamEffectOnly, short arg_priority, short arg_priorityModifier, boolean arg_post,
                          String arg_postMemory, Method arg_execute, Method arg_successTest, Method arg_successTestSensorFactory,
                          AblNamedPropertySupport arg_propertyTable, Method arg_conditionalTest,
                          Method arg_conditionalTestSensorFactory, String ifBehaviorSignature, String elseBehaviorSignature) {
      super(stepID,
            arg_stepFactory,
            arg_parent,
            arg_persistent,
            arg_persistentWhenSucceeds,
            arg_persistentWhenFails,
            arg_ignoreFailure,
            arg_effectOnly,
            arg_teamEffectOnly,
            arg_priority,
            arg_priorityModifier,
            arg_post,
            arg_postMemory,
            arg_execute,
            arg_successTest,
            arg_successTestSensorFactory,
            arg_propertyTable,
            // Synthesize Conditional step name
            arg_parent + "ConditionalStep" + stepID + "_if_" + ifBehaviorSignature + "_else_" + elseBehaviorSignature,
            CONDITIONAL,
            // Currently not supporting conflict registration for conditional steps
            new String[0]);
      this.conditionalTest = arg_conditionalTest;
      this.conditionalTestSensorFactory = arg_conditionalTestSensorFactory;
      this.ifBehaviorSignature = ifBehaviorSignature;
      this.elseBehaviorSignature = elseBehaviorSignature;
   }

   @Override
   void execute() {
      if (!isSuspended()) {
         // Propagate failure up immediately if any child behavior fails instead of searching for other matching signatures
         if (!failedBehaviors.isEmpty()) {
            failStep();
            return;
         }
         /*
          * If the conditional test is true, add the ifBehavior as a child,
          * otherwise add the elseBehavior or just succeed if no else step was
          * specified
          */
         if (evaluateConditionalTest()) {
            addBranchBehavior(ifBehaviorSignature);
         } else if (elseBehaviorSignature != null) {
            addBranchBehavior(elseBehaviorSignature);
         } else {
            succeedStep();
         }
      }
   }

   /* Add the corresponding branch behavior which will have a unique signature */
   private void addBranchBehavior(String branchBehaviorSignature) {
      // The args array to pass - just taken from the parent since this will always be nested scope
      Object[] args = parent.getBehaviorVariableFrame();
      Behavior beh = BehavingEntity.getBehavingEntity().getUniqueSynthesizedBehavior(branchBehaviorSignature, this, args);
      addChild(beh);
      executeBookkeeping();
   }

   private boolean evaluateConditionalTest() {
      // Before evaluating the conditional test, update any sensors referenced
      // in the test
      runConditionalTestSensors();

      Object[] args = {
         stepID,
         parent.getBehaviorVariableFrame(),
         BehavingEntity.getBehavingEntity()
      };
      try {
         return (Boolean) conditionalTest.invoke(null, args);
      } catch (Exception e) {
         throw new AblRuntimeError("Error invoking conditional test for step " + name + " in parent " + parent, e);
      }
   }

   /* If any sensors are referenced in the test, run them first */
   private void runConditionalTestSensors() {
      if (conditionalTestSensorFactory == null) {
         return;
      }
      Set<SensorActivation> sensors = new HashSet<>();
      try {
         final Object[] sensorFactoryArgs = {
            stepID
         };
         final SensorActivation[] activations = (SensorActivation[]) conditionalTestSensorFactory.invoke(null, sensorFactoryArgs);
         Collections.addAll(sensors, activations);
      } catch (Exception e) {
         throw new AblRuntimeError("Reflection error running conditional test sensor factory for step " + name + " in parent "
               + parent, e);
      }

      // invoke the sensors - senseOneShot
      if (!sensors.isEmpty()) {
         BehavingEntity.getBehavingEntity().runSensors(new ArrayList<>(sensors), false);
      }
   }
}
