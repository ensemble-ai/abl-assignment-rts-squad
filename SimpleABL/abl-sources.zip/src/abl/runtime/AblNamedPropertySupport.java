// provides support for named properties on ABT nodes (goals and behaviors).

package abl.runtime;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// fixme: create a subclass of working memory that lives in abl.runtime that implements property support. 
public class AblNamedPropertySupport implements Serializable {
   private final Map<String,Object> propertyTable = new HashMap<>();

   public class UserProperty {
      private final String name;
      private final Object value;

      UserProperty(String n, Object v) {
         name = n;
         value = v;
      }

      public String getName() {
         return name;
      }

      public Object getValue() {
         return value;
      }

   }

   public void setProperty(String name, Object value) {
      propertyTable.put(name, value);
   }

   public Object getProperty(String name) {
      return propertyTable.get(name);
   }

   void deleteProperty(String name) {
      propertyTable.remove(name);
   }

   List<UserProperty> getAllDefinedProperties() {
      List<UserProperty> propertyList = new ArrayList<>();

      for (Object key : propertyTable.keySet()) {
         String propertyName = (String) key;
         Object propertyValue = propertyTable.get(propertyName);
         propertyList.add(new UserProperty(propertyName, propertyValue));
      }

      return propertyList;
   }

}
