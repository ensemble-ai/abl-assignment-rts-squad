package abl.runtime;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;

// StepDescriptor - used to store information about steps in instances of Behavior.

public class __StepDesc
      implements Serializable {
   final int stepID; // unique behavior id
   transient Method factory; // the step factory method to call for this step

   public __StepDesc(int arg_stepID, Method arg_factory) {
      stepID = arg_stepID;
      factory = arg_factory;
   }
   
   private void writeObject(ObjectOutputStream out) throws IOException {
      out.defaultWriteObject();
      /* persist the method fields */
      MethodSerializationIO helper = new MethodSerializationIO();
      helper.writeMethod(factory, out);
   }
   
   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      /* extract the method fields */
      MethodSerializationIO helper = new MethodSerializationIO();
      factory = helper.readMethod(in);
   }
}
