/**
 * Copyright 2015 UCSC
 */
package abl.runtime;


/**
 * Contains information for dynamically instantiating a goal
 */
public class GoalStepDescWME
      extends DynamicSpawnWME  {
   private String signature;
   private Object[] args;

   /**
    * Default constructor for assertion
    */
   public GoalStepDescWME() {
   }

   /**
    * Constructor allowing specification of signature and args
    * 
    * @param signature the signature of the GoalStep e.g. foo(String, int) with
    *        spaces between param types in parens
    */
   public GoalStepDescWME(String signature, Object... args) {
      this.signature = signature;
      this.args = args;
   }

   public Object[] getArgs() {
      return args;
   }

   public String getSignature() {
      return signature;
   }

   /**
    * Spawn the GoalStepDescWME at the spawnTargetRootBehavior with its bound args
    */
   @Override
   public void spawn(MultiStepBehavior spawnTargetRootBehavior) {
      GoalStep.dynamicSpawn(signature, spawnTargetRootBehavior, args);
   }

   @Override
   public String toString() {
      String desc = signature;
      if (args != null) {
         desc += "\nargs: {";
         for (int i = 0; i < args.length; i++) {
            if (i != 0) {
               desc += ", ";
            }
            desc += args[i];
         }
         desc += "}";
      }
      desc += "\nscore: " + getScore();
      return desc;
   }
}
