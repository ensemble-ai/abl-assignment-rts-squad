// Provides debug negotiation support for JointBehaviors.

package abl.runtime;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Map;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import abl.compiler.AblDebuggerConstants;

class JointGoalNegotiatorDebug
      extends JointGoalNegotiator
      implements AblDebuggerConstants {
   private final byte debugLevel;
   private final List<JointGoalNegotiationEvent> negotiationEvents = new ArrayList<>(20);

   class JointGoalNegotiationInfo {
      final JointGoalStep g;
      final BehavingEntity behavingEntity;
      final int intention;

      JointGoalNegotiationInfo(JointGoalStep g, BehavingEntity behavingEntity, int intention) {
         this.g = g;
         this.behavingEntity = behavingEntity;
         this.intention = intention;
      }
   }

   class JointGoalNegotiationEvent {
      String negotiation;
      JointGoalNegotiationInfo info;
      int eventCurrentState;

      JointGoalNegotiationEvent(String negotiation, JointGoalNegotiationInfo info, int currentState) {
         this.negotiation = negotiation;
         this.info = info;
         this.eventCurrentState = currentState;
      }

      @Override
      public String toString() {
         if (info != null) {
            String entity;
            if (info.behavingEntity != null) {
               entity = info.behavingEntity.getBehavingEntityShortName();
            } else {
               entity = "self";
            }
            return negotiation + " from: " + entity + ", intention: " + formatIntention(info.intention) + ", state: "
                  + formatState(eventCurrentState);
         } else {
            return "state changed by " + negotiation + " to: " + formatState(eventCurrentState);
         }

      }
   }

   JointGoalNegotiatorDebug(Set<BehavingEntity> teamMembers, boolean isNewEntryNegotiation, JointGoalStep g, byte arg_debugLevel) {
      super(teamMembers, isNewEntryNegotiation, g);
      debugLevel = arg_debugLevel;
   }

   JointGoalNegotiatorDebug(Map<BehavingEntity, Step> commitSet, byte arg_debugLevel) {
      super(commitSet);
      debugLevel = arg_debugLevel;
   }

   JointGoalNegotiatorDebug(Map<BehavingEntity, Step> commitSet, int currentState, byte arg_debugLevel) {
      super(commitSet, currentState);
      debugLevel = arg_debugLevel;
   }

   JointGoalNegotiatorDebug(Set<BehavingEntity> teamMembers, JointGoalStep g, byte arg_debugLevel) {
      super(teamMembers, g);
      debugLevel = arg_debugLevel;
   }

   @Override
   protected synchronized void setState(int state) {
      JointGoalNegotiationThread t = (JointGoalNegotiationThread) Thread.currentThread();
      negotiationEvents.add(new JointGoalNegotiationEvent(t.descriptorString, null, state));
      super.setState(state);
   }

   // fixme: the negotiating goal could be an initiated joint goal step - need
   // to check
   // Debug action for initiation of negotiation.
   @Override
   final protected void initiateNegotiationAction(JointGoalStep g, int negotiation) {
      JointGoalNegotiationInfo info = new JointGoalNegotiationInfo(g, null, negotiation);
      if (debugLevel == GUI_DEBUGGER) {
         ((DebuggableJointGoalStep) negotiatingGoal).traceAblNegotiationEvent(AblEvent.INITIATE_NEGOTIATION, info);
      }
      negotiationEvents.add(new JointGoalNegotiationEvent("INITIATE_NEGOTIATION", info, getState()));
   }

   // Debug action for completion of negotiation.
   @Override
   final protected void completeNegotiationAction(JointGoalStep g, int negotiation) {
      JointGoalNegotiationInfo info = new JointGoalNegotiationInfo(g, null, negotiation);
      if (debugLevel == GUI_DEBUGGER) {
         ((DebuggableJointGoalStep) negotiatingGoal).traceAblNegotiationEvent(AblEvent.COMPLETE_NEGOTIATION, info);
      }
      negotiationEvents.add(new JointGoalNegotiationEvent("COMPLETE_NEGOTIATION", info, getState()));
   }

   // Debug action for initiaton of intention.
   @Override
   final protected void initiateIntentionAction(BehavingEntity sender, JointGoalStep receivingGoal, int intention) {
      JointGoalNegotiationInfo info = new JointGoalNegotiationInfo(receivingGoal, sender, intention);
      if (debugLevel == GUI_DEBUGGER) {
         ((DebuggableJointGoalStep) negotiatingGoal).traceAblNegotiationEvent(AblEvent.INITIATE_INTENTION, info);
      }
      negotiationEvents.add(new JointGoalNegotiationEvent("INITIATE_INTENTION", info, getState()));
   }

   // Debug action for commitment to intention.
   @Override
   final protected void commitToIntentionAction(JointGoalStep g, int intention) {
      JointGoalNegotiationInfo info = new JointGoalNegotiationInfo(g, null, intention);
      if (debugLevel == GUI_DEBUGGER) {
         ((DebuggableJointGoalStep) negotiatingGoal).traceAblNegotiationEvent(AblEvent.COMMIT_TO_INTENTION, info);
      }
      negotiationEvents.add(new JointGoalNegotiationEvent("COMMIT_TO_INTENTION", info, getState()));
   }

   // Debug action for processing an intention.
   @Override
   final protected void processIntentionAction(BehavingEntity sender, JointGoalStep receivingGoal, int intention) {
      JointGoalNegotiationInfo info = new JointGoalNegotiationInfo(receivingGoal, sender, intention);
      if (debugLevel == GUI_DEBUGGER) {
         ((DebuggableJointGoalStep) negotiatingGoal).traceAblNegotiationEvent(AblEvent.PROCESS_INTENTION, info);
      }
      negotiationEvents.add(new JointGoalNegotiationEvent("PROCESS_INTENTION", info, getState()));
   }

   @Override
   void printNegotiationHistory(PrintStream s) {
      Iterator<JointGoalNegotiationEvent> iter = negotiationEvents.iterator();
      s.println("Negotiation history: " + " for " + negotiatingGoal + ":");
      s.println("   Current state: " + formatState(getState()));
      while (iter.hasNext()) {
         JointGoalNegotiationEvent evt = iter.next();
         s.println("   " + evt);
      }
   }

   @Override
   final void printNegotiationHistory() {
      printNegotiationHistory(System.err);
   }

}
