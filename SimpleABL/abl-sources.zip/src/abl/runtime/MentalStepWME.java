// WME wrapper for MentalSteps

package abl.runtime;

public class MentalStepWME
      extends StepWME {
   public MentalStepWME(MentalStep mentalStep, BehaviorWME parent) {
      super(mentalStep, parent);
   }
}
