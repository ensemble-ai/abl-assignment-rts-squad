package abl.runtime;

import java.util.Map;

import wm.UnorderedRelationWME;

/**
 * Static class used to increment map counts, and compare maps for unordered
 * relation field tests
 * 
 * @author John
 * 
 */
public class UnorderedRelationsComparitor {

   /**
    * helper static function to increment the value stored in a map
    * 
    * @param h
    * @param key
    */
   public static void increment(Map<Object, Integer> h, Object key) {
      if (!h.containsKey(key)) {
         h.put(key, 1);
      } else {
         int value = h.get(key);
         value += 1;
         h.put(key, value);
      }
   }

   /**
    * Static method to compare the contents of two maps.
    * 
    * @param h1 the first map of object keys and Integer values
    * @param h2 the second map of object keys and Integer values
    * @return
    */
   public static boolean compare(Map<Object, Integer> h1, Map<Object, Integer> h2) {
      // For all values in the first map
      for (Map.Entry<Object, Integer> objectIntegerEntry : h2.entrySet()) {
         // System.out.println("H2 key: " + h2Temp.toString());
         /**
          * TODO: this wont work until all arguments are mapped automatically.
          */
         // See if there is a corresponding value in the second map
         Object key = objectIntegerEntry.getKey();
         if (h1.containsKey(key)) {
            // System.out.println("H1 contains: " + h2Temp.toString());
            int h2tempint = objectIntegerEntry.getValue();
            int h1tempint = h1.get(key);
            if (h1tempint != h2tempint) {
               // boo they are different
               return false;
            }
         } else {
            System.out.println("H1 does NOT contain: " + key.toString());
            return false;
         }

      }

      return true;
   }

   /**
    * Method to add all arguments from an unorderedRelationWME automatically
    * 
    * @param h the hashmap to add to
    * @param w the wme to use
    */
   public static void addAll(Map<Object, Integer> h, UnorderedRelationWME w) {
      for (int i = 0; i < w.getArgCount(); i++) {
         UnorderedRelationsComparitor.increment(h, w.getArg(i));
      }

   }

}
