/* Simple utility class pairing a satisfied behavior class with the
   hash table of variables bound by the precondition. */

package abl.runtime;

import java.util.Map;

class SatisfiedBehavior {
   __BehaviorDesc behDesc;
   
   /* Variables bound by precondition.  Impossible to guess what that types should be */
   
   Map<Object,Object> preconditionBoundVariables; 

   SatisfiedBehavior(__BehaviorDesc arg_behDesc, Map<Object,Object> arg_preconditionBoundVariables) {
      behDesc = arg_behDesc;
      preconditionBoundVariables = arg_preconditionBoundVariables;
   }
}
