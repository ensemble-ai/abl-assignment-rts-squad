// WME wrapper for PrimitiveSteps

package abl.runtime;

public class PrimitiveStepWME
      extends ExecutableStepWME {
   public PrimitiveStepWME(PrimitiveStep primitiveStep, BehaviorWME parent) {
      super(primitiveStep, parent);
   }

   public synchronized int getCompletionStatus() {
      return ((PrimitiveStep) s).getCompletionStatus();
   }

   public synchronized String getName() {
      return ((PrimitiveStep) s).getName();
   }
}
