// WME for abl physical acts
// fixme: change this into EpisodicActWME when temporal intervals are supported

package abl.runtime;

public class CompletedActWME
      extends CompletedExecutableStepWME {

   public CompletedActWME(String signature, int completionStatus, String behaviorSignature, String agent, long timestamp) {
      super(signature, completionStatus, behaviorSignature, agent, timestamp);
   }

   public CompletedActWME(String signature, int completionStatus, String behaviorSignature, String agent) {
      super(signature, completionStatus, behaviorSignature, agent);
   }
}
