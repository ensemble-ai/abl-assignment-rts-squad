/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2012. All rights reserved.
 *
 *******************************************************************************/
package abl.runtime;

import wm.WME;


/**
 * A WME that stores information about the type of SIU CiF has asked ABL to
 * run.
 */
public class LaunchTestBedBehaviorWME
      extends WME {

   private String behaviorToLaunch;
   private String arg1;
   private String arg2;
   private String arg3;
   
   /**
    * @param toLaunch
    * @param a1
    * @param a2
    * @param a3
    */
   public LaunchTestBedBehaviorWME(String toLaunch, String a1, String a2, String a3) {
	   this.behaviorToLaunch = toLaunch;
	   this.arg1 = a1;
	   this.arg2 = a2;
	   this.arg3 = a3;
   }

   /**
    * @return the behaviorToLaunch
    */
   public String getBehaviorToLaunch() {
      return behaviorToLaunch;
   }

   /**
    * @param behaviorToLaunch the behaviorToLaunch to set
    */
   public void setBehaviorToLaunch(String behaviorToLaunch) {
      this.behaviorToLaunch = behaviorToLaunch;
   }

   /**
    * @return the arg1
    */
   public String getArg1() {
      return arg1;
   }

   /**
    * @param arg1 the arg1 to set
    */
   public void setArg1(String arg1) {
      this.arg1 = arg1;
   }

   /**
    * @return the arg2
    */
   public String getArg2() {
      return arg2;
   }

   /**
    * @param arg2 the arg2 to set
    */
   public void setArg2(String arg2) {
      this.arg2 = arg2;
   }

   /**
    * @return the arg3
    */
   public String getArg3() {
      return arg3;
   }

   /**
    * @param arg3 the arg3 to set
    */
   public void setArg3(String arg3) {
      this.arg3 = arg3;
   }

}
