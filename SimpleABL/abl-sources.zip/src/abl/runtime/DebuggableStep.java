package abl.runtime;

interface DebuggableStep
      extends DebuggableABTNode {
}
