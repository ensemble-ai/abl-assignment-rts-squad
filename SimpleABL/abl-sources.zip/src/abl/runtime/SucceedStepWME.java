// WME wrapper for succeed steps

package abl.runtime;

public class SucceedStepWME
      extends StepWME {
   public SucceedStepWME(SucceedStep succeedStep, BehaviorWME parent) {
      super(succeedStep, parent);
   }
}
