// Comparator used to compare behavior specificities on __BehaviorDescs

package abl.runtime;

import java.util.Comparator;

class BehaviorSpecificityComparator
      implements Comparator<SatisfiedBehavior> {

   /*
    * Compares the specificities of two behavior classes. Returns value < 0 if
    * o1.behDesc.specificity > o2.behDesc.specificity. Returns value = 0 if
    * o1.behDesc.specificity = o2.behDesc.specificity. Returns value > 0 if
    * o1.behDesc.specificity < o2.behDesc.specificity. Note: this comparator
    * imposes orderings that are inconsitent with equals because it inherits
    * equals from Object which tests for *reference* equality
    */
   @Override
   public int compare(SatisfiedBehavior o1, SatisfiedBehavior o2) {
      final Integer i1 = (int) o1.behDesc.specificity;
      final Integer i2 = (int) o2.behDesc.specificity;
      return -i1.compareTo(i2);
   }
}
