// WME wrapper for fail steps

package abl.runtime;

public class FailStepWME
      extends StepWME {
   public FailStepWME(FailStep failStep, BehaviorWME parent) {
      super(failStep, parent);
   }
}
