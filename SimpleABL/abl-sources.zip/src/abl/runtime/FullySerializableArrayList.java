/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2013. All rights reserved.
 *
 ******************************************************************************/
package abl.runtime;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * An ArrayList whose iterators are guaranteed to be serializable
 * 
 * Content of inner classes handling iteration mostly copied from Java sources.
 * 
 * @param <T> element type
 */
public final class FullySerializableArrayList<T extends Serializable>
      extends ArrayList<T> {

   private static final long serialVersionUID = 6973223681321140118L;

   /**
    * Make an empty list
    */
   public FullySerializableArrayList() {
   }

   /**
    * Make a list initially populated by some other collection.
    * 
    * @param baseCollection the initial population.
    */
   public FullySerializableArrayList(Collection<T> baseCollection) {
      super(baseCollection);
   }

   @Override
   public ListIterator<T> listIterator() {
      return new ListItr<>(this, 0);
   }

   @Override
   public ListIterator<T> listIterator(int index) {
      return new ListItr<>(this, index);
   }

   @Override
   public Iterator<T> iterator() {
      return new Itr<>(this);
   }

   private int getModCount() {
      return modCount;
   }

   private static class Itr<E extends Serializable>
         implements Serializable, Iterator<E> {

      private static final long serialVersionUID = 6195263960307820909L;

      protected final FullySerializableArrayList<E> owner;
      protected int size;
      protected int cursor;
      protected int lastRet;
      protected int expectedModCount;

      Itr(FullySerializableArrayList<E> owner) {
         this.owner = owner;
         expectedModCount = owner.getModCount();
         size = owner.size();
      }

      @Override
      public boolean hasNext() {
         return cursor != size;
      }

      @Override
      public E next() {
         checkForComodification();
         int i = cursor;
         if (i >= size) {
            throw new NoSuchElementException();
         }
         if (i >= owner.size()) {
            throw new ConcurrentModificationException();
         }
         cursor = i + 1;
         return owner.get(lastRet = i);
      }

      @Override
      public void remove() {
         if (lastRet < 0) {
            throw new IllegalStateException();
         }
         checkForComodification();

         try {
            owner.remove(lastRet);
            cursor = lastRet;
            lastRet = -1;
            --size;
            expectedModCount = owner.getModCount();
         } catch (IndexOutOfBoundsException ex) {
            throw new ConcurrentModificationException();
         }
      }

      final void checkForComodification() {
         if (owner.getModCount() != expectedModCount) {
            throw new ConcurrentModificationException();
         }
      }
   }

   /*
    * Copied from Java sources and modified as needed.
    */
   private static class ListItr<E extends Serializable>
         extends Itr<E>
         implements ListIterator<E> {

      ListItr(FullySerializableArrayList<E> owner, int index) {
         super(owner);
         cursor = index;
      }

      @Override
      public boolean hasPrevious() {
         return cursor != 0;
      }

      @Override
      public int nextIndex() {
         return cursor;
      }

      @Override
      public int previousIndex() {
         return cursor - 1;
      }

      @Override
      public E previous() {
         checkForComodification();
         int i = cursor - 1;
         if (i < 0) {
            throw new NoSuchElementException();
         }
         if (i >= owner.size()) {
            throw new ConcurrentModificationException();
         }
         cursor = i;
         return owner.get(lastRet = i);
      }

      @Override
      public void set(E e) {
         if (lastRet < 0) {
            throw new IllegalStateException();
         }
         checkForComodification();

         try {
            owner.set(lastRet, e);
         } catch (IndexOutOfBoundsException ex) {
            throw new ConcurrentModificationException();
         }
      }

      @Override
      public void add(E e) {
         checkForComodification();

         try {
            int i = cursor;
            owner.add(i, e);
            cursor = i + 1;
            lastRet = size;
            ++size;
            expectedModCount = owner.getModCount();
         } catch (IndexOutOfBoundsException ex) {
            throw new ConcurrentModificationException();
         }

      }
   }
   
   /**
    * Create a FullySerializableArrayList from an array.
    * 
    * @param array the array
    * @return the fully serializable list.
    */
   public static <T extends Serializable> FullySerializableArrayList<T> asList(T[] array) {
      return new FullySerializableArrayList<>(Arrays.asList(array));
      
   }
}