/**
 * Copyright 2013 UCSC
 */
package abl.runtime.statistics;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Make statistics available via logging
 */
public final class StatisticsUtils {

   /**
    * Always use this as the logger name.
    */
   public static final String ABL_STATS_LOGGER_NAME = "abl.stats";

   private StatisticsUtils() {
   }

   /** The one and only level instance  */
   public static final Level ABL_STATS = new StatsLevel();
   private static String csvHeader;
   
   /**
    * Be sure to call this before logging.properties is parsed.
    * Otherwise that file can't reference ABL_STATS by name.
    */
   public static void register() {
      /* the reference is sufficient */
   }

   /**
    *
    * @return true iff the statistics support is enabled
    */
   public static boolean isEnabled() {
      return Logger.getLogger(ABL_STATS_LOGGER_NAME).isLoggable(StatisticsUtils.ABL_STATS);
   }

   static void setCsvHeader(String header) {
      csvHeader = header;
   }

   /**
    *
    * @return the previously set CSV columns file header
    */
   public static String getCsvHeader() {
      return csvHeader;
   }

   private static class StatsLevel extends Level {
      private StatsLevel() {
         super("ABL_STATS", Level.FINEST.intValue()-1, Level.FINEST.getResourceBundleName());
      }
   }

}
