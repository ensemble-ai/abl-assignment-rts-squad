/**
 * Copyright 2013 UCSC
 */
package abl.runtime.statistics;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

/**
 * Package up any number of snapshots to be processed as a bundle.
 */
public class StatisticsCollector {
   private static final long TIME_INCREMENT_MILLIS = 1000;
   
   private static final Logger logger = Logger.getLogger(StatisticsUtils.ABL_STATS_LOGGER_NAME);
   private final List<StatisticsSnapshot> snapshots = new ArrayList<>();
   private Object[] parameters;
   private final DateFormat fmt = new SimpleDateFormat("ss");
   private long nextRecordTime;

   /**
    * Created and add standard snapshot
    * @param id the snapshot name
    * @param data a collection whose size is of interest.
    */
   public void addSnapshot(String id, Collection<?> data)  {
      addSnapshot(new StatisticsSnapshot(id, data));
   }
   
   /**
    * Add a pre-built snapshot
    * @param snapshot the existing snapshot
    */
   public void addSnapshot(StatisticsSnapshot snapshot) {
      snapshots.add(snapshot);
   }

   /**
    * Call this when all the snapshots have been added.
    */
   public void init() {
      this.parameters = new Object[snapshots.size() * 3];
      StringBuilder builder = new StringBuilder();
      builder.append("Timestamp,Seconds"); 
      for (StatisticsSnapshot snapshot : snapshots) {
         builder.append(',').append(snapshot.getId()).append("-min");
         builder.append(',').append(snapshot.getId()).append("-max");
         builder.append(',').append(snapshot.getId()).append("-avg");
      }
      StatisticsUtils.setCsvHeader(builder.toString());
   }
   
   /**
    * Sample each snapshot.
    */
   public void sample() {
      long time = System.currentTimeMillis();
      for (StatisticsSnapshot snapshot : snapshots) {
         snapshot.sample();
      }
      if (time > nextRecordTime) {
         int destPos = 0;
         for (StatisticsSnapshot snapshot : snapshots) {
            Object [] data = snapshot.getRowData();
            System.arraycopy(data, 0, parameters, destPos, 3);
            destPos += 3;
         }
         String msg = fmt.format(new Date(time));
         nextRecordTime = time + TIME_INCREMENT_MILLIS;
         logger.log(StatisticsUtils.ABL_STATS, msg, parameters);
      }
   }

}
