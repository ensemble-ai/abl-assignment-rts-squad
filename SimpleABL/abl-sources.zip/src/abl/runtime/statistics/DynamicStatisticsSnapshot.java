/**
 * Copyright 2013 UCSC
 */
package abl.runtime.statistics;

/**
 * Variant of StatisticsSnapshot where the same collection's size is checked at
 * specific times.
 */
public class DynamicStatisticsSnapshot
      extends StatisticsSnapshot {

   /**
    * @param id name
    */
   public DynamicStatisticsSnapshot(String id) {
      super(id, null);
   }

   @Override
   public void sample() {
      /* no-op here */
   }
}
