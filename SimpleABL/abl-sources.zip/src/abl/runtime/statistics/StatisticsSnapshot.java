/**
 * Copyright 2013 UCSC
 */
package abl.runtime.statistics;

import java.util.Collection;


/**
 * Simple statistics based on the changing size of a collection.
 */
public class StatisticsSnapshot {
   private final String id;
   private final Collection<?> data;
   private int min, max, count, sum;
   
   /**
    * Make one
    * @param id the name
    * @param data the collection whose changing size is of interest
    */
   public StatisticsSnapshot(String id, Collection<?> data) {
      this.id = id;
      this.data = data;
      this.min = Integer.MAX_VALUE;
   }
   
   String getId() {
      return id;
   }
   
   /**
    * Do a standard sample based on the collection's current size.
    */
   public void sample() {
      sample(data.size());
   }

   /**
    * Do a sample with a given value.
    * @param value the size value
    */
   public void sample(int value) {
      min = Math.min(min, value);
      max = Math.max(max, value);
      ++count;
      sum += value;
   }
   
   Object[] getRowData() {
      Object[] params = new Object[3];
      params[0] = min == Integer.MAX_VALUE ? 0 : min;
      params[1] = max;
      params[2] = count == 0  ? 0 : sum/count;
      count = sum = max = 0;
      min = Integer.MAX_VALUE;
      return params;
   }
}