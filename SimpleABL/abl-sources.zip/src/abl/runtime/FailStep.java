// Class for fail steps. 

package abl.runtime;

import java.lang.reflect.Method;

public class FailStep
      extends Step {

   // Constructor for FailStep calls the super constructor.
   // It is not legal to associate persistence properties or a success test with
   // a fail step.
   public FailStep(int stepID, Method arg_stepFactory, Behavior arg_parent, boolean arg_ignoreFailure, boolean arg_effectOnly, boolean arg_teamEffectOnly,
                   short arg_priority, short arg_priorityModifier, boolean arg_post, String arg_postMemory,
                   AblNamedPropertySupport arg_propertyTable) {
      super(stepID,
            arg_stepFactory,
            arg_parent,
            false,
            false,
            false,
            arg_ignoreFailure,
            arg_effectOnly,
            arg_teamEffectOnly,
            arg_priority,
            arg_priorityModifier,
            arg_post,
            arg_postMemory,
            null,
            null,
            null,
            arg_propertyTable,
            FAIL);
   }

   // Execute fails the step.
   @Override
   void execute() {
      failStep();
   }

   @Override
   void resetStep() {
      BehavingEntity.getBehavingEntity().resetStep(this);
   }

}
