/**
 * Copyright 2015 UCSC
 */
package abl.runtime;

import java.lang.reflect.Method;

import wm.ScorableWME;
import wm.WorkingMemory;
import wm.WorkingMemorySet;

public class ChooseBehavior
      extends MemoryExecuteBehavior {
   
   /**
    * The policy used for choice determination
    */
   private final Rulegroup policy;

   public ChooseBehavior(GoalStep arg_parent, Rulegroup arg_descriptionRulegroup, Method arg_contextCondition, Method arg_contextConditionSensorFactory,
                         Method arg_successCondition, Method arg_successConditionSensorFactory, boolean arg_isAtomic,
                         String arg_signature, short arg_specificity, int arg_behaviorID, Object[] arg_behaviorVariableFrame,
                         __StepDesc[] arg_stepDescs, int arg_numberNeededForSuccess, Rulegroup arg_policy) {
      super(arg_parent,
            arg_descriptionRulegroup,
            arg_contextCondition,
            arg_contextConditionSensorFactory,
            arg_successCondition,
            arg_successConditionSensorFactory,
            arg_isAtomic,
            arg_signature,
            arg_specificity,
            arg_behaviorID,
            arg_behaviorVariableFrame,
            arg_stepDescs,
            /* Set number needed for success to 0 by default, since the value is set dynamically during choice consideration/spawning */
            0);
      policy = arg_policy;
   }

   public ChooseBehavior(GoalStep arg_parent, Rulegroup arg_descriptionRulegroup, Method arg_contextCondition, Method arg_contextConditionSensorFactory,
                         Method arg_successCondition, Method arg_successConditionSensorFactory, boolean arg_isAtomic,
                         String arg_signature, short arg_specificity, int arg_behaviorID, Object[] arg_behaviorVariableFrame,
                         __StepDesc[] arg_stepDescs, int arg_numberNeededForSuccess, BehavingEntity[] arg_teamMembers, Rulegroup arg_policy) {
      super(arg_parent,
            arg_descriptionRulegroup,
            arg_contextCondition,
            arg_contextConditionSensorFactory,
            arg_successCondition,
            arg_successConditionSensorFactory,
            arg_isAtomic,
            arg_signature,
            arg_specificity,
            arg_behaviorID,
            arg_behaviorVariableFrame,
            arg_stepDescs,
            /* Set number needed for success to 0 by default, since the value is set dynamically during choice consideration/spawning */
            0,
            arg_teamMembers);
      policy = arg_policy;
   }
   
   /**
    * Dynamically generate working memory to execute by reasoning over the child steps of the behavior
    */
   @Override
   protected WorkingMemorySet getMemoryToExecute() {
      WorkingMemory goalMem = new WorkingMemory();
      /* Populate the goalMem with the goal steps to consider */
      final Step[] steps = new Step[stepDescs.length];
      for (int i = 0; i < steps.length; i++) {
         try {
            // Since this is only for consideration, instantiate the step with the choose step's
            final Object[] factoryArgs = {
               stepDescs[i].stepID,
               this,
               behaviorVariableFrame
            };
            GoalStep g = (GoalStep) stepDescs[i].factory.invoke(null, factoryArgs);
            goalMem.addWME(new GoalStepWME(g, null));
         } catch (Exception e) {
            throw new AblRuntimeError("Error invoking step factory", e);
         }
      }
      WorkingMemorySet considerationSet = new WorkingMemorySet(goalMem);
      /* Run the policy, with goalMem as the bindMem */
      BehavingEntity.getBehavingEntity().runRulegroup(policy, null, considerationSet, null, null, null);
      ScorableWME.pickBest(goalMem);
      return considerationSet;
   }
}
