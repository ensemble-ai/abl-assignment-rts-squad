// WME wrapper for Conditional Steps

package abl.runtime;

public class ConditionalStepWME
      extends GoalStepWME {
   public ConditionalStepWME(ConditionalStep conditionalStep, BehaviorWME parent) {
      super(conditionalStep, parent);
   }
}
