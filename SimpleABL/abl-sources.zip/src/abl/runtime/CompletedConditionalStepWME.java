// WME for conditional steps

package abl.runtime;

public class CompletedConditionalStepWME
      extends CompletedStepWME {

   public CompletedConditionalStepWME(String behaviorSignature, String agent, long timestamp) {
      super(behaviorSignature, agent, timestamp);
   }

   public CompletedConditionalStepWME(String behaviorSignature, String agent) {
      super(behaviorSignature, agent);
   }
}
