// Abstract WME for abl steps posted to memory
// fixme: change this into EpisodicStepWME when temporal intervals are supported

package abl.runtime;

import wm.TimeStampedWME;

public abstract class CompletedStepWME
      extends TimeStampedWME {
   private String behaviorSignature;
   private String agent;

   public CompletedStepWME(String behaviorSignature, String agent, long timestamp) {
      super(timestamp);
      this.behaviorSignature = behaviorSignature;
      this.agent = agent;
   }

   public CompletedStepWME(String behaviorSignature, String agent) {
      this.behaviorSignature = behaviorSignature;
      this.agent = agent;
   }

   public synchronized String getBehaviorSignature() {
      return behaviorSignature;
   }

   public synchronized void setBehaviorSignature(String behaviorSignature) {
      this.behaviorSignature = behaviorSignature;
   }

   public synchronized String getAgent() {
      return agent;
   }

   public synchronized void setAgent(String agent) {
      this.agent = agent;
   }

}
