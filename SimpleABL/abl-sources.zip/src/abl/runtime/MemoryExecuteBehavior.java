/**
 * Copyright 2015 UCSC
 */
package abl.runtime;

import java.lang.reflect.Method;
import java.util.List;

import wm.WorkingMemorySet;

public class MemoryExecuteBehavior
      extends ParallelBehavior {

   public MemoryExecuteBehavior(GoalStep arg_parent, Rulegroup arg_descriptionRulegroup, Method arg_contextCondition, Method arg_contextConditionSensorFactory,
                                Method arg_successCondition, Method arg_successConditionSensorFactory, boolean arg_isAtomic,
                                String arg_signature, short arg_specificity, int arg_behaviorID,
                                Object[] arg_behaviorVariableFrame, __StepDesc[] arg_stepDescs, int arg_numberNeededForSuccess) {
      super(arg_parent,
            arg_descriptionRulegroup,
            arg_contextCondition,
            arg_contextConditionSensorFactory,
            arg_successCondition,
            arg_successConditionSensorFactory,
            arg_isAtomic,
            arg_signature,
            arg_specificity,
            arg_behaviorID,
            arg_behaviorVariableFrame,
            arg_stepDescs,
            arg_numberNeededForSuccess);
   }

   public MemoryExecuteBehavior(GoalStep arg_parent, Rulegroup arg_descriptionRulegroup, Method arg_contextCondition, Method arg_contextConditionSensorFactory,
                                Method arg_successCondition, Method arg_successConditionSensorFactory, boolean arg_isAtomic,
                                String arg_signature, short arg_specificity, int arg_behaviorID,
                                Object[] arg_behaviorVariableFrame, __StepDesc[] arg_stepDescs, int arg_numberNeededForSuccess,
                                BehavingEntity[] arg_teamMembers) {
      super(arg_parent,
            arg_descriptionRulegroup,
            arg_contextCondition,
            arg_contextConditionSensorFactory,
            arg_successCondition,
            arg_successConditionSensorFactory,
            arg_isAtomic,
            arg_signature,
            arg_specificity,
            arg_behaviorID,
            arg_behaviorVariableFrame,
            arg_stepDescs,
            arg_numberNeededForSuccess,
            arg_teamMembers);
   }

   // Needs to get memory and add steps dynamically based on memory, as
   // memExeStep does now

   public static final String DEFAULT_MEMORY_EXECUTE_BEHAVIOR_SIGNATURE = "__$defaultMemoryExecuteBehavior";

   /**
    * Base version just gets the WorkingMemorySet which is the only argument to
    * the behavior
    */
   protected WorkingMemorySet getMemoryToExecute() {
      WorkingMemorySet wmSet = (WorkingMemorySet) behaviorVariableFrame[0];
      return wmSet;
   }

   /**
    * Dynamically add this behavior's children from the working memory set
    */
   @Override
   void addChildren() {
      /* Lookup the DynamicSpawnWMEs in the memory argument */
      WorkingMemorySet wmSet = getMemoryToExecute();

      List<DynamicSpawnWME> allDynamicSpawnWMEs = wmSet.lookupWME(DynamicSpawnWME.class);
      /**
       * If there are no DynamicSpawnWMEs in the memory to execute, just succeed
       * and return
       */
      if (allDynamicSpawnWMEs.isEmpty()) {
         succeedBehavior();
         return;
      }

      allDynamicSpawnWMEs.stream().forEach(s -> {
         s.spawn(this);
      });
   }
}
