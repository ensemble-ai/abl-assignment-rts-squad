// Concrete debug class for initiated joint goal steps (initiated by another entity).

package abl.runtime;

import java.util.Map;
import java.util.Set;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;

import abl.compiler.AblDebuggerConstants;

public class InitiatedJointGoalStepDebug
      extends InitiatedJointGoalStep
      implements DebuggableJointGoalStep, AblDebuggerConstants {
   private final byte debugLevel;

   public InitiatedJointGoalStepDebug(Behavior beh, String signature, Set<BehavingEntity> teamMembers, Object[] args, boolean teamNeededForSuccess,
                                      byte arg_debugLevel) {
      super(beh, signature, teamMembers, args, teamNeededForSuccess);
      debugLevel = arg_debugLevel;
   }

   // #################
   // Override getNewJointGoalNegotiator to provide a debug version of the
   // negotiator.
   @Override
   protected final JointGoalNegotiator getNewJointGoalNegotiator(Map<BehavingEntity, Step> commitSet) {
      return new JointGoalNegotiatorDebug(commitSet, debugLevel);
   }

   @Override
   protected final JointGoalNegotiator getNewJointGoalNegotiator(Set<BehavingEntity> teamMembers) {
      return new JointGoalNegotiatorDebug(teamMembers, this, debugLevel);
   }

   @Override
   protected final JointGoalNegotiator getNewJointGoalNegotiator(Map<BehavingEntity, Step> commitSet, int state) {
      return new JointGoalNegotiatorDebug(commitSet, state, debugLevel);
   }

   @Override
   protected JointGoalNegotiator getNewJointGoalNegotiator(Set<BehavingEntity> teamMembers, boolean newEntryNegotiation) {
      return new JointGoalNegotiatorDebug(teamMembers, newEntryNegotiation, this, debugLevel);
   }

   // fixme: does this need public access?
   // JointGoalSteps check with parent to see if they should trace the
   // negotiation event
   @Override
   public final void traceAblNegotiationEvent(int type, JointGoalNegotiatorDebug.JointGoalNegotiationInfo info) {
      assert debugLevel == GUI_DEBUGGER; // this method only called when GUI
                                         // debugger active
      ((DebuggableBehavior) parent).traceAblExecutionEvent(type, this, info, getNestLevel());
   }

   // #################

   // fixme: add trace support for suspend

   @Override
   final void execute() {
      if (debugLevel == GUI_DEBUGGER) {
         ((DebuggableBehavior) parent).traceAblExecutionEvent(AblEvent.SUBGOAL_EXECUTION, this, null, getNestLevel());
      }
      super.execute();
   }

   @Override
   final void succeedStep() {
      if (debugLevel == GUI_DEBUGGER) {
         ((DebuggableBehavior) parent).traceAblExecutionEvent(AblEvent.SUBGOAL_COMPLETION, this, true, getNestLevel());
      }
      super.succeedStep();
   }

   @Override
   final void failStep() {
      if (debugLevel == GUI_DEBUGGER) {
         ((DebuggableBehavior) parent).traceAblExecutionEvent(AblEvent.SUBGOAL_COMPLETION, this, false, getNestLevel());
      }
      super.failStep();
   }

   @Override
   final boolean successTest() {
      final boolean ret = super.successTest();
      if (ret && debugLevel == GUI_DEBUGGER) {
         ((DebuggableBehavior) parent).traceAblExecutionEvent(AblEvent.SUCCESS_TEST_SUCCESS, this, null, getNestLevel());
      }

      return ret;
   }

   // Returns a tree node which wraps the subtree rooted at this node in the
   // ABT.
   @Override
   public final MutableTreeNode getTree() {
      final DefaultMutableTreeNode node = new DefaultMutableTreeNode(this);
      if (child != null) {
         // If a behavior has been selected for this goal, add the tree
         // rooted at this behavior.
         node.add(((DebuggableBehavior) child).getTree());
      }

      return node;
   }

   // fixme: change this from a recursive call to an accessor for the nest level
   // (see Behavior).
   // to do this, will need to reset the nest level when a goal spawns.
   @Override
   public final int getNestLevel() {
      return ((DebuggableBehavior) parent).getNestLevel() + 1;
   }
}
