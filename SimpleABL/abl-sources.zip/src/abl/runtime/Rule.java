package abl.runtime;

import java.lang.reflect.Field;

import wm.WME;

public class Rule
      extends WME {
   public final String name;
   public final int id;

   // TODO Will probably need a signature and a way to distinguish if this is
   // globally or locally defined

   /**
    * 
    * @param name the name of the RuleOld
    * @param id the id of the RuleOld
    */
   public Rule(String name, int id) {
      this.name = name;
      this.id = id;
   }
   
   /**
    * @return the name
    */
   public synchronized String getName() {
      return name;
   }

   /**
    * @return the id
    */
   public synchronized int getId() {
      return id;
   }

   /**
    * Recurses over the inheritance structure of clazz to find a field that is
    * named fieldName. This will find private fields.
    * 
    * @param clazz The most specific class to find a field on.
    * @param fieldName The name of the field to find as a String.
    */
   public static Field getInheritedField(Class<?> clazz, String fieldName)
         throws NoSuchFieldException {
      try {
         return clazz.getDeclaredField(fieldName);
      } catch (NoSuchFieldException e) {
         Class<?> superClass = clazz.getSuperclass();
         if (superClass == null) {
            throw e;
         } else {
            return getInheritedField(superClass, fieldName);
         }
      }
   }

   @Override
   public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + id;
      result = prime * result + ((name == null) ? 0 : name.hashCode());
      return result;
   }

   @Override
   public boolean equals(Object obj) {
      if (this == obj) {
         return true;
      }
      if (obj == null) {
         return false;
      }
      if (getClass() != obj.getClass()) {
         return false;
      }
      Rule other = (Rule) obj;
      if (id != other.id) {
         return false;
      }
      if (name == null) {
         if (other.name != null) {
            return false;
         }
      } else if (!name.equals(other.name)) {
         return false;
      }
      return true;
   }
}
