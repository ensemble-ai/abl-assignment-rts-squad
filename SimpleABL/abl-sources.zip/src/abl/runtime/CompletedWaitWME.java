// WME for abl wait steps
// fixme: change this into EpisodicWaitWME when temporal intervals are supported

package abl.runtime;

public class CompletedWaitWME
      extends CompletedStepWME {

   public CompletedWaitWME(String behaviorSignature, String agent, long timestamp) {
      super(behaviorSignature, agent, timestamp);
   }

   public CompletedWaitWME(String behaviorSignature, String agent) {
      super(behaviorSignature, agent);
   }
}
