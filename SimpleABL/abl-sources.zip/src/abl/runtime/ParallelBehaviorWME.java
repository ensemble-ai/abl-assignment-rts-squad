// WME wrapper for ParallelBehaviors

package abl.runtime;

public class ParallelBehaviorWME
      extends MultiStepBehaviorWME {
   public ParallelBehaviorWME(ParallelBehavior b, GoalStepWME parent) {
      super(b, parent);
   }
}
