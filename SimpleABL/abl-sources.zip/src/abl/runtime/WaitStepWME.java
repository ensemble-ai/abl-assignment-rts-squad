// WME wrapper for wait steps

package abl.runtime;

public class WaitStepWME
      extends StepWME {
   public WaitStepWME(WaitStep waitStep, BehaviorWME parent) {
      super(waitStep, parent);
   }
}
