package abl.runtime;

interface DebuggableBehavior
      extends DebuggableABTNode {
   void traceAblExecutionEvent(int type, Step source, Object obj, int nestLevel);
}
