package abl.runtime;

import java.io.Serializable;

/** Tagging interface for Active Behavior Tree (ABT) nodes. */
/**
 * Note: Ben Weber, changed from default to public class scope.
 */
public interface ABTNode 
      extends Serializable {
}
