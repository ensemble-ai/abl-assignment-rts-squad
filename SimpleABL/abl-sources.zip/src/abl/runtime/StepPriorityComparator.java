// Comparator used to compare step priorities on instantiated steps.

package abl.runtime;

import java.util.Comparator;

class StepPriorityComparator
      implements Comparator<Step> {

   /*
    * Compares the priority of two instantiated steps. Returns value > 0 if
    * o1.getPriority() > o2.getPriority(). Returns value = 0 if o1.getPriority()
    * = o2.getPriority(). Returns value < 0 if o1.getPriority() <
    * o2.getPriority(). Note: this comparator imposes orderings that are
    * inconsistent with equals() because it inherits equals from Object which
    * tests for *reference* equality.
    */
   @Override
   public int compare(Step o1, Step o2) {
      short p1 = o1.getPriority();
      short p2 =  o2.getPriority();
      return Short.compare(p2, p1);
   }
}
