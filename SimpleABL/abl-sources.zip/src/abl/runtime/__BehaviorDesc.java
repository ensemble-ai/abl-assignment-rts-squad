package abl.runtime;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;

// BehaviorDescriptor - used to store information about behaviors in a behaving entities behavior registration table.

public class __BehaviorDesc
      implements Serializable {
   public final int behaviorID; // unique behavior id
   transient Method factory; // the behavior factory method to call for this
                         // behavior
   transient Method precondition; // the precondition method to call for this
                              // behavior - null if no precondition
   transient Method preconditionSensorFactory; // the precondition sensor factory
                                           // method to call for this behavior
   // fixme: since __BehaviorDescs are indexed by signature in the entity,
   // consider not storing it explicitly
   public final String signature; // behavior signature -- associated with the most
                           // general version of the behavior
   String uniqueName; // unique behavior name (<name>_<num>) - set when behavior
                      // is registered
   final String[] teamMembers; // array of team member descriptors - currently
                               // class names
   final short specificity; // behavior specificity

   // behaviors now have more than one signature associated with them, due to
   // inheritance
   public final String[] signatures;

   public __BehaviorDesc(int arg_behaviorID, Method arg_factory, Method arg_precondition, Method arg_preconditionSensorFactory,
                         String arg_signature, String[] arg_signatures, String[] arg_teamMembers, short arg_specificity) {
      behaviorID = arg_behaviorID;
      factory = arg_factory;
      precondition = arg_precondition;
      preconditionSensorFactory = arg_preconditionSensorFactory;
      signature = arg_signature;
      uniqueName = null;
      teamMembers = arg_teamMembers;
      specificity = arg_specificity;

      // add all the signatures associated with this behavior
      signatures = arg_signatures;
   }
   
   private void writeObject(ObjectOutputStream out) throws IOException {
      out.defaultWriteObject();
      /* persist the method fields */
      MethodSerializationIO helper = new MethodSerializationIO();
      helper.writeMethod(factory, out);
      helper.writeMethod(precondition, out);
      helper.writeMethod(preconditionSensorFactory, out);
   }
   
   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
      in.defaultReadObject();
      /* extract the method fields */
      MethodSerializationIO helper = new MethodSerializationIO();
      factory = helper.readMethod(in);
      precondition = helper.readMethod(in);
      preconditionSensorFactory = helper.readMethod(in);
   }
}
