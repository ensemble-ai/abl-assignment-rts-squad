/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2012. All rights reserved.
 *
 *******************************************************************************/

package abl.runtime;

import java.util.HashMap;
import java.util.Map;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A profiler for ABL.
 */
public final class AblProfiler
      implements AblListener {
   private static final Logger log = Logger.getLogger(AblProfiler.class.getName());
   
   /**
    * Toggle for turning off and on profiling.
    */
   private boolean profiling = true;

   /**
    * Event log storage.
    */
   private final List<String> eventsLog = new LinkedList<>();
   
   /**
    * Reference to the ABL debugger.
    * 
    * The debugger has organized access to the ABT's debug instantiation. We'll need this
    * for tree sampling.
    */
   private final Debugger ablDebugger;
  
   /**
    * A new trace listener to access formatBehaviorTrace().
    */

   // <event type, <step description, count>>
   private final Map<Integer, Map<String, Integer>> steps = new HashMap<>();
   // <event type, <behavior signature, count>>
   private final Map<Integer, Map<String, Integer>> behaviors = new HashMap<>();

   /**
    * Constructor.
    */
   private AblProfiler() {
      this.ablDebugger = BehavingEntity.getBehavingEntity().getDebuggerGUI();

      if (log.isLoggable(Level.FINER)) {
         // register this class with the debugger
         log.finer("Adding AblProfiler to the AblEvent stream.");
      }
      if (null != this.ablDebugger) {
         this.ablDebugger.addABLListener(this);
      }
   }
   
   /**
    * @return the debugger instance.
    */
   public Debugger getDebugger() {
      return ablDebugger;
   }

   @Override
   public void eventHappened(AblEvent e) {
      if (!this.profiling) {
         return;
      }
      this.eventsLog.add(e.toString());
      // System.out.println("got an AblEvent: " + e + ". New sizes: " +
      // this.steps.size() + ", " + this.behaviors.size());
      this.placeEventEntry(e);
   }

   /**
    * Processes an AblEvent and places information into the proper hashmap.
    * 
    * @param e The event.
    */
   private void placeEventEntry(AblEvent e) {
      // determine if the event represents a step or a behavior
      if (AblEvent.STEP == e.getSourceType()) {

         if (!this.steps.containsKey(e.getType())) {
            this.steps.put(e.getType(), new HashMap<String, Integer>());
         }
         Step step = (Step) e.getSource();
         String desc = step.toString();
         // String desc = this.tl.formatBehaviorTrace(e);

         Map<String, Integer> m = this.steps.get(e.getType());

         if (!m.containsKey(desc)) {
            m.put(desc, 1);
         } else {
            int count = m.get(desc);
            m.put(desc, ++count);
         }

      } else if (AblEvent.BEHAVIOR == e.getSourceType()) {
         if (!this.behaviors.containsKey(e.getType())) {
            this.behaviors.put(e.getType(), new HashMap<String, Integer>());
         }

         __BehaviorDesc behavior = (__BehaviorDesc) e.getSource();
         String desc = behavior.signature + ":" + behavior.behaviorID;
         // String desc = this.tl.formatBehaviorTrace(e);

         Map<String, Integer> m = this.behaviors.get(e.getType());

         if (!m.containsKey(desc)) {
            m.put(desc, 1);
         } else {
            int count = m.get(desc);
            m.put(desc, ++count);
         }

      }
   }

   /**
    * Starts the profiler.
    */
   public void on() {
      this.profiling = true;
   }

   /**
    * Stops the profiler.
    */
   public void off() {
      this.profiling = false;
   }

   /**
    * Removes all stored profiling data.
    */
   public void clear() {
      this.steps.clear();
      this.behaviors.clear();
      this.steps.clear();
      this.behaviors.clear();
   }

   /**
    * Prints all current profiling logs.
    */
   public void printLog() {
      this.printStepLog();
      this.printBehaviorLog();
   }

   /**
    * Prints the current step profiling log.
    */
   public void printStepLog() {
      if (log.isLoggable(Level.FINER)) {
         log.finer("Steps:");
         for (Map.Entry<Integer, Map<String, Integer>> category : this.steps.entrySet()) {
            log.finer("\t" + this.eventType(category.getKey()));
            for (Map.Entry<String, Integer> single : category.getValue().entrySet()) {
               log.finer("\t\t" + single.getValue() + "\t" + single.getKey());
            }
         }
      }
   }

   /**
    * Prints the current behavior profiling log.
    */
   public void printBehaviorLog() {
      if (log.isLoggable(Level.FINER)) {
         log.finer("Behaviors:");
         for (Map.Entry<Integer, Map<String, Integer>> category : this.behaviors.entrySet()) {
            log.finer("\t" + this.eventType(category.getKey()));
            for (Map.Entry<String, Integer> single : category.getValue().entrySet()) {
               log.finer("\t\t" + single.getValue() + "\t" + single.getKey());
            }
         }
      }
   }

   /**
    * Prints the current event log
    */
   public void printEventLog() {
      if (log.isLoggable(Level.FINER)) {
         log.finer("Events");
         for (String event : eventsLog) {
            log.finer(event);
         }
      }
   }

   /**
    * Prints the current step profiling log.
    * 
    * @return step profile
    */
   public List<String> getStepProfile() {
      List<String> prof = new LinkedList<>();
      prof.add("Steps:");

      for (Map.Entry<Integer, Map<String, Integer>> category : this.steps.entrySet()) {
         prof.add("\t" + this.eventType(category.getKey()));
         for (Map.Entry<String, Integer> single : category.getValue().entrySet()) {
            prof.add("\t\t" + single.getValue() + "\t" + single.getKey());
         }
      }
      return prof;
   }

   /**
    * Prints the current behavior profiling prof.
    * 
    * @return behavior profile
    */
   public List<String> getBehaviorProfile() {
      List<String> prof = new LinkedList<>();
      prof.add("Behaviors:");

      for (Map.Entry<Integer, Map<String, Integer>> category : this.behaviors.entrySet()) {
         prof.add("\t" + this.eventType(category.getKey()));
         for (Map.Entry<String, Integer> single : category.getValue().entrySet()) {
            prof.add("\t\t" + single.getValue() + "\t" + single.getKey());
         }
      }
      return prof;
   }

   /**
    * Returns the basic type name from an AblEvent type "enum".
    * 
    * NOTE: This function is adapted from
    * abl.runtime.Debugger.TraceListener.formatBehaviorTrace().
    * 
    * @param type An AblEvent type int.
    * @return Label associated with the event type.
    */
   private String eventType(int type) {
      String name = null;
      if (type < TYPE_NAMES.length) {
         name = TYPE_NAMES[type];
      }
      return name != null ? name : "unrecognized action " + type;
   }

   private static AblProfiler singleton;

   /**
    * Static getter method for retrieving the singleton instance
    * 
    * @return Instance of AblProfiler
    */
   public static AblProfiler getInstance() {
      if (singleton == null) {
         singleton = new AblProfiler();
      }
      return singleton;
   }
   
   
   private static final String[] TYPE_NAMES = new String[25];

   static {
      TYPE_NAMES[AblEvent.PRECONDITION_EXECUTION] = "precondition execution";
      TYPE_NAMES[AblEvent.BEHAVIOR_EXECUTION] = "behavior execution";
      TYPE_NAMES[AblEvent.BEHAVIOR_COMPLETION] = "behavior completion";
      TYPE_NAMES[AblEvent.CONTEXT_CONDITION_FAILURE] = "context condition failed";
      TYPE_NAMES[AblEvent.ACT_EXECUTION] = "act execution";
      TYPE_NAMES[AblEvent.ACT_COMPLETION] = "act completion";
      TYPE_NAMES[AblEvent.SUBGOAL_EXECUTION] = "subgoal execution";
      TYPE_NAMES[AblEvent.SUBGOAL_COMPLETION] = "subgoal completion";
      TYPE_NAMES[AblEvent.MENTAL_STEP_EXECUTION] = "mental step execution";
      TYPE_NAMES[AblEvent.MENTAL_STEP_COMPLETION] = "mental step completion";
      TYPE_NAMES[AblEvent.WAIT_STEP_COMPLETION] = "wait step completion";
      TYPE_NAMES[AblEvent.FAILSTEP_EXECUTION] = "failstep execution";
      TYPE_NAMES[AblEvent.FAILSTEP_COMPLETION] = "failstep failed";
      TYPE_NAMES[AblEvent.SUCCEEDSTEP_EXECUTION] = "succeedstep execution";
      TYPE_NAMES[AblEvent.SUCCEEDSTEP_COMPLETION] = "succeedstep succeeded";
      TYPE_NAMES[AblEvent.STEP_SUSPENSION] = "step suspension";
      TYPE_NAMES[AblEvent.STEP_UNSUSPENSION] = "step unsuspension";
      TYPE_NAMES[AblEvent.SUCCESS_TEST_SUCCESS] = "success test success";
      TYPE_NAMES[AblEvent.SPAWNGOAL_AT_ROOT] = "re-rooting subgoal at ABT root";
      TYPE_NAMES[AblEvent.INITIATE_NEGOTIATION] = "initiating negotiation";
      TYPE_NAMES[AblEvent.COMPLETE_NEGOTIATION] = "completing negotiation";
      TYPE_NAMES[AblEvent.INITIATE_INTENTION] = "initiating intention";
      TYPE_NAMES[AblEvent.COMMIT_TO_INTENTION] = "committing to intention";
      TYPE_NAMES[AblEvent.PROCESS_INTENTION] = "process intention";
   }

}
