package abl.runtime;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import abl.runtime.BehavingEntity.BehaviorLibrary;

/**
 * 
 * Interface for receiving notification of new decision cycles in ABL
 * 
 * @author Ben Weber, April Grow
 */
public interface BehavingListener 
      extends Serializable {

   /**
    * Invoked at the start of each ABL decision cycle
    * 
    * @param executingSteps - executing steps in the ABT
    * @param leafSteps - leaf steps in the ABT
    */
   public void onBehave(Map<String, Set<Step>> executingSteps, Set<Step> leafSteps);
   
   /**
    * Invoked at the start of each ABL decision cycle
    * 
    * @param executingSteps - executing steps in the ABT
    * @param leafSteps - leaf steps in the ABT
    */
   public void onLoad(BehaviorLibrary individualBehaviorLibrary, BehaviorLibrary jointBehaviorLibrary);
}
