package abl.learning;

public interface Action {
}
