/*
 * Created on Feb 3, 2005
 *
 */
package abl.learning;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Basic Q-learning over discrete states and actions. It is assumed all actions
 * are available in all states.
 * 
 * @author Sooraj Bhat
 */
public class QLearner
      implements Serializable {
   double learningRate = 0.1;
   double discountFactor = 0.9;
   Map qTable = new HashMap(); // Map<State,Map<Action,Double>>
   List allActions;
   Random random = new Random();

   static final long serialVersionUID = 3503118303158320040L;

   /**
    * @param allActions An array of all possible actions the agent can take.
    */
   public QLearner(Action[] allActions) {
      assert allActions.length > 0 : "Number of actions not a positive integer: " + allActions.length;
      this.allActions = new ArrayList(Arrays.asList(allActions)); // make my own
                                                                  // copy
   }

   /**
    * Selects the best action to take in the specified state, as prescribed by
    * the learned policy.
    * 
    * @param state The specified state.
    * @return The best action to take in the specified state.
    */
   public Action selectAction(State state) {
      if (theRound++ < 100) {
         return selectRandomAction(state);
      }
      // explore something random 10% of the time
      if (random.nextInt(3) == 0) {
         return selectRandomAction(state);
      }
      List best = getArgmaxQValue(state);
      return (Action) best.get(random.nextInt(best.size()));
      // double[] values = getQValues(state);
      // return (Action)allActions.get(sample(values));
   }

   @SuppressWarnings("unused")
   private double[] getQValues(State state) {
      double[] values = new double[allActions.size()];
      for (int i = 0; i < allActions.size(); i++) {
         values[i] = getQValue(state, (Action) allActions.get(i));
      }
      return values;
   }

   private int theRound;
   
   @SuppressWarnings("unused")
   private double Tcount;

   private double T() {
      return 1;
   } // { return 1000/Math.sqrt(++Tcount); }

   // Boltzmann sampling
   @SuppressWarnings("unused")
   private int sample(double[] values) {
      // compute unnormalized CDF
      double[] cdf = new double[values.length + 1];
      cdf[0] = 0.0;
      double expval;
      double sum = 0.0;
      for (int i = 0; i < values.length; i++) {
         expval = Math.exp(values[i]) / T();
         sum += expval;
         cdf[i + 1] = cdf[i] + expval;
      }

      // sample from the CDF
      double randval = Math.random() * sum;
      for (int i = 0; i < cdf.length - 1; i++) {
         if (cdf[i] <= randval && randval <= cdf[i + 1]) {
            return i;
         }
      }
      assert false;
      return -1; // quiet the compiler
   }

   /**
    * Selects a random action, unconditional (for now) of the current state
    */
   Action selectRandomAction(State state) {
      // System.out.println("selectRandomAction()");
      return (Action) allActions.get(random.nextInt(allActions.size()));
   }

   public void update(State prevState, Action prevAction, double reward, State currState) {
      double oldQValue = getQValue(prevState, prevAction);
      double newQValue = (1 - learningRate) * oldQValue + learningRate * (reward + discountFactor * getMaxQValue(currState));
      setQValue(prevState, prevAction, newQValue);
      // System.out.println("UPDATE reward "+reward+" old "+oldQValue+" new "+newQValue);
   }

   void setQValue(State state, Action action, double qValue) {
      Map qVector = (Map) qTable.get(state);
      if (qVector == null) {
         // no actions associated with this state yet
         qVector = new HashMap();
         qTable.put(state, qVector);
      }
      qVector.put(action, qValue);
   }

   double getQValue(State state, Action action) {
      Map qVector = (Map) qTable.get(state);
      if (qVector == null) {
         return 0.0;
      }
      Double qValue = (Double) qVector.get(action);
      if (qValue == null) {
         return 0.0;
      }
      return qValue;
   }

   /**
    * @param state
    * @return The maximum q-value over the actions at this state.
    */
   double getMaxQValue(State state) {
      List best = getArgmaxQValue(state);
      return getQValue(state, (Action) best.get(0));
   }

   /**
    * @param state
    * @return The actions which maximize the q-value at this state.
    */
   List getArgmaxQValue(State state) {
      // if there are no mappings, then they have not been filled yet, and must
      // have
      // q-value == 0, so all actions are the "best".
      Map qVector = (Map) qTable.get(state);
      if (qVector == null) {
         return allActions;
      }
      Set entries = qVector.entrySet();
      if (entries == null) {
         return allActions;
      }

      // fixme: Need to return *all* actions that have the max, right now,
      // the loop only keeps track of one max...the behavior is correct if
      // there are no mappings yet (i.e. q-value == 0, see above)

      // loop over the actions to find the max q-value
      double maxQValue = Double.NEGATIVE_INFINITY;
      Map.Entry maxEntry = null;
      for (Object entry1 : entries) {
         Map.Entry entry = (Map.Entry) entry1;
         Double qValue = (Double) entry.getValue();
         // System.out.println("getArgmaxQValue(): considering entry="+entry);
         if (qValue > maxQValue) {
            maxQValue = qValue;
            maxEntry = entry;
         }
      }

      List best = null;
      Set actions = qVector.keySet();
      // if the best value is negative and there are actions that have not been
      // mapped yet,
      // then the best actions are the ones we haven't found a mapping for,
      // which have q-value == 0
      
      /*
       * FIXME This will throw an NPE if entries is empty.
       * 
       * An earlier check ensures that entries is not null but does NOT ensure it
       * isn't empty. Almost certainly it should
       */
      if ((Double) maxEntry.getValue() < 0 && actions.size() != allActions.size()) {
         best = new ArrayList(allActions);
         best.removeAll(actions);
      } else {
         best = new ArrayList();
         best.add(maxEntry.getKey());
      }
      // System.out.println("getArgmaxQValue(): returning action(s): "+best);
      return best;
   }
}
