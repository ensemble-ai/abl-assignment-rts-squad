/*
 * Created on March 28, 2006
 *
 */
package abl.learning;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * This is an implementation of the MAXQ-Q learning algorithm. See Dietterich's
 * MAXQ work for more detail.
 * 
 * @author Sooraj Bhat
 */
public class MaxqqLearner {
   double epsilon = 0.1; // for epsilon-greedy exploration
   double learningRate = 0.1; // "alpha"
   double discountFactor = 0.9; // "gamma"
   Action[] actions;
   Random random = new Random();
   SparseTable qTable = new SparseTable();

   /**
    * @param actions An array of all possible actions the agent can take.
    */
   public MaxqqLearner(Action[] actions) {
      assert actions.length > 0 : "Number of actions not a positive integer: " + actions.length;
      this.actions = new Action[actions.length];
      System.arraycopy(actions, 0, this.actions, 0, actions.length); // make a
                                                                     // copy
   }

   /**
    * Selects an action to take in the specified state, as prescribed by the
    * learned policy.
    * 
    * @param state The specified state.
    * @return The best action to take in the specified state.
    */
   public Action selectAction(State state) {
      if (shouldExplore()) {
         return selectRandomAction(state);
      }
      List best = getArgmaxQValue(state);
      if (best.isEmpty()) {
         return selectRandomAction(state);
      }
      return (Action) best.get(random.nextInt(best.size()));
   }

   boolean shouldExplore() {
      return random.nextDouble() < epsilon;
   }

   /**
    * Selects a random action, unconditional (for now) of the current state
    */
   Action selectRandomAction(State state) {
      return actions[random.nextInt(actions.length)];
   }

   public void update(State prevState, Action prevAction, double reward, State currState) {
      double oldQValue = (Double) qTable.get(prevState, prevAction);
      double newQValue = (1 - learningRate) * oldQValue + learningRate * (reward + discountFactor * getMaxQValue(currState));
      qTable.set(prevState, prevAction, newQValue);
   }

   /**
    * @param state
    * @return The maximum q-value over actions for this state.
    */
   double getMaxQValue(State state) {
      List best = getArgmaxQValue(state);
      return (Double) qTable.get(state, best.get(0));
   }

   /**
    * @param state
    * @return All actions which maximize the q-value at this state.
    */
   List getArgmaxQValue(State state) {
      List result = new ArrayList();
      Object[] qvalues = new Object[actions.length];
      for (int i = 0; i < actions.length; i++) {
         qvalues[i] = qTable.get(state, actions[i]);
      }
      Object max = Collections.max(Arrays.asList((Double[]) qvalues));
      for (int i = 0; i < actions.length; i++) {
         if (max.equals(qvalues[i])) {
            result.add(actions[i]);
         }
      }
      return result;
   }
}
