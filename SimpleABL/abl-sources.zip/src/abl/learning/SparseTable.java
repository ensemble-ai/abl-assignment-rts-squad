package abl.learning;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Implemenation of a sparse 2D matrix of Objects. The default value for
 * unitialized cells is a new Double equal to 0.0; in the future this can be
 * made more general with a user-defined default value.
 * 
 * @author Sooraj Bhat
 */
public class SparseTable {
   public SparseTable() {
   }

   public void set(Object x, Object y, Object v) {
      ((Map) table.get(x)).put(y, v);
   }

   public Object get(Object x, Object y) {
      return ((Map) table.get(x)).get(y);
   }

   private final static Double zero = 0.0;
   private DefaultValueFactory zeros = new DefaultValueFactory() {
      @Override
      public Object value() {
         return zero;
      }
   };
   private DefaultValueFactory zeromaps = new DefaultValueFactory() {
      @Override
      public Object value() {
         return new DefaultMap(zeros, false);
      }
   };
   private Map table = new DefaultMap(zeromaps, true);

   interface DefaultValueFactory {
      public Object value();
   }

   class DefaultMap
         extends LinkedHashMap {
      DefaultValueFactory f;
      boolean shouldPut;

      DefaultMap(DefaultValueFactory f, boolean shouldPut) {
         super();
         this.f = f;
         this.shouldPut = shouldPut;
      }

      @Override
      public Object get(Object key) {
         if (!containsKey(key)) {
            Object value = f.value();
            if (shouldPut) {
               put(key, value);
            }
            return value;
         }
         return super.get(key);
      }
   }

   /** for testing **/
   public static void main(String[] args) {
      SparseTable t = new SparseTable();
      System.out.println(t.get("a", "a"));
      t.set("a", "a", 3.0);
      System.out.println(t.get("a", "a"));
   }
}
