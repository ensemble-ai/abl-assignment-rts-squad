/* MethodDescriptor. Syntactic descriptor for a Java method. */

package jd;

import java.io.StringWriter;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class MethodDescriptor
      extends CodeBlockDescriptor {
   private List methodModifiers = new LinkedList();
   private MethodArglistDescriptor methodArguments = new MethodArglistDescriptor();
   private Set localVarNames = new HashSet();
   public String methodName;

   /* The method body is maintained by super.blockBody. */

   public void addModifier(String s) {
      methodModifiers.add(s);
   }

   public void addArgument(MethodArgDescriptor a) {
      methodArguments.addArgument(a);
   }

   public void addArgument(String argumentType, String argumentName) {
      MethodArgDescriptor a = new MethodArgDescriptor();

      a.argType = argumentType;
      a.argName = argumentName;
      methodArguments.addArgument(a);
   }

   public void addLocalVariableDecl(FieldDescriptor field) {
      @SuppressWarnings("unused")
      String fieldType;
      String[] fieldNames;

      addToBlockBody(field);
      fieldNames = field.getFieldNames();
      for (String fieldName : fieldNames) {
         if (localVarNames.contains(fieldName)) {
            throw new JavaDescriptorError("Variable " + fieldName + " multiply defined in MethodDescriptor " + methodName);
         } else {
            localVarNames.add(fieldName);
         }
      }
   }

   @Override
   public String toString(int nestLevel) {
      blockHeader = methodSignatureString() + " {";
      blockFooter = "}";
      return super.toString(nestLevel);
   }

   protected String methodSignatureString() {
      StringWriter tempBuffer = new StringWriter();

      // Output the method modifiers and method name
      for (Object methodModifier : methodModifiers) {
         tempBuffer.write(methodModifier + " ");
      }

      tempBuffer.write(methodName);

      // Output the arglist
      tempBuffer.write(methodArguments.toString());

      return tempBuffer.toString();
   }

   /*
    * Block headers should not be set directy on a MethodDescriptor.
    */
   @Override
   public void setBlockHeader(String headerToSet) {
      throw new JavaDescriptorError("setBlockHeader() should not be called on a MethodDescriptor.");
   }

   /*
    * Block footers should not be set directy on a MethodDescriptor.
    */
   @Override
   public void setBlockFooter(String footerToSet) {
      throw new JavaDescriptorError("setBlockFooter() should not be called on a MethodDescriptor.");
   }
}
