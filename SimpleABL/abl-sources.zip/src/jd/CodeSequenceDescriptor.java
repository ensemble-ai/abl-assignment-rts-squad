package jd;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CodeSequenceDescriptor
      extends NestableCodeDescriptor {
   private List sequence = new ArrayList(100);

   public CodeSequenceDescriptor() {
   }

   public void addToSequence(NestableCodeDescriptor n) {
      sequence.add(n);
   }

   public void addToSequence(NestableCodeDescriptor[] n) {
      Collections.addAll(sequence, n);
   }

   @Override
   public String toString(int nestLevel) {
      // fixme: create a constant at the top of the jd class hierarchy with a
      // default buffer value
      StringWriter tempBuffer = new StringWriter(1024);
      PrintWriter tempPrinter = new PrintWriter(tempBuffer);

      for (Object aSequence : sequence) {
         NestableCodeDescriptor descriptor = (NestableCodeDescriptor) aSequence;
         if (descriptor.getClass().getName().equals("jd.CodeSequenceDescriptor")) {
            tempPrinter.println(descriptor.toString(nestLevel));
         } else {
            tempPrinter.println(descriptor.toString(nestLevel + 1));
         }
      }

      return tempBuffer.toString();
   }

}
