/* Class that stores the description of a class. Unlike the reflection API, which supports getting information
   at runtime about already compiled classes, this class is designed to facilitate the construction of class
   declarations at runtime. */

package jd;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import abl.compiler.ASTBehaviorUnit;

public class ClassDescriptor
      extends CodeBlockDescriptor {

   public String packageName;
   private List<String> imports = new LinkedList<String>();
   public String className;
   private List classModifiers = new LinkedList();
   private List fieldMembers = new LinkedList();
   private List methodMembers = new LinkedList();
   private List staticBlocks = new ArrayList();
   public String extendsClass;
   private List interfaces = new LinkedList();
   
   @SuppressWarnings("unused")
   private int nestLevel;

   public void addPackageImport(String importPackage) {
      imports.add(importPackage);
   }

   public void addField(FieldDescriptor f) {
      fieldMembers.add(f);
   }

   public void addField(String[] fieldModifiers, String typeName, String fieldName, String initializer) {
      FieldDescriptor f = new FieldDescriptor();

      f.fieldType = typeName;
      f.addFieldName(fieldName);
      f.addFieldModifiers(fieldModifiers);
      f.initializer = initializer;
      fieldMembers.add(f);
   }

   public FieldDescriptor[] getFields() {
      List fieldArray = new LinkedList();
      FieldDescriptor tempField;
      FieldDescriptor currentField;

      for (Object fieldMember : fieldMembers) {
         currentField = (FieldDescriptor) fieldMember;
         String[] fieldNames = currentField.getFieldNames();
         String fieldType = currentField.fieldType;
         tempField = new FieldDescriptor();
         for (String fieldName : fieldNames) {
            tempField.fieldType = fieldType;
            tempField.addFieldName(fieldName);
         }
         fieldArray.add(tempField);
      }
      Object[] objArray = fieldArray.toArray();
      FieldDescriptor[] fdArray = new FieldDescriptor[objArray.length];
      System.arraycopy(objArray, 0, fdArray, 0, objArray.length);
      return fdArray;
   }

   public void addMethod(MethodDescriptor m) {
      methodMembers.add(m);
   }

   public void addClassModifier(String s) {
      classModifiers.add(s);
   }

   public void addInterface(String s) {
      interfaces.add(s);
   }

   public void addStaticBlock(CodeStringDescriptor desc) {
      CodeBlockDescriptor staticBlock = new CodeBlockDescriptor();
      staticBlock.setBlockHeader("static {");
      staticBlock.addToBlockBody(desc);
      staticBlock.setBlockFooter("}");
      staticBlocks.add(staticBlock);
   }

   @Override
   public String toString(int level) {
      StringWriter tempWriter = new StringWriter();
      PrintWriter tempPrinter = new PrintWriter(tempWriter);

      if (className == null) {
         throw new JavaDescriptorError("Attempt to call toString(int) on an instance of ClassDescriptor without a specified class name");
      }

      ListIterator<String> iter;

      // First create the block header.

      // Add the package (with a newline) to the block header.
      if (packageName != null) {
         tempPrinter.println("package " + packageName + ";");
         tempPrinter.println();
      }

      // Add the package imports to the block header.
      if (!imports.isEmpty()) {
         iter = imports.listIterator();
         while (iter.hasNext()) {
            String importName = iter.next();
            // Need to ensure that any inner class imports have '$' converted back to '.'
            importName = ASTBehaviorUnit.convertInnerJavaNameToUserName(importName);
            tempPrinter.println("import " + importName + ";");
         }
         tempPrinter.println();
      }

      // Output the class modifiers

      tempWriter.write(delimitedList(classModifiers.toArray(), " "));
      if (!classModifiers.isEmpty()) {
         tempWriter.write(" ");
      }

      // Output the class name
      tempWriter.write("class " + className);

      if (extendsClass != null) {
         tempWriter.write(" extends " + extendsClass);
      }

      if (!interfaces.isEmpty()) {
         tempWriter.write(" implements " + delimitedList(interfaces.toArray(), ", "));
      }

      tempWriter.write(" {");
      blockHeader = tempWriter.toString();

      // Create the block footer.
      blockFooter = "}";

      // Copy the fields and methods into the blockBody.
      blockBody.clear();
      blockBody.addAll(fieldMembers);
      blockBody.add(new BlanklineDescriptor());
      blockBody.addAll(staticBlocks);
      blockBody.add(new BlanklineDescriptor());
      blockBody.addAll(methodMembers);

      // Return the string representation of this class.
      return super.toString(level);
   }

   /*
    * Block headers should not be set directy on a ClassDescriptor.
    */
   @Override
   public void setBlockHeader(String headerToSet) {
      throw new JavaDescriptorError("setBlockHeader() should not be called on a ClassDescriptor.");
   }

   /*
    * Block footers should not be set directy on a ClassDescriptor.
    */
   @Override
   public void setBlockFooter(String footerToSet) {
      throw new JavaDescriptorError("setBlockFooter() should not be called on a ClassDescriptor.");
   }

   /*
    * The block body should not be set directly on a ClassDescriptor.
    */
   @Override
   public void addToBlockBody(NestableCodeDescriptor n) {
      throw new JavaDescriptorError("addToBlockBody() should not be called on a ClassDescriptor.");
   }

   private void writeToFileHelper(File directory, String codeToWrite) {
      try (PrintStream classStream = new PrintStream(new FileOutputStream(new File(directory, className + ".java")))) {
         classStream.print(codeToWrite);
         classStream.close();
      } catch (IOException e) {
         throw new JavaDescriptorError("Error writing " + className + ".java", e);
      }
   }

   // If the generated java file is the same, don't replace (speeds up jikes
   // compilation).
   public boolean writeToFile(File directory) {
      String newJavaCode = this.toString();
      
      try (BufferedReader classReader = new BufferedReader(new FileReader(new File(directory, className + ".java")))) {
         StringBuilder javaCode = new StringBuilder(8000);
         try {
            for (int c = classReader.read(); c != -1; c = classReader.read()) {
               javaCode.append((char) c);
            }
            classReader.close();
         } catch (IOException e) {
            // An IOException occured while trying to read the .java file. Report
            // the error.
            throw new JavaDescriptorError("Error reading " + className + ".java", e);
         }
         if (!javaCode.toString().equals(newJavaCode)) {
            // code isn't equal - write the new code
            writeToFileHelper(directory, newJavaCode);
            return true;
         } else {
            return false;
         }
      } catch (IOException e) {
         writeToFileHelper(directory, newJavaCode);
         return true;
      }
   }

   // code to test compiling as public static nested classes
   public void writeNestedClassToStream(PrintStream stream) {
      addClassModifier("static");
      stream.print(toString());
   }

}
