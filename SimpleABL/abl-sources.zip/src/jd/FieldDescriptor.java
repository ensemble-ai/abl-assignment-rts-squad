package jd;

import java.util.LinkedList;
import java.util.List;

public class FieldDescriptor
      extends CodeStringDescriptor {
   public String fieldType;
   private List fieldNames = new LinkedList();
   private List fieldModifiers = new LinkedList();
   public String initializer;

   public FieldDescriptor() {
      fieldType = null;
      initializer = null;
   }

   public void addFieldModifier(String s) {
      fieldModifiers.add(s.intern());
   }

   public void addFieldModifiers(String[] s) {
      for (String value : s) {
         addFieldModifier(value.intern());
      }
   }

   public void addFieldName(String s) {
      fieldNames.add(s.intern());
   }

   public String[] getFieldNames() {
      Object[] objArray = fieldNames.toArray();
      String[] fNames = new String[objArray.length];
      System.arraycopy(objArray, 0, fNames, 0, objArray.length);
      return fNames;
   }

   @Override
   public int hashCode() {
      int hashValue = fieldType.hashCode();
      for (Object fieldName : fieldNames) {
         hashValue += fieldName.hashCode();
      }
      return hashValue;
   }

   @Override
   public boolean equals(Object obj) {
      if (obj.getClass() != this.getClass()) {
         return false;
      }

      FieldDescriptor fieldDescriptorToCompare = (FieldDescriptor) obj;
      if (fieldDescriptorToCompare.fieldType != fieldType) {
         return false;
      }

      String[] fieldNamesToCompare = fieldDescriptorToCompare.getFieldNames();
      if (fieldNamesToCompare.length != fieldNames.size()) {
         return false;
      }

      int i, j;
      for (i = 0; i < fieldNamesToCompare.length; i++) {
         for (j = 0; j < fieldNames.size(); j++) {
            if (fieldNamesToCompare[i] == fieldNames.get(j)) {
               break;
            }
         }
         if (j >= fieldNames.size()) {
            return false;
         }
      }
      return true;
   }

   @Override
   public String toString(int nestLevel) {
      codeString = fieldDeclarationString();
      return super.toString(nestLevel);
   }

   protected String fieldDeclarationString() {
      StringBuilder tempBuffer = new StringBuilder();

      tempBuffer.append(delimitedList(fieldModifiers.toArray(), " "));
      /*
       * for(int i = 0; i < fieldModifiers.size(); i++) {
       * tempBuffer.append((String)fieldModifiers.get(i)); }
       */
      if (!fieldModifiers.isEmpty()) {
         tempBuffer.append(" ");
      }

      tempBuffer.append(fieldType).append(" ");
      tempBuffer.append(delimitedList(fieldNames.toArray(), ", "));

      if (initializer != null) {
         tempBuffer.append(" = ").append(initializer);
      }
      tempBuffer.append(";");

      return tempBuffer.toString();
   }

   /*
    * The code string should not be set directly on a FieldDescriptor.
    */
   @Override
   public void setCodeString(String codeStringToSet) {
      throw new JavaDescriptorError("setCodeString() should not be called on a FieldDescriptor.");
   }
}
