/* MethodArglistDescriptor. Syntactic descriptor for the list of
   arguments in a method signature. */

package jd;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MethodArglistDescriptor
      extends JavaCodeDescriptor {
   private List methodArgs = new ArrayList();
   private Map argIndexTable = new HashMap();
   private int argIndexCounter;

   public void addArgument(MethodArgDescriptor m) {
      methodArgs.add(m);
      argIndexTable.put(m.argName, argIndexCounter++);
   }

   /*
    * Returns an array of the MethodArgDescriptors stored in this
    * MethodArglistDescriptor.
    */
   public Object[] getArguments() {
      return methodArgs.toArray();
   }

   @Override
   public String toString() {
      StringWriter tempBuffer = new StringWriter();

      tempBuffer.write("(");
      List args = new LinkedList();
      for (Object methodArg : methodArgs) {
         args.add(methodArg.toString());
      }

      tempBuffer.write(delimitedList(args.toArray(), ", "));
      tempBuffer.write(")");

      return tempBuffer.toString();
   }

   public int getArgIndex(String argName) {
      Integer argIndexInt = (Integer) argIndexTable.get(argName);

      // fixme: change this to a specialized exception
      if (argIndexInt == null) {
         throw new Error("Unknown argument name " + argName);
      }
      return argIndexInt;
   }
}
