package jd;

public abstract class JavaCodeDescriptor {
   @Override
   public abstract String toString();

   protected static String delimitedList(Object[] l, String delimiter) {

      if (l.length == 0) {
         return "";
      } else if (l.length == 1) {
         return (String) l[0];
      } else {
         StringBuilder tempBuffer = new StringBuilder();
         for (int i = 0; i < l.length - 1; i++) {
            tempBuffer.append((String) l[i]).append(delimiter);
         }
         tempBuffer.append((String) l[l.length - 1]);
         return tempBuffer.toString();
      }
   }
}
