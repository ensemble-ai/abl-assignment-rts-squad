package jd;

public abstract class NestableCodeDescriptor
      extends JavaCodeDescriptor {

   public abstract String toString(int nestLevel);

   // The number of spaces corresponding to a tab.
   private final static String tabSpaces = "   ";

   @Override
   public String toString() {
      return toString(0);
   }

   public static String leadingTabs(int tabCount) {
      StringBuilder tempBuffer = new StringBuilder();

      for (int i = 0; i < tabCount; i++) {
         tempBuffer.append(tabSpaces);
      }
      return tempBuffer.toString();
   }
}
