package jd;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class CodeBlockDescriptor
      extends NestableCodeDescriptor {

   protected String blockHeader;
   protected String blockFooter;
   protected List blockBody = new LinkedList();

   public CodeBlockDescriptor() {
      blockHeader = null;
      blockFooter = null;
   }

   public CodeBlockDescriptor(String headerToSet, String footerToSet) {
      blockHeader = headerToSet;
      blockFooter = footerToSet;
   }

   public void setBlockHeader(String headerToSet) {
      blockHeader = headerToSet;
   }

   public void setBlockFooter(String footerToSet) {
      blockFooter = footerToSet;
   }

   public void addToBlockBody(NestableCodeDescriptor n) {
      blockBody.add(n);
   }

   public void addToBlockBody(NestableCodeDescriptor[] n) {
      Collections.addAll(blockBody, n);
   }

   @Override
   public String toString(int nestLevel) {
      StringWriter tempBuffer = new StringWriter(1024);
      PrintWriter tempPrinter = new PrintWriter(tempBuffer);

      if (blockHeader != null) {
         tempPrinter.print(leadingTabs(nestLevel));
         tempPrinter.println(blockHeader);
      }

      for (Object aBlockBody : blockBody) {
         NestableCodeDescriptor descriptor = (NestableCodeDescriptor) aBlockBody;
         if (descriptor.getClass().getName().equals("jd.CodeSequenceDescriptor")) {
            tempPrinter.println(descriptor.toString(nestLevel));
         } else {
            tempPrinter.println(descriptor.toString(nestLevel + 1));
         }

      }

      if (blockFooter != null) {
         tempPrinter.print(leadingTabs(nestLevel));
         tempPrinter.println(blockFooter);
      }
      return tempBuffer.toString();
   }
}
