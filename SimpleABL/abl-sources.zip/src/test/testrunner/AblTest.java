package test.testrunner;

import java.util.HashSet;
import java.util.Set;

import abl.compiler.Abl;
import abl.compiler.CompileWarning;
import abl.compiler.util.FindOption;
import abl.compiler.util.Option;
import fun.Fun;

/**
 * A class encompassing the test of one ABL file.
 * 
 */
public class AblTest {

   public static enum Status {
      SUCCESS, FAILURE
   }

   public Status testStatus;

   public final Set<Throwable> empty = new HashSet<>();

   private final Set<Throwable> expectedThrown;

   private String ablFile;

   private int expectedWarnCount;

   public AblTest(final String ablFile, final int expectedWarnCount, final Set<Throwable> expectedThrowables) {
      this.ablFile = ablFile;
      this.expectedThrown = expectedThrowables;
      this.expectedWarnCount = expectedWarnCount;
   }

   public String getAblFile() {
      return ablFile;
   }

   /**
    * Compile our file.
    */
   public void compile() {
      Set<Throwable> tmpExpected = new HashSet<>(expectedThrown);

      try {
         Abl.compileFile(ablFile);
      } catch (final Exception e) {
         reportErrorIfUnexpected(e, tmpExpected);
      }

      testStatus =
            tmpExpected.isEmpty() && expectedWarnCount == CompileWarning.warnCount && testStatus != Status.FAILURE ? Status.SUCCESS
                  : Status.FAILURE;
      if (expectedWarnCount != CompileWarning.warnCount) {
         System.out.println("Test Error: Expected " + expectedWarnCount + " warnings, got " + CompileWarning.warnCount);
      }

      if (!tmpExpected.isEmpty()) {
         System.out.println("Test Error: Never got expected exceptions: " + tmpExpected);
      }
   }

   class InstanceOfPredicate
         extends Fun<Throwable, Boolean> {

      private Throwable t;

       InstanceOfPredicate(final Throwable t) {
         this.t = t;
      }

      @Override
      public Boolean apply(Throwable item) {
         return item.getClass().isAssignableFrom(t.getClass());
      }
   }

   // This method will change the testStatus if the test fails.
   private void reportErrorIfUnexpected(final Exception e, final Set<Throwable> exp) {

      // If `e' is not an expected exception, report an error on the screen &
      // the exception
      // info.
      Option<Throwable> o = new FindOption<Throwable>().apply(new InstanceOfPredicate(e), exp.iterator());
      switch (o.type) {
         case SOME:
            exp.remove(o.getData());
            break;

         case NONE:
            testStatus = Status.FAILURE;
            System.out.println("Test Error: On file " + ablFile + ", got unexpected exception: " + e);
            break;

      }
   }

   @Override
   public String toString() {
      return getClass() + " of " + getAblFile();
   }

}
