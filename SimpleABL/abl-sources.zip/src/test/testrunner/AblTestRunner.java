package test.testrunner;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import tuple.Triple;
import abl.compiler.CompileWarning;
import abl.compiler.util.VoidType;
import fun.Fun;
import fun.Map;

public class AblTestRunner {

   static class TestEntry
         extends Triple<String, Integer, Set<Throwable>> {
      TestEntry(String x, Integer y, Set<Throwable> z) {
         super(x, y, z);
      }
   }

   private static List<TestEntry> tests = new ArrayList<>();
   private static final String testDir = "src/test";

   /**
    * Add a test to the ABL test runner.
    * 
    * @param filename the filename of the test, relative to
    *        {@link AblTestRunner#testDir}.
    * @param expectedExceptions an array of exceptions one expects the test to
    *        throw; can be empty.
    */
   static void addTest(String filename, int warningCount, Throwable... expectedExceptions) {
      tests.add(new TestEntry(filename, warningCount, new HashSet<>(Arrays.asList(expectedExceptions))));
   }

   /**
    * Construct an AblTest from the filename an the set of expected throwables.
    * 
    */
   private static class ConstructTest
         extends Fun<TestEntry, AblTest> {
      @Override
      public AblTest apply(TestEntry x) {
         final String filename = new File(testDir, x.get1()).getAbsolutePath();
         final Integer expectedWarnCount = x.get2();
         final Set<Throwable> expectedExceptions = x.get3();
         return new AblTest(filename, expectedWarnCount, expectedExceptions);
      }
   }

   /**
    * Run tests & exit when done.
    */
   static void runTests() {
      // Construct AblTests.
      final Iterator<AblTest> testIter = Map.map(new ConstructTest(), tests.iterator());
      final List<AblTest> failed = new ArrayList<>();

      System.out.println("Running ABL file compiler tests...");

      // Run AblTests.
      while (testIter.hasNext()) {
         CompileWarning.warnCount = 0; // Reset warning count.
         final AblTest test = testIter.next();
         System.out.println("Testing " + test.getAblFile() + "...");

         // Test compiling the given file.
         test.compile();

         if (test.testStatus == AblTest.Status.FAILURE) {
            failed.add(test);
         }
         System.out.println("");
      }

      exitTestRunner(failed);
   }

   private static class PrintFilename
         extends Fun<AblTest, VoidType> {
      @Override
      public VoidType apply(AblTest x) {
         System.out.println("    " + x.getAblFile());
         return VoidType.VOID;
      }
   }

   private static final PrintFilename printFilename = new PrintFilename();

   /**
    * Exit the test runner with the correct exit code & printing a message.
    * 
    * @param failed the set of failed tests
    */
   private static void exitTestRunner(final Collection<AblTest> failed) {
      final int failureCount = failed.size();
      if (failureCount > 0) {
         System.out.println("ABL Test Summary:");
         System.out.println("Failed file(s): ");
         Map.map(printFilename, failed.iterator());
         System.out.println(tests.size() + " test(s), " + failureCount + " failure(s).");
      }

      System.exit(failureCount);
   }
}
