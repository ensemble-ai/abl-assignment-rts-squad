package test.testrunner;

import abl.runtime.BehavingEntity;

/**
 * A simple program to run an abl agent, allowing simple runtime tests to be
 * performed.
 * 
 * @author jgrey
 * 
 */
public class BasicAgentTester {
   /**
    * The name of the agent class to load and test:
    */
   String agentClassName = "UnorderedTest";

   /**
    * The name of the package the agent is in:
    */
   private String packageName = "examples";

   /**
    * The Agent
    */
   private BehavingEntity mainAgent;

   public BasicAgentTester() {
      try {

         /*
     The Agent
    */
         /*
     The name of the package the agent is in:
    */
         String packageName = "examples";
         BehavingEntity mainAgent = (BehavingEntity) Class.forName(packageName + "." + agentClassName).newInstance();
         mainAgent.startBehaving();

      } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
         throw new RuntimeException(e);
      }

   }

   /**
    * Main class to run the test
    * 
    * @param args
    */
   public static void main(String args[]) {
      @SuppressWarnings("unused")
      BasicAgentTester t = new BasicAgentTester();
   }
}
