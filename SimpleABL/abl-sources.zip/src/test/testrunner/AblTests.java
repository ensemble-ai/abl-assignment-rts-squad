package test.testrunner;

import static test.testrunner.AblTestRunner.addTest;

import abl.compiler.CompileException;
import abl.compiler.ParseException;

/**
 * Sets up the tests that AblTestRunner will run. Use this class every time you
 * write a new .abl file.
 */
public class AblTests {

   // Some static throwable instances which can be reused below.
   static CompileException ce = new CompileException();
   static ParseException pe = new ParseException();

   public static void main(String[] args) {
      // Add new tests here.
      addTest("EmptyFile.abl", 0);
      addTest("ExceptionInMentalAct.abl", 0, ce);
      addTest("JustInitialTree.abl", 0, ce);
      addTest("MentalActError_ExtraneousParen.abl", 0, pe);
      addTest("MentalActError_MissingArgument.abl", 0, pe);
      addTest("MentalActError_NoClosingBraceInIf.abl", 0, pe);
      addTest("MentalActWithAssert.abl", 0);
      addTest("MentalActWithNakedBlockThrow.abl", 0, ce);
      addTest("NonexistentSubgoal.abl", 1);
      addTest("DoublesAndFloats.abl", 0);
      addTest("LiteralNullArgument.abl", 0);
      addTest("CallOfSubclass.abl", 0);
      addTest("MultiplyDefinedGlobalScope.abl", 0, ce);
      addTest("ReferenceToGlobalInGlobalScope.abl", 1);
      addTest("ForwardReferenceToGlobal.abl", 0, ce);
      addTest("PreconditionDeclares.abl", 0);
      addTest("ContextConditionDeclares.abl", 0);
      addTest("ContextPreConditionsTogether.abl", 0);
      addTest("MAMixedDeclsAndCode.abl", 0);
      addTest("AnonymousClassInMentalAct.abl", 0);
      addTest("BindToVarTest.abl", 0);

      AblTestRunner.runTests();
   }

}
