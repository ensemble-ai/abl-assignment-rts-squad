/** An interface defining constants. Used to test the constants declaration in ABL. */

package test;

public interface ABLConstants {
   public final int constantInt = 1;
   public final float constantFloat = 1.0f;
   public final double constantDouble = 1.0d;
   public final char constantChar = 'x';
   public final boolean constanBool = true;
   public final String constantString = "foo";
   public final long constantLong = 1;
   public final short constantShort = 1;
   public final byte constantByte = 1;
}