package debug;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import abl.runtime.ABTNode;
import abl.runtime.BehavingEntity;
import abl.runtime.BehavingListener;
import abl.runtime.Behavior;
import abl.runtime.Step;
import abl.runtime.__BehaviorDesc;
import abl.runtime.BehavingEntity.BehaviorLibrary;

/**
 * Viewer for the ABL Behavior Tree (ABT). Displays the executing and leafs
 * nodes in the ABT.
 * 
 * Note: this viewer is meant for demos
 * 
 * To use: BehavingEntity entity = new YourBehavingEntity();
 * enetity.addBehavingListener(new ABTViewer()); entity.startBehaving();
 * 
 * @author Ben Weber, 1-6-10
 * @author April Grow 10-21-2014 edits and comments
 */
public class ABTViewer
      extends JPanel
      implements BehavingListener, MouseWheelListener, MouseMotionListener, MouseListener, ItemListener {

   /** mapping of ABT nodes to the local Node representation */
   private final Map<ABTNode, ABLNode> nodeMap = new HashMap<>();

   public enum NodeType {
      Root, SubGoal, SpawnGoal, Parallel, Sequential, MentalAct, PrimitiveAct, Conditional, Unknown
   }
   /* One for each node type you want to hide */
   JCheckBox subgoalCB;
   JCheckBox spawngoalCB;
   JCheckBox parallelsCB;
   JCheckBox sequentialsCB;
   JCheckBox mentalsCB;
   JCheckBox primitivesCB;
   JCheckBox conditionalCB;
   JCheckBox unknownsCB;

   private boolean running = true;

   private JFrame frame;
   private JPanel controls;//JPanel controls;
   private JScrollPane scrollWrap;

   private double scale = 1.0;
   private double tx;
   private double ty;
   public int mx;
   public int my;
   private boolean mouseDown;

   Font font = new Font("ariel", Font.BOLD, 12);
   int h = 25;
   int stackHeight = 35;

   private long last;

   double scaleAmmount = 0.9;

   public ABTViewer() {

      frame = new JFrame("ABL Behavior Tree");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setPreferredSize(new Dimension(600, 600));
      frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
      
      frame.add(this);
      
      controls = new JPanel();//new JScrollPane();//
      scrollWrap = new JScrollPane(controls);
      subgoalCB = new JCheckBox("Hide Subgoals");
      spawngoalCB = new JCheckBox("Hide Spawngoals");
      parallelsCB = new JCheckBox("Hide Parallels");
      sequentialsCB = new JCheckBox("Hide Sequentials");
      mentalsCB = new JCheckBox("Hide Mental Acts");
      primitivesCB = new JCheckBox("Hide Primitive Acts");
      conditionalCB = new JCheckBox("Hide Conditionals");
      unknownsCB = new JCheckBox("Hide Unknowns");
      
      subgoalCB.addItemListener(this);
      spawngoalCB.addItemListener(this);
      parallelsCB.addItemListener(this);
      sequentialsCB.addItemListener(this);
      mentalsCB.addItemListener(this);
      primitivesCB.addItemListener(this);
      conditionalCB.addItemListener(this);
      unknownsCB.addItemListener(this);
      
      //controls.setMaximumSize(new Dimension(600, 20));
      scrollWrap.setMaximumSize(new Dimension(99999, 100));
      scrollWrap.setMinimumSize(new Dimension(0, 100));
      scrollWrap.setPreferredSize(new Dimension(600, 50));
      //controls.setPreferredSize(new Dimension(600, 40));
      controls.add(subgoalCB);
      controls.add(spawngoalCB);
      controls.add(parallelsCB);
      controls.add(sequentialsCB);
      controls.add(mentalsCB);
      controls.add(primitivesCB);
      controls.add(conditionalCB);
      controls.add(unknownsCB);
      //frame.add(controls);
      frame.add(scrollWrap);
      
      this.addMouseWheelListener(this);
      this.addMouseMotionListener(this);
      this.addMouseListener(this);
      frame.setLocation(640, 0);
      frame.setVisible(true);
      frame.pack();

      // start the drawing thread
      new Thread() {
         @Override
         public void run() {
            while (running) {
               try {
                  Thread.sleep(50);
               } catch (Exception e) {
               }

               repaint();
            }
         }
      }.start();
   }

   /**
    * Shuts down the GUI.
    */
   public void stop() {
      running = false;
      frame.setVisible(false);
   }


   @Override
   public void paint(Graphics g) {
      Graphics2D g2 = (Graphics2D) g;
      g2.setBackground(Color.WHITE);
      g2.clearRect(0, 0, getWidth(), getHeight());
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
      g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

      g2.translate(tx, ty);
      g2.scale(scale, scale);

      // draw working memory
      int y = 0;

      List<ABLNode> roots = new ArrayList<>();
      synchronized (nodeMap) {
         for (ABLNode node : nodeMap.values()) {
            if (node.parent == null) {
               roots.add(node);
            }
         }
      }

      y = 0;
      int depth = 0;
      for (ABLNode node : roots) {
         y = drawNode(g2, node, y, depth);
      }
      frame.validate();
   }

   public int drawNode(Graphics2D g2, ABLNode node, int y, int depth) {
      if(!node.hiding){
         // Draw the node if we are not hiding it and don't increment the height marker
         drawNode(g2, node, y, depth, h);
         y++;
      }

      if (!node.collapsed) {
         for (ABLNode child : node.children) {
            y = drawNode(g2, child, y, depth + 1);
         }
      }

      return y;
   }

   private void drawNode(Graphics2D g2, ABLNode node, int y, int depth, int height) {

      // draw the collapse icon
      g2.setColor(Color.GRAY.darker());
      // g2.setColor(new Color(230, 230, 230));
      g2.fillRect(50 * depth - 20, stackHeight * y + height / 2 + 1, 10, 2);
      if (node.collapsed) {
         g2.fillRect(50 * depth - 16, stackHeight * y + 9, 2, 10);
      }

      int tw = 20 + 15 * node.name.length() / 2;
      g2.setColor(new Color(230, 230, 230));

      if (node.type == NodeType.Root) {
         g2.setColor(Color.ORANGE.brighter().brighter()); // Super bright yellow
      } else if (node.type == NodeType.Parallel) {
         g2.setColor(new Color(200, 255, 200)); // A light green
      } else if (node.type == NodeType.Sequential) {
         g2.setColor(new Color(255, 255, 200)); // A light yellow
      } else if (node.type == NodeType.MentalAct) {
         g2.setColor(new Color(255, 255, 255)); // White
      } else if (node.type == NodeType.PrimitiveAct) {
         g2.setColor(new Color(150, 255, 255)); // A light teal
      } else if (node.type == NodeType.SpawnGoal) {
         g2.setColor(new Color(255, 190, 240)); // A light pink
      } else if (node.type == NodeType.Conditional) {
         g2.setColor(new Color(255, 220, 160)); // A light orange
      }

      RoundRectangle2D rect = new RoundRectangle2D.Double(50 * depth, stackHeight * y, tw, height, 20, 20);
      g2.fill(rect);

      if (node.executing > 0) {
         g2.setColor(new Color(0, 0.9f, 0, 0.001f * node.executing));
         g2.fill(rect);
      }

      if (node.leaf > 0) {
         g2.setColor(new Color(0.5f, 0.5f, 1f, 0.001f * node.leaf));
         g2.fill(rect);
      }

      g2.setStroke(new BasicStroke(3.0f));
      g2.setColor(Color.GRAY.darker());
      g2.draw(rect);

      g2.setColor(Color.black);
      g2.setFont(font);
      g2.drawString(node.name, 50 * depth + 10, stackHeight * y + 18);
   }

   @Override
   public void onBehave(Map<String, Set<Step>> executingSteps, Set<Step> leafSteps) {
      updateTree(executingSteps, leafSteps);
   }
   
   @Override
   public void onLoad(BehaviorLibrary individualBehaviorLibrary, BehaviorLibrary jointBehaviorLibrary) {
      
   }

   private void updateTree(Map<String, Set<Step>> executingSteps, Set<Step> leafSteps) {
      synchronized (nodeMap) {

         // clear the node status's
         int decay = 0;
         if (last > 0) {
            decay = 5 * (int) (System.currentTimeMillis() - last);
         }
         last = System.currentTimeMillis();

         for (ABLNode node : nodeMap.values()) {
            node.leaf = Math.max(0, node.leaf - decay);
            node.executing = Math.max(0, node.executing - decay);
         }

         // add leaf steps
         for (Object obj : leafSteps) {
            Step step = (Step) obj;

            ABLNode node = nodeMap.get(step);
            if (node != null) {
               node.leaf = 1000;
            } else {
               node = new ABLNode(step.toString());
               node.leaf = 1000;
               nodeMap.put(step, node);
               addNode(node, step);
            }
         }

         // add executing steps
         for (Object key : executingSteps.keySet()) {
            Set<Step> steps = executingSteps.get(key);

            for (Object object : steps) {
               Step step = (Step) object;

               ABLNode node = nodeMap.get(step);
               if (node != null) {
                  node.executing = 1000;
               } else {
                  node = new ABLNode(step.toString());
                  node.executing = 1000;
                  nodeMap.put(step, node);
                  addNode(node, step);
               }
            }
         }

      }
   }

   @SuppressWarnings("unused")
   private void printTree() {
      List<ABLNode> rootNodes = new ArrayList<>();
      for (ABLNode node : nodeMap.values()) {
         if (node.parent == null) {
            rootNodes.add(node);
         }
      }

      for (ABLNode node : rootNodes) {
         print(node, " ");
      }
   }

   private void print(ABLNode node, String indent) {
      System.out.println(indent + node.type + ": " + node.name);

      for (ABLNode child : node.children) {
         print(child, indent + " ");
      }
   }

   private void addNode(ABLNode node, Step step) {

      // get the parent behavior
      Behavior parent = step.getParent();
      
      if(node.type == NodeType.SpawnGoal){
         // Spawngoals spawn at the root unless given arguments to reroot
         //System.out.println("Spawngoal.... parent? " + step.getParent());
         // If it doesn't have a reroot goal, set it to the root
         parent = BehavingEntity.getBehavingEntity().getRootCollectionBehavior();
         // TO DO: if spawngoal has an at XXXX Something, go figure out what it should be
         
      }
      if (parent != null) {
         ABLNode behaviorNode = nodeMap.get(parent);

         // no parent node yet
         if (behaviorNode == null) {
            behaviorNode = new ABLNode(parent.toString());

            nodeMap.put(parent, behaviorNode);
            node.setParent(behaviorNode);

            // get the parent step
            Step parentStep = parent.getParent();
            if (parentStep != null) {

               ABLNode goalNode = nodeMap.get(parentStep);

               // create the parent step node
               if (goalNode == null) {
                  goalNode = new ABLNode(step.toString());
                  nodeMap.put(parentStep, goalNode);
                  addNode(goalNode, parentStep);

                  behaviorNode.setParent(goalNode);
               }
               // parent step node already exist
               else {
                  behaviorNode.setParent(goalNode);
               }
            }
            // no parent step
            else {
            }
         }
         // parent behavior node already exist
         else {
            node.setParent(behaviorNode);
         }
      }
      // no step parent, not sure if possible
      else {
      }
   }

   public class ABLNode
         implements Comparable<ABLNode> {
      public ABLNode parent;
      public TreeSet<ABLNode> children = new TreeSet<>();
      public int leaf;
      public int executing;
      public String description;
      public String name;
      public NodeType type;
      public boolean collapsed;
      public boolean hiding;

      public ABLNode(String name) {
         this.description = name;
         type = NodeType.Unknown;
         this.name = name;

         if (name.startsWith("collection")) {
            type = NodeType.Root;
            this.name = name.split(" ")[1];
         } else if (name.startsWith("subgoal")) {
            type = NodeType.SubGoal;
            this.name = name.split(" ")[1];
            if(subgoalCB.isSelected()) this.hiding = true;
         } else if (name.startsWith("sequential")) {
            type = NodeType.Sequential;
            this.name = name.split(" ")[1];
            if(sequentialsCB.isSelected()) this.hiding = true;
         } else if (name.startsWith("parallel")) {
            type = NodeType.Parallel;
            this.name = name.split(" ")[1];
            if(parallelsCB.isSelected()) this.hiding = true;
         } else if (name.startsWith("mental")) {
            type = NodeType.MentalAct;
            this.name = "Mental Act";
            if(mentalsCB.isSelected()) this.hiding = true;
         } else if (name.startsWith("act")) {
            type = NodeType.PrimitiveAct;
            this.name = name.split(" ")[1];
            if(primitivesCB.isSelected()) this.hiding = true;
         } else if (name.startsWith("spawngoal")) {
            type = NodeType.SpawnGoal;
            this.name = name.split(" ")[1];
            if(spawngoalCB.isSelected()) this.hiding = true;
         } else if (name.startsWith("conditional")) {
            type = NodeType.Conditional;
            this.name = name;
            if(conditionalCB.isSelected()) this.hiding = true;
         }

         if(type != NodeType.Conditional) {
            this.name = type + ":" + this.name;
         }
         
         if(type == NodeType.Unknown && unknownsCB.isSelected()) this.hiding = true;
      }

      public void setParent(ABLNode parent) {
         this.parent = parent;
         parent.children.add(this);
      }

      @Override
      public int compareTo(ABLNode o) {
         return name.compareTo(o.name);
      }
   }

   @Override
   public void mouseWheelMoved(MouseWheelEvent e) {
      try {

         if (e.getWheelRotation() > 0) {
            // scale *= scaleAmmount;

            // compute the current mouse location in virtual coordinates
            double screenX = e.getX();
            double screenY = e.getY();
            AffineTransform transform = new AffineTransform();
            transform.translate(tx, ty);
            transform.scale(scale, scale);
            double[] src = new double[] {
               screenX,
               screenY
            };
            double[] dest1 = new double[2];
            transform.inverseTransform(src, 0, dest1, 0, 1);

            // do the scalle
            scale *= scaleAmmount;

            // compute the new mouse location in virtual coordinates
            screenX = e.getX();
            screenY = e.getY();
            transform = new AffineTransform();
            transform.translate(tx, ty);
            transform.scale(scale, scale);
            src = new double[] {
               screenX,
               screenY
            };
            double[] dest2 = new double[2];
            transform.inverseTransform(src, 0, dest2, 0, 1);

            tx += (dest2[0] - dest1[0]) * scale;
            ty += (dest2[1] - dest1[1]) * scale;
         } else {
            // compute the current mouse location in virtual coordinates
            double screenX = e.getX();
            double screenY = e.getY();
            AffineTransform transform = new AffineTransform();
            transform.translate(tx, ty);
            transform.scale(scale, scale);
            double[] src = new double[] {
               screenX,
               screenY
            };
            double[] dest1 = new double[2];
            transform.inverseTransform(src, 0, dest1, 0, 1);

            // do the scalle
            scale /= scaleAmmount;

            // compute the new mouse location in virtual coordinates
            screenX = e.getX();
            screenY = e.getY();
            transform = new AffineTransform();
            transform.translate(tx, ty);
            transform.scale(scale, scale);
            src = new double[] {
               screenX,
               screenY
            };
            double[] dest2 = new double[2];
            transform.inverseTransform(src, 0, dest2, 0, 1);

            tx += (dest2[0] - dest1[0]) * scale;
            ty += (dest2[1] - dest1[1]) * scale;
         }

      } catch (Exception ex) {
         ex.printStackTrace();
      }

      repaint();
   }

   @Override
   public void mouseDragged(MouseEvent e) {

      if (mouseDown) {
         double dx = e.getX() - mx;
         double dy = e.getY() - my;

         tx += dx;
         ty += dy;

         mx = e.getX();
         my = e.getY();
      }

      repaint();
   }

   @Override
   public void mouseMoved(MouseEvent e) {
   }

   @Override
   public void mouseEntered(MouseEvent e) {

   }

   @Override
   public void mouseExited(MouseEvent e) {

   }

   @Override
   public void mousePressed(MouseEvent e) {
      if (e.getButton() == 3) {
         mouseDown = true;
         mx = e.getX();
         my = e.getY();
      } else {
         int x = e.getX();
         int y = e.getY();

         AffineTransform transform = new AffineTransform();
         transform.translate(tx, ty);
         transform.scale(scale, scale);

         Point2D source = new Point2D.Double(x, y);
         Point2D result = new Point2D.Double();

         try {
            transform.inverseTransform(source, result);
         } catch (Exception ex) {
            ex.printStackTrace();
         }
         
         int stack = (int) (result.getY() / stackHeight); // The node 'index' we clicked on down the tree
         if (stack >= 0 && stack < nodeMap.size()) {
            // Find which node was clicked on
            synchronized (nodeMap) {
               List<ABLNode> fringe = new ArrayList<>();
               for (ABLNode node : nodeMap.values()) {
                  if (node.parent == null) {
                     fringe.add(node);
                  }
               }

               int count = 0; // The number of nodes we have traversed
               while (!fringe.isEmpty()) {
                  ABLNode node = fringe.remove(0);
                  if (!node.hiding && stack == count++) {
                     // Toggles collapsed flag
                     node.collapsed = !node.collapsed;
                  } else {
                     int index = 0;
                     // Ignores children of collapsed nodes
                     // Does NOT ignore the children of hidden nodes.
                     if (!node.collapsed) {
                        for (ABLNode child : node.children) {
                           fringe.add(index++, child);
                        }
                     }
                  }
               }
            }
         }
      }

      repaint();
   }

   @Override
   public void mouseReleased(MouseEvent e) {
      if (e.getButton() == 3) {
         mouseDown = false;
      }

      repaint();
   }

   @Override
   public void mouseClicked(MouseEvent e) {
   }
   
   @Override
   public void itemStateChanged(ItemEvent e) {
      Object source = e.getItemSelectable();
      boolean hiding;
      
      // If the checkbox has been selected, HIDE the type you selected
      if(e.getStateChange() == ItemEvent.SELECTED) hiding = true;
      else hiding = false;
      
      if (source == subgoalCB) {
         synchronized (nodeMap) {
            for (ABLNode node : nodeMap.values()) {
               if (node.type == NodeType.SubGoal) {
                  node.hiding = hiding;
               }
            }
         }
      } else if (source == parallelsCB) {
         synchronized (nodeMap) {
            for (ABLNode node : nodeMap.values()) {
               if (node.type == NodeType.Parallel) {
                  node.hiding = hiding;
               }
            }
         }
      } else if (source == sequentialsCB) {
         synchronized (nodeMap) {
            for (ABLNode node : nodeMap.values()) {
               if (node.type == NodeType.Sequential) {
                  node.hiding = hiding;
               }
            }
         }
      } else if (source == mentalsCB) {
         synchronized (nodeMap) {
            for (ABLNode node : nodeMap.values()) {
               if (node.type == NodeType.MentalAct) {
                  node.hiding = hiding;
               }
            }
         }
      } else if (source == primitivesCB) {
         synchronized (nodeMap) {
            for (ABLNode node : nodeMap.values()) {
               if (node.type == NodeType.PrimitiveAct) {
                  node.hiding = hiding;
               }
            }
         }
      } else if (source == unknownsCB) {
         synchronized (nodeMap) {
            for (ABLNode node : nodeMap.values()) {
               if (node.type == NodeType.Unknown) {
                  node.hiding = hiding;
               }
            }
         }
      } else if (source == spawngoalCB) {
         synchronized (nodeMap) {
            for (ABLNode node : nodeMap.values()) {
               if (node.type == NodeType.SpawnGoal) {
                  node.hiding = hiding;
               }
            }
         }
      } else if (source == conditionalCB) {
         synchronized (nodeMap) {
            for (ABLNode node : nodeMap.values()) {
               if (node.type == NodeType.Conditional) {
                  node.hiding = hiding;
               }
            }
         }
      }
      
      repaint();
   }
}
