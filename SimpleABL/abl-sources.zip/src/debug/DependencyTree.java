package debug;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.RoundRectangle2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

import abl.runtime.ABTNode;
import abl.runtime.BehavingEntity.BehaviorLibrary;
import abl.runtime.BehavingListener;
import abl.runtime.Behavior;
import abl.runtime.Step;
import abl.runtime.__BehaviorDesc;
import abl.runtime.BehavingEntity;

/**
 * Viewer for the Behavior Dependency Tree in ABL
 * where edges indicate subgoal or spawngoal activity
 * 
 * To use: BehavingEntity entity = new YourBehavingEntity();
 * entity.addBehavingListener(new ABTViewer()); entity.startBehaving();
 * 
 * @author April Grow 10-28-14
 */

public class DependencyTree
      extends JPanel
      implements BehavingListener, MouseWheelListener, MouseMotionListener, MouseListener {
   
   /** mapping of ABT nodes to the local Node representation */
   private final Map<ABTNode, ABLNode> nodeMap = new HashMap<>();
   
   
   // <BehaviorID, __BehaviorDesc>
   // Behavior library uses <Signature, __BehaviorDesc>, which is not useful since inheretance
   // Behavior library ALSO has <ID, subgoaledSignatures>, which has been a long time in making
   private final Map<Integer, __BehaviorDesc> indBehaviorIDMap = new HashMap<>();
   private final Map<Integer, __BehaviorDesc> jointBehaviorIDMap = new HashMap<>();
  
   // Loaded in from the behaving entity initializing this function
   private BehaviorLibrary individualBehaviorLibrary;
   private BehaviorLibrary jointBehaviorLibrary;
   
   // Edges in a graph to draw. Turns possible cyclic ABL Dependency Tree into an Acyclic graph that can be safely looped/drawn
   private Map<Integer, List<Integer>> indBehaviorNeighbors = new HashMap<>();
   
   public enum NodeType {
      Root, SubGoal, SpawnGoal, Parallel, Sequential, MentalAct, PrimitiveAct, Conditional, Unknown
   }
   
   private boolean running = true;
   private JFrame frame;
   
   private double scale = 1.0;
   private double tx;
   private double ty;
   public int mx;
   public int my;
   private boolean mouseDown;
   private boolean loaded = false;

   Font font = new Font("ariel", Font.BOLD, 12);
   int h = 25;
   int stackHeight = 35;

   double scaleAmmount = 0.9;

   public DependencyTree() {
      frame = new JFrame("ABL Depdendecy Tree");
      //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setPreferredSize(new Dimension(400, 110));
      frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
      
      frame.add(this);
      
      this.addMouseWheelListener(this);
      this.addMouseMotionListener(this);
      this.addMouseListener(this);
      frame.setLocation(660, 0);
      frame.setVisible(true);
      frame.pack();

      // start the drawing thread
      new Thread() {
         @Override
         public void run() {
            while (running) {
               try {
                  Thread.sleep(50);
               } catch (Exception e) {
               }

               repaint();
            }
         }
      }.start();
   }
   
   /**
    * Shuts down the GUI.
    */
   public void stop() {
      //running = false;
      frame.setVisible(false);
   }
   
   @Override
   public void paint(Graphics g) {
      Graphics2D g2 = (Graphics2D) g;
      g2.setBackground(Color.WHITE);
      g2.clearRect(0, 0, getWidth(), getHeight());
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
      g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

      g2.translate(tx, ty);
      g2.scale(scale, scale);

      // draw working memory
      int y = 0;

      List<ABLNode> roots = new ArrayList<>();
      synchronized (nodeMap) {
         for (ABLNode node : nodeMap.values()) {
            if (node.parent == null) {
               roots.add(node);
            }
         }
      }

      y = 0;
      int depth = 0;
      for (ABLNode node : roots) {
         y = drawNode(g2, node, y, depth);
      }
      
      g2.setColor(Color.black);
      g2.setFont(font);
      g2.drawString("Files generated!     See \\generated\\graphVis.html", 50, 50);
      
      frame.validate();
   }
   
   public int drawNode(Graphics2D g2, ABLNode node, int y, int depth) {
      if(!node.hiding){
         // Draw the node if we are not hiding it and don't increment the height marker
         drawNode(g2, node, y, depth, h);
         y++;
      }

      if (!node.collapsed) {
         for (ABLNode child : node.children) {
            y = drawNode(g2, child, y, depth + 1);
         }
      }

      return y;
   }
   
   /* TO DO: Fix the depth measurements to look like/be structured like a tree **/
   private void drawNode(Graphics2D g2, ABLNode node, int y, int depth, int height) {

      // draw the collapse icon
      g2.setColor(Color.GRAY.darker());
      // g2.setColor(new Color(230, 230, 230));
      g2.fillRect(50 * depth - 20, stackHeight * y + height / 2 + 1, 10, 2);
      if (node.collapsed) {
         g2.fillRect(50 * depth - 16, stackHeight * y + 9, 2, 10);
      }

      int tw = 20 + 15 * node.name.length() / 2;
      g2.setColor(new Color(230, 230, 230));

      if (node.type == NodeType.Root) {
         g2.setColor(Color.ORANGE.brighter().brighter()); // Super bright yellow
      } else if (node.type == NodeType.Parallel) {
         g2.setColor(new Color(200, 255, 200)); // A light green
      } else if (node.type == NodeType.Sequential) {
         g2.setColor(new Color(255, 255, 200)); // A light yellow
      } else if (node.type == NodeType.MentalAct) {
         g2.setColor(new Color(255, 255, 255)); // White
      } else if (node.type == NodeType.PrimitiveAct) {
         g2.setColor(new Color(150, 255, 255)); // A light teal
      } else if (node.type == NodeType.SpawnGoal) {
         g2.setColor(new Color(255, 190, 240)); // A light pink
      } else if (node.type == NodeType.Conditional) {
         g2.setColor(new Color(255, 220, 160)); // A light orange
      }

      RoundRectangle2D rect = new RoundRectangle2D.Double(50 * depth, stackHeight * y, tw, height, 20, 20);
      g2.fill(rect);

      if (node.executing > 0) {
         g2.setColor(new Color(0, 1.0f, 0, 0.001f * node.executing));
         g2.fill(rect);
      }

      if (node.leaf > 0) {
         g2.setColor(new Color(0, 0, 1.0f, 0.001f * node.leaf));
         g2.fill(rect);
      }

      g2.setStroke(new BasicStroke(3.0f));
      g2.setColor(Color.GRAY.darker());
      g2.draw(rect);

      g2.setColor(Color.black);
      g2.setFont(font);
      g2.drawString(node.name, 50 * depth + 10, stackHeight * y + 18);
   }
   
   @Override
   public void onBehave(Map<String, Set<Step>> executingSteps, Set<Step> leafSteps) {
      updateTree(executingSteps, leafSteps);
   }
   
   @Override
   //public void onLoad(Map<String, List<__BehaviorDesc>> behaviors) {
   public void onLoad(BehaviorLibrary individualBehaviorLibrary, BehaviorLibrary jointBehaviorLibrary){
      if(!loaded){
         loaded = true;
         this.individualBehaviorLibrary = individualBehaviorLibrary;
         this.jointBehaviorLibrary = jointBehaviorLibrary;
         
         Iterator it = individualBehaviorLibrary.getBehaviorMap().entrySet().iterator();
         while (it.hasNext()) {
             Map.Entry pairs = (Map.Entry)it.next();
             List<__BehaviorDesc> desc = (List<__BehaviorDesc>) pairs.getValue();
             for(__BehaviorDesc d : desc){
                indBehaviorIDMap.put(d.behaviorID, d);
             }
             //System.out.println(pairs.getKey() + " = " + desc);
         }
         //System.out.println(indBehaviorIDMap);
         
         makeMapFiles();
      }
   }
   
   private void makeMapFiles(){
      try {
         String workingDir = System.getProperty("user.dir") + File.separator + "generated";
         //String workingDir = "";

         System.out.println("Working Directory for generated files: " + workingDir);
         File dir = new File(workingDir);
         File goalfile = new File(dir, "goalStepMap.txt"); // Add in dir, if you set workingDir
         File sigfile = new File(dir, "signatureMap.txt"); // Add in dir, if you set workingDir
         
         //goalfile.getParentFile().mkdirs();
         // if file doesn't exists, then create it
         if (!goalfile.exists()) {
            System.out.println("making goalfile");
            goalfile.getParentFile().mkdirs(); // Use if making dirs
            goalfile.createNewFile();
         }
         if (!sigfile.exists()) {
            System.out.println("making sigfile");
            sigfile.createNewFile();
         }
         
         System.out.println("sending to file thing: " + goalfile.getAbsoluteFile());
         
         FileWriter gfw = new FileWriter(goalfile.getAbsoluteFile());
         BufferedWriter gbw = new BufferedWriter(gfw);
         FileWriter sfw = new FileWriter(sigfile.getAbsoluteFile());
         BufferedWriter sbw = new BufferedWriter(sfw);
         
         // Write the lines, formated as "id|target|target..." for each line
         Iterator it = individualBehaviorLibrary.getGoalStepMap().entrySet().iterator();
         String gfcontent = "";
         String sfcontent = "";
         
         while (it.hasNext()) {
             Map.Entry pairs = (Map.Entry)it.next();
             // Make a line that includes the id
             gfcontent = String.valueOf(pairs.getKey());
             sfcontent = String.valueOf(pairs.getKey());
             List<String> sigs = (List<String>) pairs.getValue();
             for(String s : sigs){
                // Adds in every connecting target's sig (since we don't know the id for sure
                gfcontent += "|" + s;
             }
             gbw.write(gfcontent + "\n");
             //System.out.println("Writing line " + gfcontent + " to goalStepMap.txt file.");
             
             for(String s2 : indBehaviorIDMap.get(pairs.getKey()).signatures){
                sfcontent += "|" + s2;
             }
             
             sbw.write(sfcontent + "\n");
             //System.out.println("Writing line " + sfcontent + " to signatureMap.txt file.");
         }
         
         gbw.close();
         
         sbw.close();
            

         System.out.println("Finished!");
    
    
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
   /*
   private List<Integer> explorePath(int behaviorID, List<Integer> visitedThisPath, int depth){
      String signature = (indBehaviorIDMap.get(behaviorID)).signature;
      
      // If we have seen this behavior in this search, GET OUT! No Cycles!
      if(!visitedThisPath.contains(signature)) {
         // We have not seen this behavior before, so add all its targets
         List<String> possibleTargets = individualBehaviorLibrary.getGoalStepMap().get(behaviorID);
         List<String> actualTargets = new ArrayList<String>();
         for(String target : possibleTargets){
            if(!visitedThisPath.contains(signature));
         }
         indBehaviorMapToDraw.put(signature, actualTargets);
      }
      
      return visitedThisPath;
      
   }*/
   
   private void updateTree(Map<String, Set<Step>> executingSteps, Set<Step> leafSteps) {
      synchronized (nodeMap) {
         /* No 'updating' should be necessary because it gets all loaded in the beginning
         // clear the node status's
         int decay = 0;
         if (last > 0) {
            decay = 5 * (int) (System.currentTimeMillis() - last);
         }
         last = System.currentTimeMillis();

         for (ABLNode node : nodeMap.values()) {
            node.leaf = Math.max(0, node.leaf - decay);
            node.executing = Math.max(0, node.executing - decay);
         }

         // add leaf steps
         for (Object obj : leafSteps) {
            Step step = (Step) obj;

            ABLNode node = nodeMap.get(step);
            if (node != null) {
               node.leaf = 1000;
            } else {
               node = new ABLNode(step.toString());
               node.leaf = 1000;
               nodeMap.put(step, node);
               addNode(node, step);
            }
         }

         // add executing steps
         for (Object key : executingSteps.keySet()) {
            Set<Step> steps = executingSteps.get(key);

            for (Object object : steps) {
               Step step = (Step) object;

               ABLNode node = nodeMap.get(step);
               if (node != null) {
                  node.executing = 1000;
               } else {
                  node = new ABLNode(step.toString());
                  node.executing = 1000;
                  nodeMap.put(step, node);
                  addNode(node, step);
               }
            }
         }*/

      }
   }
   
   private void addNode(ABLNode node, Step step) {

      // get the parent behavior
      Behavior parent = step.getParent();
      if (parent != null) {
         ABLNode behaviorNode = nodeMap.get(parent);

         // no parent node yet
         if (behaviorNode == null) {
            behaviorNode = new ABLNode(parent.toString());

            nodeMap.put(parent, behaviorNode);
            node.setParent(behaviorNode);

            // get the parent step
            Step parentStep = parent.getParent();
            if (parentStep != null) {

               ABLNode goalNode = nodeMap.get(parentStep);

               // create the parent step node
               if (goalNode == null) {
                  goalNode = new ABLNode(step.toString());
                  nodeMap.put(parentStep, goalNode);
                  addNode(goalNode, parentStep);

                  behaviorNode.setParent(goalNode);
               }
               // parent step node already exist
               else {
                  behaviorNode.setParent(goalNode);
               }
            }
            // no parent step
            else {
            }
         }
         // parent behavior node already exist
         else {
            node.setParent(behaviorNode);
         }
      }
      // no step parent, not sure if possible
      else {
      }
   }
   
   public class ABLNode
         implements Comparable<ABLNode> {
      public ABLNode parent;
      public TreeSet<ABLNode> children = new TreeSet<>();
      public int leaf;
      public int executing;
      public String description;
      public String name;
      public NodeType type;
      public boolean collapsed;
      public boolean hiding;
      
      public ABLNode(String name) {
         this.description = name;
         type = NodeType.Unknown;
         this.name = name;
      
         if (name.startsWith("collection")) {
            type = NodeType.Root;
            this.name = name.split(" ")[1];
         } else if (name.startsWith("subgoal")) {
            type = NodeType.SubGoal;
            this.name = name.split(" ")[1];
         } else if (name.startsWith("sequential")) {
            type = NodeType.Sequential;
            this.name = name.split(" ")[1];
         } else if (name.startsWith("parallel")) {
            type = NodeType.Parallel;
            this.name = name.split(" ")[1];
         } else if (name.startsWith("mental")) {
            type = NodeType.MentalAct;
            this.name = "Mental Act";
         } else if (name.startsWith("act")) {
            type = NodeType.PrimitiveAct;
            this.name = name.split(" ")[1];
         } else if (name.startsWith("spawngoal")) {
            type = NodeType.SpawnGoal;
            this.name = name.split(" ")[1];
         } else if (name.startsWith("conditional")) {
            type = NodeType.Conditional;
            this.name = name;
         }
      
         if(type != NodeType.Conditional) this.name = type + ":" + this.name;
      }
      
      public void setParent(ABLNode parent) {
         this.parent = parent;
         parent.children.add(this);
      }
      
      @Override
      public int compareTo(ABLNode o) {
         return name.compareTo(o.name);
      }
   } /* End internal AblNode class */
   
   @Override
   public void mouseWheelMoved(MouseWheelEvent e) {
      try {

         if (e.getWheelRotation() > 0) {
            // scale *= scaleAmmount;

            // compute the current mouse location in virtual coordinates
            double screenX = e.getX();
            double screenY = e.getY();
            AffineTransform transform = new AffineTransform();
            transform.translate(tx, ty);
            transform.scale(scale, scale);
            double[] src = new double[] {
               screenX,
               screenY
            };
            double[] dest1 = new double[2];
            transform.inverseTransform(src, 0, dest1, 0, 1);

            // do the scalle
            scale *= scaleAmmount;

            // compute the new mouse location in virtual coordinates
            screenX = e.getX();
            screenY = e.getY();
            transform = new AffineTransform();
            transform.translate(tx, ty);
            transform.scale(scale, scale);
            src = new double[] {
               screenX,
               screenY
            };
            double[] dest2 = new double[2];
            transform.inverseTransform(src, 0, dest2, 0, 1);

            tx += (dest2[0] - dest1[0]) * scale;
            ty += (dest2[1] - dest1[1]) * scale;
         } else {
            // compute the current mouse location in virtual coordinates
            double screenX = e.getX();
            double screenY = e.getY();
            AffineTransform transform = new AffineTransform();
            transform.translate(tx, ty);
            transform.scale(scale, scale);
            double[] src = new double[] {
               screenX,
               screenY
            };
            double[] dest1 = new double[2];
            transform.inverseTransform(src, 0, dest1, 0, 1);

            // do the scalle
            scale /= scaleAmmount;

            // compute the new mouse location in virtual coordinates
            screenX = e.getX();
            screenY = e.getY();
            transform = new AffineTransform();
            transform.translate(tx, ty);
            transform.scale(scale, scale);
            src = new double[] {
               screenX,
               screenY
            };
            double[] dest2 = new double[2];
            transform.inverseTransform(src, 0, dest2, 0, 1);

            tx += (dest2[0] - dest1[0]) * scale;
            ty += (dest2[1] - dest1[1]) * scale;
         }

      } catch (Exception ex) {
         ex.printStackTrace();
      }

      repaint();
   }
   
   @Override
   public void mouseDragged(MouseEvent e) {

      if (mouseDown) {
         double dx = e.getX() - mx;
         double dy = e.getY() - my;

         tx += dx;
         ty += dy;

         mx = e.getX();
         my = e.getY();
      }

      repaint();
   }
   
   @Override
   public void mouseMoved(MouseEvent e) {
   }

   @Override
   public void mouseEntered(MouseEvent e) {

   }

   @Override
   public void mouseExited(MouseEvent e) {

   }
   
   @Override
   public void mousePressed(MouseEvent e) {
   }
   
   @Override
   public void mouseReleased(MouseEvent e) {

   }

   @Override
   public void mouseClicked(MouseEvent e) {
   }
}
