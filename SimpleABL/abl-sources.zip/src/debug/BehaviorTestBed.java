package debug;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import abl.runtime.BehavingEntity;
import abl.runtime.LaunchTestBedBehaviorWME;

public class BehaviorTestBed extends JFrame {

   protected JTextField textField1;
	protected JTextField textField2;
	protected JTextField textField3;
	private JComboBox behaviorDropDown;
	
	public String arg1;
	public String arg2;
	public String arg3;
	public String behaviorToLaunch;
	
	public BehavingEntity entity;
	
    public BehaviorTestBed(BehavingEntity entity) {
		setTitle("Behavior Launcher");
		setSize(300, 200);
		setLocationRelativeTo(null);
		//setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		this.entity = entity;
		
		Box vertBox = Box.createVerticalBox();
		vertBox.add(Box.createVerticalStrut(10));
		JLabel agentNameLabel = new JLabel(entity.getBehavingEntityShortName());
		vertBox.add(agentNameLabel);
		vertBox.add(Box.createVerticalStrut(10));
		behaviorDropDown = new JComboBox();
		behaviorDropDown.addActionListener(new ActionListener() { 
			   @Override
            public void actionPerformed(ActionEvent e) {
				   behaviorToLaunch = (String)((JComboBox)e.getSource()).getSelectedItem();
			   }
			 });
		vertBox.add(behaviorDropDown);
		vertBox.add(Box.createVerticalStrut(10));
		
		Box hBox = Box.createHorizontalBox();
		
		textField1 = new JTextField();
		textField1.addActionListener(new ActionListener() { 
			   @Override
            public void actionPerformed(ActionEvent e) {
				   arg1 = textField1.getText();
			   }
			 });
		hBox.add(textField1);
		
		textField2 = new JTextField();
		textField2.addActionListener(new ActionListener() { 
			   @Override
            public void actionPerformed(ActionEvent e) {
			       //System.out.println("**************** Selected " + ((JComboBox)e.getSource()).getSelectedItem());
				   arg2 = textField2.getText();
			   }
			 });
		hBox.add(textField2);
		
		textField3 = new JTextField();
		textField3.addActionListener(new ActionListener() { 
			   @Override
            public void actionPerformed(ActionEvent e) {
			       //System.out.println("**************** Selected " + ((JComboBox)e.getSource()).getSelectedItem());
				   arg3 = textField3.getText();
			   }
			 });
		hBox.add(textField3);
		vertBox.add(hBox);
		
		vertBox.add(Box.createVerticalStrut(10));
       JButton launchBtn = new JButton("Launch");
		vertBox.add(launchBtn);
		// Add the listeners to the buttons
		launchBtn.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            System.out.println(("Created LaunchTestBedBehaviorWME with: behavior=" + behaviorToLaunch + ", arg1=" + arg1 + ", arg2=" + arg2 + ", arg3=" + arg3));
            arg1 = BehaviorTestBed.this.textField1.getText();
            arg2 = BehaviorTestBed.this.textField2.getText();
            arg3 = BehaviorTestBed.this.textField3.getText();
            LaunchTestBedBehaviorWME launchBehaviorWME = new LaunchTestBedBehaviorWME(behaviorToLaunch, arg1, arg2, arg3);
            BehaviorTestBed.this.entity.addWME(launchBehaviorWME);
         }
      });
		
		vertBox.add(Box.createVerticalStrut(10));
       this.add(vertBox);
       
       
       
       //activeagentswme
       //populate a drop down with the names there
       //
       //spawnBehavior(name,arg1,arg2,arg3) overloaded one first each name

		// pack();
       setVisible(true);
    }
    
    
    public void addToBehaviorDropDownBox(String behavior) {
			behaviorDropDown.addItem(behavior);
    }
}
