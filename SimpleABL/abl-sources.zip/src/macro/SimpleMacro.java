package macro;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StreamTokenizer;
import java.io.StringReader;
import java.io.StringWriter;

public class SimpleMacro {
   public final int maxArguments = 20;
   private final static char macroAppendChar = '@';
   private boolean macroDefined;
   private String[] arguments = new String[maxArguments];
   private int numberOfArguments;
   private String macroName;
   private String macroBody;

   private final static boolean slashSlashComments = true;
   private final static boolean slashStarComments = true;

   private final static char singleLineCommentChar = '#';

   public SimpleMacro(String macroDefnString) {
      
      @SuppressWarnings("resource")
      /* Suppress for now, Eclipse seems to be confused even when it is a try-with-resources */
      Reader stringToRead = new StringReader(macroDefnString);
      try  {
         StreamTokenizer macroDefnTokens = new StreamTokenizer(stringToRead);
         macroDefnTokens.slashSlashComments(slashSlashComments);
         macroDefnTokens.slashStarComments(slashStarComments);
         macroDefnTokens.eolIsSignificant(true);
         macroDefnTokens.nextToken();
         if (!macroDefnTokens.sval.equals("definemacro")) {
            throw new SimpleMacroError("Macro " + macroDefnString + " doesn't start with 'definemacro'");
         }

         macroDefnTokens.nextToken();
         macroName = macroDefnTokens.sval;

         macroDefnTokens.nextToken();
         if (macroDefnTokens.ttype != '(') {
            throw new SimpleMacroError("Error finding beginning of argument list in " + macroDefnString);
         }

         int previousTokenType = '(';
         for (macroDefnTokens.nextToken(); macroDefnTokens.ttype != ')'; macroDefnTokens.nextToken()) {

            if (macroDefnTokens.ttype != ',' && macroDefnTokens.ttype == StreamTokenizer.TT_WORD
                  && (previousTokenType == ',' || previousTokenType == '(')) {

               arguments[numberOfArguments++] = macroDefnTokens.sval;
               previousTokenType = StreamTokenizer.TT_WORD;
            } else if (macroDefnTokens.ttype == ',' && previousTokenType == StreamTokenizer.TT_WORD) {
               previousTokenType = ',';
            } else if (macroDefnTokens.ttype != ')') {
               throw new SimpleMacroError("Error parsing the argument list of macro " + macroDefnString);
            }
         }
         StringBuilder macroRead = new StringBuilder();

         for (int charRead = stringToRead.read(); charRead != -1; charRead = stringToRead.read()) {
            macroRead.append((char) charRead);
         }
         macroBody = macroRead.toString();
         macroDefined = true;
      } catch (IOException e) {
         throw new SimpleMacroError("IO error occurred while reading macro " + macroDefnString + ". Error: " + e.getMessage());
      } finally {
         try {
            stringToRead.close();
         } catch (IOException e) {
            // can't really happen with a StringReader
         }
      }
   }

   public SimpleMacro(File macroDefnFile) {
      try  (FileReader fileToRead = new FileReader(macroDefnFile)) {
         StreamTokenizer macroDefnTokens = new StreamTokenizer(fileToRead);
         macroDefnTokens.slashSlashComments(slashSlashComments);
         macroDefnTokens.slashStarComments(slashStarComments);
         macroDefnTokens.eolIsSignificant(true);
         macroDefnTokens.nextToken();
         if (!macroDefnTokens.sval.equals("definemacro")) {
            throw new SimpleMacroError("Macro definition file " + macroDefnFile.getAbsolutePath()
                  + " doesn't start with 'definemacro'");
         }

         macroDefnTokens.nextToken();
         macroName = macroDefnTokens.sval;

         macroDefnTokens.nextToken();
         if (macroDefnTokens.ttype != '(') {
            throw new SimpleMacroError("Error finding beginning of argument list in " + macroDefnFile.getAbsolutePath());
         }

         int previousTokenType = '(';
         for (macroDefnTokens.nextToken(); macroDefnTokens.ttype != ')'; macroDefnTokens.nextToken()) {

            if (macroDefnTokens.ttype != ',' && macroDefnTokens.ttype == StreamTokenizer.TT_WORD
                  && (previousTokenType == ',' || previousTokenType == '(')) {

               arguments[numberOfArguments++] = macroDefnTokens.sval;
               previousTokenType = StreamTokenizer.TT_WORD;
            } else if (macroDefnTokens.ttype == ',' && previousTokenType == StreamTokenizer.TT_WORD) {
               previousTokenType = ',';
            } else if (macroDefnTokens.ttype != ')') {
               throw new SimpleMacroError("Error parsing the argument list of macro definition file "
                     + macroDefnFile.getAbsolutePath());
            }
         }

         StringBuilder macroRead = new StringBuilder();

         /*
          * Throw away intial newline characters. Doesn't work because parsing
          * of EOL characters doesn't seem to work properly on PC platforms.
          * Seems like it is still leaving the second character of the EOL token
          * in the stream. Ignore this for now.
          */
         /*
          * macroDefnTokens.nextToken(); if (!(macroDefnTokens.ttype ==
          * StreamTokenizer.TT_EOL)) macroRead.append(macroDefnTokens.sval);
          */

         for (int charRead = fileToRead.read(); charRead != -1; charRead = fileToRead.read()) {
            macroRead.append((char) charRead);
         }
         macroBody = macroRead.toString();
         macroDefined = true;
         fileToRead.close();
      } catch (FileNotFoundException e) {
         throw new SimpleMacroError("Macro definition file " + macroDefnFile.getAbsolutePath() + " not found.");
      } catch (IOException e) {
         throw new SimpleMacroError("IO error occurred while reading macro definition file " + macroDefnFile.getAbsolutePath()
               + ". Error: " + e.getMessage());
      }
   }

   private int argLookup(String s) {
      for (int i = 0; i < arguments.length; i++) {
         if (s.equals(arguments[i])) {
            return i;
         }
      }
      return -1; // The string s is not an argument.
   }

   /* Garbled logic makes a potential-null warning unavoidable */
   @SuppressWarnings("null")
   public String expand(String[] expansionArgs)
         throws SimpleMacroException {
      if (expansionArgs == null) {
         if (numberOfArguments != 0) {
            throw new SimpleMacroException("The number of expansion arguments for macro " + macroName
                                           + " does not equal the number of macro arguments.");
         }
      } else if (expansionArgs.length != numberOfArguments) {
         throw new SimpleMacroException("The number of expansion arguments for macro " + macroName
                                        + " does not equal the number of macro arguments. " + expansionArgs.length + " != "+ numberOfArguments);
      }
      if (!macroDefined) {
         throw new SimpleMacroException("Macro not defined.");
      }

      try (StringReader macroReader = new StringReader(macroBody)) {

         final String LINE_SEP = System.getProperty("line.separator");

         StringBuilder expandedMacro = new StringBuilder();
         StreamTokenizer macroTokens = new StreamTokenizer(macroReader);
         macroTokens.slashSlashComments(slashSlashComments);
         macroTokens.slashStarComments(slashStarComments);
         macroTokens.eolIsSignificant(true);
         macroTokens.ordinaryChar(' '); // Don't skip spaces
         macroTokens.ordinaryChar('\t'); // Don't skip tabs
         macroTokens.ordinaryChar('"'); // Don't parse strings
         macroTokens.ordinaryChar('\''); // Don't parse strings
         macroTokens.ordinaryChar('.');
         macroTokens.wordChars('0', '9'); // Treat digits as word characters
                                          // (don't parse as a number).

         // First substitute the macro arguments.
         int argIndex = -1; // Initialize argIndex to no argument found.
         for (int tokenType = macroTokens.nextToken(); tokenType != StreamTokenizer.TT_EOF; tokenType = macroTokens.nextToken()) {

            if (tokenType == StreamTokenizer.TT_WORD) {
               argIndex = argLookup(macroTokens.sval);
               if (argIndex != -1) {
                  /*
                   * The excessively convoluted logic of this method has fooled
                   * Eclipse into thing expansionArgs could be null here.
                   * 
                   * FIXME: Simplify the logic, which will make Eclipse happy
                   * and human readers even happier.
                   */
                  expandedMacro.append(expansionArgs[argIndex]);
               } else {
                  expandedMacro.append(macroTokens.sval);
               }

            } else if (tokenType == StreamTokenizer.TT_EOL) {
               expandedMacro.append(LINE_SEP);
            }
            /*
             * Now see if the token begins a single line comment (begun with
             * "#"). I need to do this BS because setting slashSlashComments and
             * slashStarComments on StreamTokenizers doesn't seem to work. The
             * tokenizer always skips comments regardless of these settings.
             */
            else if (tokenType == singleLineCommentChar) {
               expandedMacro.append("// ");
            } else {
               expandedMacro.append((char) macroTokens.ttype);
            }
         }

         // Next remove the macro append operators.
         for (int i = 0; i < expandedMacro.length(); i++) {
            if (expandedMacro.charAt(i) == macroAppendChar) {
               expandedMacro.deleteCharAt(i);
            }
         }

         /* Return the expanded macro, removing the initial newline. */
         String eol = System.getProperty("line.separator");
         if (expandedMacro.substring(0, eol.length()) == eol) {
            return expandedMacro.substring(eol.length(), expandedMacro.length());
         } else {
            return expandedMacro.toString();
         }
      } catch (IOException e) {
         throw new SimpleMacroException("Error occurred while reading tokens during expand of macro " + macroName + ". Error: "
               + e.getMessage());
      } finally {
      }
   }

   // Override the default toString method from Object
   @Override
   public String toString() {
      StringWriter tempBuf = new StringWriter();
      PrintWriter tempPrint = new PrintWriter(tempBuf);

      tempPrint.println("Macro name: " + macroName);
      tempPrint.print("Arguments: ");
      for (int i = 0; i < numberOfArguments; i++) {
         tempPrint.print(arguments[i] + " ");
      }
      tempPrint.println("");
      tempPrint.println("Macro body:");
      tempPrint.print(macroBody);

      return tempBuf.toString();
   }

}
