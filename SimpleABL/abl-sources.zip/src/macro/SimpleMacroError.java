package macro;

public class SimpleMacroError
      extends Error {
   SimpleMacroError() {
      super();
   }

   SimpleMacroError(String s) {
      super(s);
   }
}
