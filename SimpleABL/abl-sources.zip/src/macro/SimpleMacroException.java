package macro;

public class SimpleMacroException
      extends Exception {
   SimpleMacroException() {
      super();
   }

   SimpleMacroException(String s) {
      super(s);
   }
}
