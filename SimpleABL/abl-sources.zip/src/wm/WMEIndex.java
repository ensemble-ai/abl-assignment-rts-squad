/**
 * Copyright 2014 UCSC
 */
package wm;

import java.io.Serializable;
import java.util.List;

import abl.runtime.FullySerializableArrayList;

/**
 * Stores a WME and a reference to its working memory of origin
 */
public class WMEIndex implements Serializable {
   private final WME wme;
   private final WorkingMemory mem;
   
   public WMEIndex(WME wme, WorkingMemory mem) {
      this.wme = wme;
      this.mem = mem;
   }
   
   /**
    * @return the wme
    */
   public WME getWME() {
      return wme;
   }
   
   /**
    * @return the mem
    */
   public WorkingMemory getMem() {
      return mem;
   }
   
   /**
    * @return true if mem contains this index's wme
    */
   public boolean memContainsWME() {
      return mem.containsThisWME(wme);
   }
   
   /**
    * Delete this wme from its memory of origin
    */
   public synchronized void deleteFromMem() {
      mem.deleteWME(wme);
   }
   
   /**
    * Create a list of WMEIndex given a list of WMEs and their memory of origin
    */
   static synchronized FullySerializableArrayList<WMEIndex> createWMEIndices(List<WME> wmes, WorkingMemory memory) {
      FullySerializableArrayList<WMEIndex> wmeIndices = new FullySerializableArrayList<>();
      for (WME wme : wmes) {
         WMEIndex wmeIndex =  new WMEIndex(wme, memory);
         wmeIndices.add(wmeIndex);
      }
      return wmeIndices;
   }

   @Override
   public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + ((mem == null) ? 0 : mem.hashCode());
      result = prime * result + ((wme == null) ? 0 : wme.hashCode());
      return result;
   }

   /* Allows only strict memory equality */
   @Override
   public boolean equals(Object obj) {
      if (this == obj) {
         return true;
      }
      if (obj == null) {
         return false;
      }
      if (getClass() != obj.getClass()) {
         return false;
      }
      WMEIndex other = (WMEIndex) obj;
      if (mem == null) {
         if (other.mem != null) {
            return false;
         }
      } else if (mem != other.mem) {
         return false;
      }
      if (wme == null) {
         if (other.wme != null) {
            return false;
         }
      } else if (wme != other.wme) {
         return false;
      }
      return true;
   }
}
