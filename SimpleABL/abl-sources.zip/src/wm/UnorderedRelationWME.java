/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2013. All rights reserved.
 *
 *******************************************************************************/
package wm;

/**
 * The Cif relation wme for unordered relations.
 */
public class UnorderedRelationWME
      extends RelationWME {

   /**
    * @param type the type of the unordered relation
    * @param set whether the relation is active
    * @param args the individuals in the relation
    */
   public UnorderedRelationWME(String type, boolean set, String... args) {
      super(type, set, args);
   }
}
