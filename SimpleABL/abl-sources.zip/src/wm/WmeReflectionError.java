package wm;

public class WmeReflectionError
      extends WorkingMemoryError {
   private static final String errorString = "Error reflecting WME class";

   public WmeReflectionError() {
      super(errorString);
   }

   public WmeReflectionError(String s) {
      super(errorString + ": " + s);
   }

   public WmeReflectionError(Throwable t) {
      super(errorString, t);
   }
}
