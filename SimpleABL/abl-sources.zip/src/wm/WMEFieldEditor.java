package wm;

public interface WMEFieldEditor {
   public String getFieldValue();

   public void setFieldValue(String s);
}
