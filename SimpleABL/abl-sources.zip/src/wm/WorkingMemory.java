// Working memory. 

package wm;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import util.CollectionMapAdder;
import abl.runtime.AblNamedPropertySupport;
import abl.runtime.AblNamedPropertySupport.UserProperty;
import abl.runtime.AblRuntimeError;
import abl.runtime.BehaviorWME;
import abl.runtime.ExecutableStepWME;
import abl.runtime.FailStepWME;
import abl.runtime.FullySerializableArrayList;
import abl.runtime.GoalStepWME;
import abl.runtime.MentalStepWME;
import abl.runtime.PrimitiveStepWME;
import abl.runtime.RuntimeError;
import abl.runtime.StepWME;
import abl.runtime.SucceedStepWME;
import abl.runtime.WaitStepWME;

public class WorkingMemory
      implements Serializable {
   private static Map<String, WorkingMemory> workingMemoryRegistry = new HashMap<>();

   @SuppressWarnings("rawtypes")
   private Map<String, WMEntry> memory = new HashMap<>();

   private transient WorkingMemoryDebugger workingMemoryDebugger;

   private String wmName;

   /**
    * What we're doing when modifying property table.
    */
   private enum PropertyTableOperation {
      Add, Remove
   }

   // The no-arg constructor doesn't register the working memory - this makes
   // the memory private
   public WorkingMemory() {
   }

   // Register the working memory for access by other threads
   public WorkingMemory(String name) {
      workingMemoryRegistry.put(name, this);
      this.wmName = name;
   }

   /*
    * Invoked on deserialization
    */
   private void readObject(ObjectInputStream in)
         throws ClassNotFoundException, IOException {
      in.defaultReadObject();
      workingMemoryRegistry.put(wmName, this);
   }

   public static WorkingMemory lookupRegisteredMemory(String name) {
      return workingMemoryRegistry.get(name);
   }

   /**
    * Common API for the kinds of elements in {@link WorkingMemory#memory}.
    */
   private interface WMEntry<T extends WME>
         extends Serializable {
      List<T> getContents();

      void addWMEntry(WMEntry<T> other);
   }

   private static final class ListEntry<T extends WME>
         extends ArrayList<T>
         implements WMEntry<T> {

      @Override
      public synchronized void addWMEntry(WMEntry<T> other) {
         /* Requires other to be of the same type */
         if (!(other instanceof ListEntry)) {
            throw new AblRuntimeError("Attempted to add a non-ListEntry to a ListEntry WMEntry");
         }
         this.addAll(other.getContents());
      }

      @Override
      public List<T> getContents() {
         return this;
      }
   }

   private static final class ReflectionWMEEntry
         implements WMEntry<WME> {
      // List of all reflection WMEs of a given type (e.g. GoalStepWME)
      private final List<WME> wmeList = new FullySerializableArrayList<>();

      // Table of lists of reflection WMEs by signature (only GoalStepWME and
      // subclasses of BehaviorWME have this)
      private final Map<String, List<WME>> signatureTable = new HashMap<>();

      // Table of lists of reflection WMEs by property
      private final Map<String, Set<WME>> propertyTable = new HashMap<>();

      private Map<String, Set<WME>> getPropertyTable() {
         return propertyTable;
      }

      public ReflectionWMEEntry() {
      }

      @Override
      public synchronized void addWMEntry(WMEntry<WME> other) {
         /* Requires other to be of the same type */
         if (!(other instanceof ReflectionWMEEntry)) {
            throw new AblRuntimeError("Attempted to add a non-ReflectionWMEEntry to a ReflectionWMEEntry WMEntry");
         }
         ReflectionWMEEntry otherReflectionEntry = (ReflectionWMEEntry) other;
         wmeList.addAll(otherReflectionEntry.wmeList);
         CollectionMapAdder<String, WME, List<WME>> listMapAdder = new CollectionMapAdder<>();
         listMapAdder.add(signatureTable, otherReflectionEntry.signatureTable);
         CollectionMapAdder<String, WME, Set<WME>> setMapAdder = new CollectionMapAdder<>();
         setMapAdder.add(propertyTable, otherReflectionEntry.propertyTable);
      }

      @Override
      public List<WME> getContents() {
         return wmeList;
      }

      // dispatcher
      /* Called once for each class in the WME's hierarchy */
      public void addReflectionWMEForClass(WME w, String wmeShortClassName) {
         switch (wmeShortClassName) {
            case "ConditionalStepWME":
            case "GoalStepWME":
               addGoalStepWME((GoalStepWME) w);
               break;
            case "WaitStepWME":
               addWaitStepWME((WaitStepWME) w);
               break;
            case "MentalStepWME":
               addMentalStepWME((MentalStepWME) w);
               break;
            case "PrimitiveStepWME":
               addPrimitiveStepWME((PrimitiveStepWME) w);
               break;
            case "FailStepWME":
               addFailStepWME((FailStepWME) w);
               break;
            case "SucceedStepWME":
               addSucceedStepWME((SucceedStepWME) w);
               break;
            case "ExecutableStepWME":
               addExecutableStepWME((ExecutableStepWME) w);
               break;
            case "StepWME":
               addStepWME((StepWME) w);
               break;
            case "CollectionBehaviorWME":
            case "ParallelBehaviorWME":
            case "SequentialBehaviorWME":
            case "MultiStepBehaviorWME":
            case "BehaviorWME":
               addBehaviorWME((BehaviorWME) w);
               break;
            default:
               throw new RuntimeError("Error: No case in addReflectionWMEForClass for " + wmeShortClassName);
         }
      }

      // dispatcher
      /* Called once for each class in the WME's hierarchy */
      public void deleteReflectionWMEForClass(WME w, String wmeShortClassName) {
         switch (wmeShortClassName) {
            case "ConditionalStepWME":
            case "GoalStepWME":
               deleteGoalStepWME((GoalStepWME) w);
               break;
            case "WaitStepWME":
               deleteWaitStepWME((WaitStepWME) w);
               break;
            case "MentalStepWME":
               deleteMentalStepWME((MentalStepWME) w);
               break;
            case "PrimitiveStepWME":
               deletePrimitiveStepWME((PrimitiveStepWME) w);
               break;
            case "FailStepWME":
               deleteFailStepWME((FailStepWME) w);
               break;
            case "SucceedStepWME":
               deleteSucceedStepWME((SucceedStepWME) w);
               break;
            case "ExecutableStepWME":
               deleteExecutableStepWME((ExecutableStepWME) w);
               break;
            case "StepWME":
               deleteStepWME((StepWME) w);
               break;
            case "CollectionBehaviorWME":
            case "ParallelBehaviorWME":
            case "SequentialBehaviorWME":
            case "MultiStepBehaviorWME":
            case "BehaviorWME":
               deleteBehaviorWME((BehaviorWME) w);
               break;
            default:
               throw new RuntimeError("Error: No case in deleteReflectionWMEForClass for " + wmeShortClassName);
         }
      }

      public void addGoalStepWME(GoalStepWME w) {
         wmeList.add(w);

         indexBySignature(w, w.getSignature());
         indexByUserProperties(w, w.getAllDefinedProperties());
      }

      public void addWaitStepWME(WaitStepWME w) {
         wmeList.add(w);
         indexByUserProperties(w, w.getAllDefinedProperties());
      }

      public void addMentalStepWME(MentalStepWME w) {
         wmeList.add(w);
         indexByUserProperties(w, w.getAllDefinedProperties());
      }

      public void addPrimitiveStepWME(PrimitiveStepWME w) {
         wmeList.add(w);
         indexByUserProperties(w, w.getAllDefinedProperties());
      }

      public void addFailStepWME(FailStepWME w) {
         wmeList.add(w);
         indexByUserProperties(w, w.getAllDefinedProperties());
      }

      public void addSucceedStepWME(SucceedStepWME w) {
         wmeList.add(w);
         indexByUserProperties(w, w.getAllDefinedProperties());
      }

      public void addExecutableStepWME(ExecutableStepWME w) {
         wmeList.add(w);
         indexByUserProperties(w, w.getAllDefinedProperties());
      }

      public void addStepWME(StepWME w) {
         wmeList.add(w);
         indexByUserProperties(w, w.getAllDefinedProperties());
      }

      public void addBehaviorWME(BehaviorWME w) {
         wmeList.add(w);
         indexBySignature(w, w.getSignature());
         indexByUserProperties(w, w.getAllDefinedProperties());
      }

      public void deleteGoalStepWME(GoalStepWME w) {
         wmeList.remove(w);
         deleteFromSignatureTable(w, w.getSignature());
         deleteFromUserPropertiesTable(w, w.getAllDefinedProperties());
      }

      public void deleteWaitStepWME(WaitStepWME w) {
         wmeList.remove(w);
         deleteFromUserPropertiesTable(w, w.getAllDefinedProperties());
      }

      public void deleteMentalStepWME(MentalStepWME w) {
         wmeList.remove(w);
         deleteFromUserPropertiesTable(w, w.getAllDefinedProperties());
      }

      public void deletePrimitiveStepWME(PrimitiveStepWME w) {
         wmeList.remove(w);
         deleteFromUserPropertiesTable(w, w.getAllDefinedProperties());
      }

      public void deleteFailStepWME(FailStepWME w) {
         wmeList.remove(w);
         deleteFromUserPropertiesTable(w, w.getAllDefinedProperties());
      }

      public void deleteSucceedStepWME(SucceedStepWME w) {
         wmeList.remove(w);
         deleteFromUserPropertiesTable(w, w.getAllDefinedProperties());
      }

      public void deleteExecutableStepWME(ExecutableStepWME w) {
         wmeList.remove(w);
         deleteFromUserPropertiesTable(w, w.getAllDefinedProperties());
      }

      public void deleteStepWME(StepWME w) {
         wmeList.remove(w);
         deleteFromUserPropertiesTable(w, w.getAllDefinedProperties());
      }

      public void deleteBehaviorWME(BehaviorWME w) {
         wmeList.remove(w);
         deleteFromSignatureTable(w, w.getSignature());
         deleteFromUserPropertiesTable(w, w.getAllDefinedProperties());
      }

      private void indexBySignature(WME w, String signature) {
         List<WME> sigList = signatureTable.get(signature);
         if (sigList == null) {
            sigList = new FullySerializableArrayList<>();
            sigList.add(w);
            signatureTable.put(signature, sigList);
         } else {
            sigList.add(w);
         }
      }

      private void indexByUserProperties(WME w, List<UserProperty> propertyList) {
         for (Object aPropertyList : propertyList) {
            AblNamedPropertySupport.UserProperty property = (AblNamedPropertySupport.UserProperty) aPropertyList;
            String propertyName = property.getName();
            Set<WME> indexedPropSet = propertyTable.get(propertyName);
            if (indexedPropSet == null) {
               indexedPropSet = new HashSet<>();
               indexedPropSet.add(w);
               propertyTable.put(propertyName, indexedPropSet);
            } else {
               indexedPropSet.add(w);
            }
         }
      }

      private void deleteFromSignatureTable(WME w, String signature) {
         List<WME> sigList = signatureTable.get(signature);

         assert sigList != null && !sigList.isEmpty() && sigList.contains(w);

         sigList.remove(w);
         if (sigList.isEmpty()) {
            signatureTable.remove(signature);
         }
      }

      private void deleteFromUserPropertiesTable(WME w, List<UserProperty> propertyList) {
         for (AblNamedPropertySupport.UserProperty property : propertyList) {
            String propertyName = property.getName();
            Set<WME> indexedPropList = propertyTable.get(propertyName);

            assert indexedPropList != null && !indexedPropList.isEmpty() && indexedPropList.contains(w);

            indexedPropList.remove(w);
         }
      }

      public List<WME> lookupWMEBySignature(String signature) {
         List<WME> list = signatureTable.get(signature);
         if (list == null) {
            list = new FullySerializableArrayList<>();
         }
         return list;
      }

      public Set<WME> lookupWMEByProperty(String propertyName) {
         Set<WME> list = propertyTable.get(propertyName);
         if (list == null) {
            list = new HashSet<>();
         }
         return list;
      }
   }

   /*
    * Given a WME, returns the short name (rather than fully qualified name) for
    * use in hashing WMEs
    */
   public static String wmeShortName(WME w) {
      return w.getClass().getSimpleName();
   }

   /*
    * Given a WME name, returns the short name (rather than fully qualified
    * name) for use in hashing WMEs
    */
   public static String wmeShortName(String wmeName) {
      if (wmeName.indexOf('.') != -1) {
         String afterLastPeriod = wmeName.substring(wmeName.lastIndexOf('.') + 1);
         int indexOfDollarSign = afterLastPeriod.lastIndexOf('$');
         if (indexOfDollarSign > -1) {
            return afterLastPeriod.substring(indexOfDollarSign + 1);
         }
         return afterLastPeriod;
      } else {
         return wmeName;
      }
   }

   /**
    * Returns a list of all the short names for the provided WME, plus all its
    * superclasses. List is guaranteed to be ordered from most specific -> most
    * abstract. Stops before WME.
    * 
    * Note: Gillian Smith, added 5-26-10
    */
   public static List<String> wmeShortNames(WME w) {
      List<String> classNameList = new FullySerializableArrayList<>();
      Class<?> currentClass = w.getClass();
      String longName = currentClass.getName();
      while (!wmeShortName(longName).equals("WME")) {
         classNameList.add(wmeShortName(longName));
         currentClass = currentClass.getSuperclass();
         longName = currentClass.getName();
      }
      return classNameList;
   }

   /**
    * Returns the number of WMEs for each WME class in memory.
    * 
    * Note: Ben Weber, added 1-6-10
    */
   public TreeMap<String, Integer> getMemoryUsage() {
      TreeMap<String, Integer> map = new TreeMap<>();

      for (String key : new ArrayList<>(memory.keySet())) {
         WMEntry<?> value = memory.get(key);

         if (value != null) {
            map.put(key, value.getContents().size());
         }
      }

      return map;
   }

   // Adds WME to working memory.
   public synchronized <T extends WME> void addWME(T w) {
      assert w != null;

      // If the WME is a TimeStampedWME and the timestamp = 0 (was not
      // manually set), set the timestamp to the current time.
      try {
         if (w instanceof TimeStampedWME && ((TimeStampedWME) w).getTimestamp() == 0) {
            ((TimeStampedWME) w).setTimestamp(System.currentTimeMillis());
         }
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }

      /*
       * Modified 5-26-10 by Gillian Smith. Instead of hashing WMEs by just
       * their short name, we now hash by their short names + the short names of
       * all their parent classes.
       */

      // String wmeClassName = wmeShortName(w);
      List<String> classNameList = wmeShortNames(w);
      for (String wmeClassName : classNameList) {
         if (!memory.containsKey(wmeClassName)) {
            /*
             * No wme with this class name has yet been added to working memory.
             * Create a new entry list and add it to working memory.
             */
            WMEntry newEntry;
            /*
             * Reflection WME classes need to go through a special addition
             * process
             */
            if (isReflectionWME(wmeClassName)) {
               ReflectionWMEEntry reflectionEntry = new ReflectionWMEEntry();
               reflectionEntry.addReflectionWMEForClass(w, wmeClassName);
               newEntry = reflectionEntry;
            } else {
               ListEntry<T> listEntry = new ListEntry<>();
               listEntry.add(w);
               newEntry = listEntry;
            }
            memory.put(wmeClassName, newEntry);
         } else {
            // This wme class has been added to working memory. Add wme to
            // the list.
            WMEntry<T> oldList = memory.get(wmeClassName);

            if (isReflectionWME(wmeClassName)) {
               ReflectionWMEEntry reflectionEntry = (ReflectionWMEEntry) oldList;
               reflectionEntry.addReflectionWMEForClass(w, wmeClassName);
            } else {
               oldList.getContents().add(w);
            }
         }
      }

      if (workingMemoryDebugger != null) {
         workingMemoryDebugger.updateIfMonitoring();
      }
   }

   /**
    * Add the contents of a workingMemory to this one
    * 
    * @param memToAdd the mem to add
    */
   @SuppressWarnings("rawtypes")
   public synchronized <T extends WME> void addWorkingMemory(WorkingMemory memToAdd) {
      for (Map.Entry<String, WMEntry> otherEntry : memToAdd.memory.entrySet()) {
         String key = otherEntry.getKey();
         WMEntry entryToAdd = otherEntry.getValue();

         /* If the key is in this memory, just add the contents */
         if (memory.containsKey(key)) {
            memory.get(key).addWMEntry(entryToAdd);
         } else {
            memory.put(key, entryToAdd);
         }
      }
   }

   // Atomically add multiple wmes to working memory.
   public synchronized <T extends WME> void addWMEs(Collection<T> wmes) {
      assert wmes != null;

      for (WME w : wmes) {
         addWME(w);
      }
   }

   // Adds WME to a registered working memory.
   public static void addWME(String memoryName, WME w) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      wm.addWME(w);
   }

   // Atomically add wmes to a registered working memory.
   public static void addWMEs(String memoryName, List<WME> wmeList) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      wm.addWMEs(wmeList);
   }

   // Modifies a WME in working memory.
   public synchronized <T extends WME> void modifyWME(WME wmeToModify, T wmeWithNewValues)
         throws IncompatibleWmeClassException, NonexistentWmeException {
      assert !isReflectionWME(wmeShortName(wmeToModify));

      if (!wmeShortName(wmeToModify).equals(wmeShortName(wmeWithNewValues))) {
         throw new IncompatibleWmeClassException();
      }

      String wmeClass = wmeShortName(wmeToModify);

      if (!memory.containsKey(wmeClass)) {
         throw new NonexistentWmeException();
      }

      WMEntry<T> wmEntry = memory.get(wmeClass);
      List<T> wmeList = wmEntry.getContents();
      if (!wmeList.contains(wmeToModify)) {
         throw new NonexistentWmeException();
      }

      wmeToModify.assign(wmeWithNewValues);

      if (workingMemoryDebugger != null) {
         workingMemoryDebugger.updateIfMonitoring();
      }
   }

   // Modifies a WME is a registered working memory.
   public static void modifyWME(String memoryName, WME wmeToModify, WME wmeWithNewValues)
         throws IncompatibleWmeClassException, NonexistentWmeException {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      wm.modifyWME(wmeToModify, wmeWithNewValues);
   }

   /*
    * Removes a WME from working memory. If the wme is not in working memory
    * does nothing (doesn't throw an error).
    */
   public synchronized <T extends WME> void deleteWME(T wmeToDelete) {
      /*
       * Modified 5-26-10 by Gillian Smith. Must delete WMEs not only from their
       * short name's list, but also from their superclasses' lists.
       */
      List<String> classNameList = wmeShortNames(wmeToDelete);
      for (String wmeClassName : classNameList) {
         if (memory.containsKey(wmeClassName)) {
            // wme class has been added to working memory; continue.
            WMEntry<T> wmEntry = memory.get(wmeClassName);
            List<T> wmeList = wmEntry.getContents();

            /*
             * Reflection WME classes need to go through a special deletion
             * process
             */
            if (isReflectionWME(wmeClassName)) {
               ReflectionWMEEntry reflectionEntry = (ReflectionWMEEntry) wmEntry;
               reflectionEntry.deleteReflectionWMEForClass(wmeToDelete, wmeClassName);
            } else {
               // Remove the non-reflection WME directly from the list
               wmeList.remove(wmeToDelete);
            }

            // If there are no WME's of this class left in working memory,
            // remove the key.
            if (wmeList.isEmpty()) {
               memory.remove(wmeClassName);
            }
         }
      }

      if (workingMemoryDebugger != null) {
         workingMemoryDebugger.updateIfMonitoring();
      }
   }

   // Deletes a WME from a a registered working memory.
   public static void deleteWME(String memoryName, WME wmeToDelete) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      wm.deleteWME(wmeToDelete);
   }

   /*
    * Deletes all WMEs with a given class name from working memory. If the WME
    * class is not found in working memory, does nothing.
    */
   public synchronized void deleteAllWMEClass(String wmeClassName) {
      if (isReflectionWME(wmeClassName)) {
         deleteAllReflectionWMEClass(wmeClassName);
      } else {
         /*
          * Modified 6-8-10 by Gillian Smith. Must delete all WMEs from this
          * class not only from their short name's list, but also from their
          * superclasses' lists.
          * 
          * Do this by iterating over all the WMEs in this class. Remove them
          * from the list, but also remove them from all their other lists.
          * Optimized so that it finds all the other lists that *aren't* a
          * superclass and removes the entire list at the end instead.
          */
         if (memory.containsKey(wmeClassName)) {
            WMEntry<WME> wmEntry = memory.get(wmeClassName);
            List<WME> wmeList = wmEntry.getContents();

            Iterator<WME> wmeListIter = wmeList.iterator();
            Set<String> listsToClear = new HashSet<>();
            while (wmeListIter.hasNext()) {
               WME currWME = wmeListIter.next();
               List<String> classNames = wmeShortNames(currWME);
               boolean isSuperclass = false;
               for (String className : classNames) {
                  if (!isSuperclass && className.equals(wmeClassName)) {
                     isSuperclass = true;
                  }

                  if (!isSuperclass) {
                     listsToClear.add(className);
                  } else {
                     if (!className.equals(wmeClassName) && memory.containsKey(className)) {
                        (memory.get(className)).getContents().remove(currWME);
                     }
                  }
               }
               wmeListIter.remove();
            }
            for (String clearList : listsToClear) {
               if (memory.containsKey(clearList)) {
                  (memory.get(clearList)).getContents().clear();
               }
            }
         }
      }
      if (workingMemoryDebugger != null) {
         workingMemoryDebugger.updateIfMonitoring();
      }
   }

   // Deletetes all WMEs with a given class name from a registered working
   // memory.
   public static void deleteAllWMEClass(String memoryName, String wmeClassName) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      wm.deleteAllWMEClass(wmeClassName);
   }

   protected synchronized void deleteAllReflectionWMEClass(String wmeClassName) {
      assert memory.get(wmeClassName) != null;
      memory.remove(wmeClassName);
   }

   /**
    * Remove all WMEs in this WorkingMemory
    */
   public synchronized void clear() {
      memory.clear();
      if (workingMemoryDebugger != null) {
         workingMemoryDebugger.updateIfMonitoring();
      }
   }

   /**
    * @param <T> WME type
    * @param wmeClass Any WME class
    * 
    * @return a correctly genericized list of working memory WMEs of the given
    *         type.
    */
   public synchronized <T extends WME> List<T> lookupWME(Class<T> wmeClass) {

      WMEntry<T> wmEntry = memory.get(wmeClass.getSimpleName());
      if (wmEntry == null) {
         /*
          * No wmes with requested class name in working memory. Return an empty
          * list.
          */
         return Collections.emptyList();
      }
      List<T> wmeList = wmEntry.getContents();
      if (wmeList == null) {
         /*
          * No wmes with requested class name in working memory. Return an empty
          * list.
          */
         return Collections.emptyList();
      } else {
         /* Return a copy of the list in working memory */
         return new FullySerializableArrayList<>(wmeList);
      }
   }

   /**
    * 
    * @param wmeClassName The name of a WME class.
    * 
    * @return a list of WMEs in working memory with that class name.
    */
   public synchronized <T extends WME> List<T> lookupWME(String wmeClassName) {
      WMEntry<T> wmEntry = memory.get(wmeClassName);
      if (wmEntry == null) {
         /*
          * No wmes with requested class name in working memory. Return an empty
          * list.
          */
         return Collections.emptyList();
      }
      List<T> wmeList = wmEntry.getContents();
      if (wmeList == null) {
         /*
          * No wmes with requested class name in working memory. Return an empty
          * list.
          */
         return Collections.emptyList();
      } else {
         /* Return a copy of the list in working memory */
         return new FullySerializableArrayList<>(wmeList);
      }
   }

   /**
    * @return the set WME class name keys present in this memory
    */
   public synchronized Set<String> getWmeClassNameKeys() {
      return memory.keySet();
   }

   // Looks up a WME class in a registered working memory
   public static List<WME> lookupWME(String memoryName, String wmeClassName) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      return wm.lookupWME(wmeClassName);
   }

   /**
    * @return a List of WMEIndex in a registered working memory
    */
   public static List<WMEIndex> lookupWMEIndices(String memoryName, String wmeClassName) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      List<WME> wmes = wm.lookupWME(wmeClassName);
      return WMEIndex.createWMEIndices(wmes, wm);
   }

   // ###############################################
   // Optimization methods for Reflection wmes

   // Look up a reflection WME using the signature to optimize
   public synchronized List<WME> lookupReflectionWMEBySignature(String wmeClassName, String signature) {
      assert WorkingMemory.isReflectionWME(wmeClassName);

      ReflectionWMEEntry entry = (ReflectionWMEEntry) memory.get(wmeClassName);
      if (entry == null) {
         return new FullySerializableArrayList<>();
      } else {
         return new FullySerializableArrayList<>(entry.lookupWMEBySignature(signature));
      }
   }

   /**
    * Get all the ReflectionWMEEntry lists this WME belongs to
    */
   private List<ReflectionWMEEntry> lookupAllReflectionWmeEntries(WME wme) {
      List<ReflectionWMEEntry> entriesForWME = new ArrayList<>();
      List<String> classNameList = wmeShortNames(wme);

      for (String wmeClassName : classNameList) {
         if (isReflectionWME(wmeClassName) && memory.containsKey(wmeClassName)) {
            ReflectionWMEEntry entry = (ReflectionWMEEntry) memory.get(wmeClassName);
            entriesForWME.add(entry);
         }
      }
      return entriesForWME;
   }

   public static List<WME> lookupReflectionWMEBySignature(String memoryName, String wmeClassName, String signature) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      return wm.lookupReflectionWMEBySignature(wmeClassName, signature);
   }

   /**
    * @return a list of WMEindex from this memory, matching the signature
    */
   public static List<WMEIndex> lookupReflectionWMEIndicesBySignature(String memoryName, String wmeClassName, String signature) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      List<WME> reflectionWMEs = wm.lookupReflectionWMEBySignature(wmeClassName, signature);
      return WMEIndex.createWMEIndices(reflectionWMEs, wm);
   }

   // Look up a reflection wme using a user property to optimize
   public synchronized List<WME> lookupReflectionWMEByUserProperty(String wmeClassName, String userPropertyName) {
      assert isReflectionWME(wmeClassName);

      ReflectionWMEEntry entry = (ReflectionWMEEntry) memory.get(wmeClassName);
      if (entry == null) {
         return new FullySerializableArrayList<>();
      } else {
         return new FullySerializableArrayList<>(entry.lookupWMEByProperty(userPropertyName));
      }
   }

   public static List<WME> lookupReflectionWMEByUserProperty(String memoryName, String wmeClassName, String userPropertyName) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      return wm.lookupReflectionWMEByUserProperty(wmeClassName, userPropertyName);
   }

   public static List<WMEIndex> lookupReflectionWMEIndicesByUserProperty(String memoryName, String wmeClassName,
                                                                         String userPropertyName) {
      WorkingMemory wm = lookupRegisteredMemory(memoryName);
      List<WME> reflectionWMEs = wm.lookupReflectionWMEByUserProperty(wmeClassName, userPropertyName);
      return WMEIndex.createWMEIndices(reflectionWMEs, wm);
   }

   /**
    * For the case where a Step property is set dynamically, we need to add it
    * to the WM property table on the fly, for indexing.
    * 
    * @param wme The WME being added.
    * @param name The name of the property newly set on (and maybe newly added
    *        to) the WME.
    */
   public void addWmeToPropertyTable(StepWME wme, String name) {
      modifyPropertyTable(wme, name, PropertyTableOperation.Add);
   }

   /**
    * @return Does the working memory contain this exact WME?
    * @param wme The wme to look for
    */
   public boolean containsThisWME(WME wme) {
      for (WME otherWME : lookupWME(wme.getClassname())) {
         if (wme == otherWME) {
            return true;
         }
      }
      return false;
   }

   /*
    * Removes this exact WME from working memory. If the wme is not in working
    * memory does nothing (doesn't throw an error).
    */
   public synchronized <T extends WME> void deleteExactWME(T wmeToDelete) {
      String wmeClass = wmeShortName(wmeToDelete);
      /*
       * ReflectionWMEs employ special removal logic, and, for now, do not
       * override equals, so they don't need to do strict equality checking
       */
      if (isReflectionWME(wmeClass)) {
         deleteWME(wmeToDelete);
      } else {
         List<String> classNameList = wmeShortNames(wmeToDelete);
         for (String wmeClassName : classNameList) {
            if (memory.containsKey(wmeClassName)) {
               // wme class has been added to working memory; continue.
               WMEntry<T> wmEntry = memory.get(wmeClassName);
               List<T> wmeList = wmEntry.getContents();
               Iterator<T> wmeListIt = wmeList.iterator();

               while (wmeListIt.hasNext()) {
                  T wmeToCheck = wmeListIt.next();
                  if (wmeToCheck == wmeToDelete) {
                     wmeListIt.remove();
                     break;
                  }
               }

               // If there are no WME's of this class left in working memory,
               // remove the key.
               if (wmeList.isEmpty()) {
                  memory.remove(wmeClassName);
               }
            }
         }
      }
      if (workingMemoryDebugger != null) {
         workingMemoryDebugger.updateIfMonitoring();
      }
   }

   /**
    * For the case where a Step property is removed dynamically, we need to
    * remove it from the WM property table on the fly, for indexing.
    * 
    * @param wme The WME being removed.
    * @param name The name of the property removed from the WME.
    */
   public void removeWmeFromPropertyTable(StepWME wme, String name) {
      modifyPropertyTable(wme, name, PropertyTableOperation.Remove);
   }

   private void modifyPropertyTable(StepWME wme, String name, PropertyTableOperation operation) {
      List<ReflectionWMEEntry> entries = lookupAllReflectionWmeEntries(wme);

      for (ReflectionWMEEntry entry : entries) {
         Map<String, Set<WME>> propertyTable = entry.getPropertyTable();
         Set<WME> wmesWithProperty = propertyTable.get(name);
         if (wmesWithProperty == null) {
            wmesWithProperty = new HashSet<>();
            propertyTable.put(name, wmesWithProperty);
         }

         switch (operation) {
            case Add:
               wmesWithProperty.add(wme);
               break;
            case Remove:
               wmesWithProperty.remove(wme);
               break;
            default:
               break;
         }
      }
   }

   @SuppressWarnings("unused")
   private final static Class<?> goalStepWME = abl.runtime.GoalStepWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> primitiveStepWME = abl.runtime.PrimitiveStepWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> mentalStepWME = abl.runtime.MentalStepWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> waitStepWME = abl.runtime.WaitStepWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> failStepWME = abl.runtime.FailStepWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> succeedStepWME = abl.runtime.SucceedStepWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> collectionBehaviorWME = abl.runtime.CollectionBehaviorWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> parallelBehaviorWME = abl.runtime.ParallelBehaviorWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> sequentialBehaviorWME = abl.runtime.SequentialBehaviorWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> stepWME = abl.runtime.StepWME.class;
   @SuppressWarnings("unused")
   private final static Class<?> behaviorWME = abl.runtime.BehaviorWME.class;

   // Returns true if the argument is the short name of a reflection WME, false
   // otherwise
   public static boolean isReflectionWME(String wmeClassName) {
      @SuppressWarnings("unused")
      Class<?> wmeClass;

      return wmeClassName.equals("ConditionalStepWME") || wmeClassName.equals("GoalStepWME")
            || wmeClassName.equals("ExecutableStepWME") || wmeClassName.equals("PrimitiveStepWME")
            || wmeClassName.equals("MentalStepWME") || wmeClassName.equals("WaitStepWME") || wmeClassName.equals("FailStepWME")
            || wmeClassName.equals("SucceedStepWME") || wmeClassName.equals("StepWME")
            || wmeClassName.equals("CollectionBehaviorWME") || wmeClassName.equals("ParallelBehaviorWME")
            || wmeClassName.equals("SequentialBehaviorWME") || wmeClassName.equals("MultiStepBehaviorWME")
            || wmeClassName.equals("BehaviorWME");

   }

   // Returns true if the argument is a reflection WME, false otherwise
   public static boolean isReflectionWME(WME wme) {
      Class<?> wmeClass = wme.getClass();

      return isReflectionWME(wmeShortName(wmeClass.getName()));
   }

   public static boolean isReflectionWME(Class<?> wmeClass) {
      return isReflectionWME(wmeShortName(wmeClass.getName()));
   }

   // ###############################################
   // Episodic memory methods

   // Returns the next wme of class wmeClassName after timestamp.
   public synchronized WME findNext(String wmeClassName, long timestamp) {
      try {
         assert Class.forName("wm.TimeStampedWME").isAssignableFrom(Class.forName(wmeClassName));
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
      List<WME> wmeList = lookupWME(wmeShortName(wmeClassName));
      if (wmeList.isEmpty()) {
         return null;
      } else {
         TimeStampedWME[] wmeArray = wmeList.toArray(new TimeStampedWME[wmeList.size()]);
         Arrays.sort(wmeArray); // fixme: should maintain TimeStampedWMEs in
                                // sorted order in wm
         for (TimeStampedWME aWmeArray : wmeArray) {
            if (aWmeArray.getTimestamp() > timestamp) {
               return aWmeArray;
            }
         }
         return null; // no wme found with getTimestamp() > timestamp
      }
   }

   public synchronized WME findPrev(String wmeClassName, long timestamp) {
      try {
         assert Class.forName("wm.TimeStampedWME").isAssignableFrom(Class.forName(wmeClassName));
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
      List<WME> wmeList = lookupWME(wmeShortName(wmeClassName));
      if (wmeList.isEmpty()) {
         return null;
      } else {
         TimeStampedWME[] wmeArray = wmeList.toArray(new TimeStampedWME[wmeList.size()]);
         Arrays.sort(wmeArray); // fixme: should maintain TimeStampedWMEs in
                                // sorted order in wm
         for (int i = wmeArray.length - 1; i >= 0; i--) {
            if (wmeArray[i].getTimestamp() < timestamp) {
               return wmeArray[i];
            }
         }
         return null; // no wme found with getTimestamp() < timestamp
      }
   }

   public synchronized WME findFirst(String wmeClassName) {
      try {
         assert Class.forName("wm.TimeStampedWME").isAssignableFrom(Class.forName(wmeClassName));
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
      List<WME> wmeList = lookupWME(wmeShortName(wmeClassName));
      if (wmeList.isEmpty()) {
         return null;
      } else {
         TimeStampedWME[] wmeArray = wmeList.toArray(new TimeStampedWME[wmeList.size()]);
         Arrays.sort(wmeArray); // fixme: should maintain TimeStampedWMEs in
                                // sorted order in wm
         return wmeArray[0];
      }
   }

   public synchronized WME findLast(String wmeClassName) {
      try {
         assert Class.forName("wm.TimeStampedWME").isAssignableFrom(Class.forName(wmeClassName));
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
      List<WME> wmeList = lookupWME(wmeShortName(wmeClassName));
      if (wmeList.isEmpty()) {
         return null;
      } else {
         TimeStampedWME[] wmeArray = wmeList.toArray(new TimeStampedWME[wmeList.size()]);
         Arrays.sort(wmeArray); // fixme: should maintain TimeStampedWMEs in
                                // sorted order in wm
         return wmeArray[wmeArray.length - 1];
      }
   }

   public synchronized List<WME> findAll(String wmeClassName, long beginTimestamp, long endTimestamp) {
      try {
         assert Class.forName("wm.TimeStampedWME").isAssignableFrom(Class.forName(wmeClassName));
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
      List<WME> wmeList = lookupWME(wmeShortName(wmeClassName));
      if (wmeList.isEmpty()) {
         return new ArrayList<>();
      } else {
         TimeStampedWME[] wmeArray = wmeList.toArray(new TimeStampedWME[wmeList.size()]);
         Arrays.sort(wmeArray); // fixme: should maintain TimeStampedWMEs in
                                // sorted order in wm
         List<WME> returnList = new ArrayList<>();
         for (TimeStampedWME aWmeArray : wmeArray) {
            if (aWmeArray.getTimestamp() >= beginTimestamp && aWmeArray.getTimestamp() <= endTimestamp) {
               returnList.add(aWmeArray);
            }
            if (aWmeArray.getTimestamp() > endTimestamp) {
               // Beyond endTimestamp; no reason to keep looking
               break;
            }
         }
         return returnList;
      }
   }

   public synchronized int countWMEBefore(String wmeClassName, long timestamp) {
      try {
         assert Class.forName("wm.TimeStampedWME").isAssignableFrom(Class.forName(wmeClassName));
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
      List<WME> wmeList = lookupWME(wmeShortName(wmeClassName));
      if (wmeList.isEmpty()) {
         return 0;
      } else {
         TimeStampedWME[] wmeArray = wmeList.toArray(new TimeStampedWME[wmeList.size()]);
         Arrays.sort(wmeArray); // fixme: should maintain TimeStampedWMEs in
                                // sorted order in wm
         int count = 0;
         for (TimeStampedWME aWmeArray : wmeArray) {
            if (aWmeArray.getTimestamp() < timestamp) {
               count++;
            }
            if (aWmeArray.getTimestamp() >= timestamp) {
               break;
            }
         }
         return count; // no wme found with getTimestamp() < timestamp
      }
   }

   public synchronized int countWMEAfter(String wmeClassName, long timestamp) {
      try {
         assert Class.forName("wm.TimeStampedWME").isAssignableFrom(Class.forName(wmeClassName));
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
      List<WME> wmeList = lookupWME(wmeShortName(wmeClassName));
      if (wmeList.isEmpty()) {
         return 0;
      } else {
         TimeStampedWME[] wmeArray = wmeList.toArray(new TimeStampedWME[wmeList.size()]);
         Arrays.sort(wmeArray); // fixme: should maintain TimeStampedWMEs in
                                // sorted order in wm
         int count = 0;
         for (int i = wmeArray.length - 1; i >= 0; i--) {
            if (wmeArray[i].getTimestamp() > timestamp) {
               count++;
            }
            if (wmeArray[i].getTimestamp() <= timestamp) {
               break;
            }
         }
         return count; // no wme found with getTimestamp() > timestamp
      }
   }

   public synchronized int countWMEBetween(String wmeClassName, long beginTimestamp, long endTimestamp) {
      try {
         assert Class.forName("wm.TimeStampedWME").isAssignableFrom(Class.forName(wmeClassName));
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
      List<WME> wmeList = lookupWME(wmeShortName(wmeClassName));
      if (wmeList.isEmpty()) {
         return 0;
      } else {
         TimeStampedWME[] wmeArray = wmeList.toArray(new TimeStampedWME[wmeList.size()]);
         Arrays.sort(wmeArray); // fixme: should maintain TimeStampedWMEs in
                                // sorted order in wm
         int count = 0;
         for (TimeStampedWME aWmeArray : wmeArray) {
            if (aWmeArray.getTimestamp() >= beginTimestamp && aWmeArray.getTimestamp() <= endTimestamp) {
               count++;
            }
            if (aWmeArray.getTimestamp() > endTimestamp) {
               // Beyond endTimestamp; no reason to keep looking
               break;
            }
         }
         return count;
      }
   }

   class WMTreeNode
         extends DefaultMutableTreeNode {
      private boolean isClassNode; // true if the node represents a
                                   // class rather than a particular wme

      WMTreeNode(Object nodeObject, boolean cn) {
         super(nodeObject);
         isClassNode = cn;
      }

      WMTreeNode(String nodeObject) {
         super(nodeObject);
      }

      boolean getIsClassNode() {
         return isClassNode;
      }
   }

   // Return a DefaultTreeModel containing a representation of working memory.
   // Used by the debugger.
   public synchronized DefaultTreeModel getWMTreeModel() {
      List<WME> wmeList;
      DefaultTreeModel WMTreeModel = new DefaultTreeModel(new DefaultMutableTreeNode("working memory root"));
      DefaultMutableTreeNode WMRoot = (DefaultMutableTreeNode) WMTreeModel.getRoot();
      WMTreeNode wmeClassNode;
      WMTreeNode wmeNode;
      for (Map.Entry<String, WMEntry> next : memory.entrySet()) {
         WMEntry<WME> value = next.getValue();
         wmeList = value.getContents();
         if (!wmeList.isEmpty()) {
            wmeClassNode = new WMTreeNode(next.getKey(), true);
            WMRoot.add(wmeClassNode);
            for (WME wme : wmeList) {
               wmeNode = new WMTreeNode(wme, false);
               wmeClassNode.add(wmeNode);
            }
         }
      }
      return WMTreeModel;
   }

   // Returns a working memory debugger interface.
   public WorkingMemoryDebugger getWMDebugInterface() {
      return new WorkingMemoryDebugger(this);
   }

   void setWMDebugger(WorkingMemoryDebugger wmd) {
      // A debugger for this working memory should not have been previously
      // created.
      assert workingMemoryDebugger == null;

      workingMemoryDebugger = wmd;
   }

   public synchronized void markTransientWMEs() {
      for (Object o : memory.keySet()) {
         String key = (String) o;
         if (!isReflectionWME(key)) {
            // Reflection WMEs aren't transient
            WMEntry<WME> wmEntry = memory.get(key);
            List<WME> wmes = wmEntry.getContents();
            if (!wmes.isEmpty()) {
               if (wmes.get(0).isTransient()) {
                  // The wmes in the list are transient - mark them
                  for (Object wme : wmes) {
                     ((TransientWME) wme).mark();
                  }
               }
            }
         }
      }
   }

   public synchronized void deleteMarkedTransientWMEs() {
      Iterator<String> memoryIterator = memory.keySet().iterator();
      while (memoryIterator.hasNext()) {
         String key = memoryIterator.next();
         if (!isReflectionWME(key)) {
            // Reflection WMEs aren't transient
            WMEntry<WME> wmEntry = memory.get(key);
            List<WME> wmes = new ArrayList<>(wmEntry.getContents()); // make a
                                                                     // copy of
            // the list to avoid
            // concurrent mod
            // errors
            if (!wmes.isEmpty() && wmes.get(0).isTransient()) {
               // The wmes in the list are transient - see if any are marked
               // for deletion
               Iterator<WME> wmeIterator = wmes.iterator();
               while (wmeIterator.hasNext()) {
                  TransientWME tWME = (TransientWME) wmeIterator.next();
                  if (tWME.getMarked()) {
                     wmeIterator.remove();
                  }
               }
               // If there are no WME's of this class left in working memory,
               // remove the key.
               if (wmes.isEmpty()) {
                  memoryIterator.remove();
               }
            }
         }
      }
      // Update debugger visualization if necessary
      if (workingMemoryDebugger != null) {
         workingMemoryDebugger.updateIfMonitoring();
      }
   }
}
