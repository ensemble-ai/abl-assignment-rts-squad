// Superclass for all working memory errors.

package wm;

import java.io.PrintStream;
import java.io.PrintWriter;

public class WorkingMemoryError
      extends Error {
   private Throwable t;

   public WorkingMemoryError() {
      super();
   }

   public WorkingMemoryError(String s) {
      super(s);
   }

   public WorkingMemoryError(String s, Throwable t) {
      super(s);
      this.t = t;
   }

   @Override
   public void printStackTrace() {
      if (t != null) {
         System.err.println(getMessage());
         t.printStackTrace();
      } else {
         super.printStackTrace();
      }
   }

   @Override
   public void printStackTrace(PrintStream s) {
      if (t != null) {
         s.println(getMessage());
         t.printStackTrace(s);
      } else {
         super.printStackTrace(s);
      }
   }

   @Override
   public void printStackTrace(PrintWriter w) {
      if (t != null) {
         w.println(getMessage());
         t.printStackTrace(w);
      } else {
         super.printStackTrace(w);
      }
   }
}
