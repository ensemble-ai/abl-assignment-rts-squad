/**
 * Copyright 2014 UCSC
 */
package wm;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import abl.runtime.FullySerializableArrayList;

/**
 * A set of working memories, consolidated into one structure. Can be queried
 * for lists of IndexedWMEs by type, spanning these memories.
 */
public class WorkingMemorySet
      implements Serializable {

   private Set<WorkingMemory> memSet = new HashSet<>();

   /**
    * Variable constructor for convenience
    * 
    * @param memories the memories to include in this set
    */
   public WorkingMemorySet(WorkingMemory... memories) {
      for (WorkingMemory memory : memories) {
         memSet.add(memory);
      }
   }

   public WorkingMemorySet(Collection<WorkingMemory> memories) {
      for (WorkingMemory memory : memories) {
         memSet.add(memory);
      }
   }
   
   public WorkingMemorySet(WorkingMemorySet memorySet) {
      add(memorySet);
   }

   /**
    * @param wm the working memory to add the set
    */
   public void add(WorkingMemory wm) {
      memSet.add(wm);
   }

   /**
    * @param wmSet the working memory set to add the set
    */
   public void add(WorkingMemorySet wmSet) {
      if (wmSet == null) {
         return;
      }
      for (WorkingMemory memory : wmSet.memSet) {
         memSet.add(memory);
      }
   }

   /**
    * @return A list of WMEIndex containing all WMEs of the class found in this
    *         set of Working Memories
    * @param wmeClassName the WME class to lookup
    */
   public synchronized List<WMEIndex> lookupWMEIndices(String wmeClassName) {
      List<WMEIndex> indexedWMEsOfClass = new FullySerializableArrayList<>();
      for (WorkingMemory memory : memSet) {
         List<WME> wmesToAdd = memory.lookupWME(wmeClassName);
         List<WMEIndex> wmeIndicesToAdd = WMEIndex.createWMEIndices(wmesToAdd, memory);
         indexedWMEsOfClass.addAll(wmeIndicesToAdd);
      }
      return indexedWMEsOfClass;
   }
   
   /**
    * @return A list of non-indexed WME containing all WMEs of the class found in this
    *         set of Working Memories
    * @param wmeClassName the WME class to lookup
    */
   public synchronized <T extends WME> List<T> lookupWME(Class<T> wmeClass) {
      List<T> allWMEsOfClass = new ArrayList<>();
      for (WorkingMemory memory : memSet) {
         List<T> wmesToAdd = memory.lookupWME(wmeClass);
         allWMEsOfClass.addAll(wmesToAdd);
      }
      return allWMEsOfClass;
   }

   /**
    * @return a list of WMEs with the given property - a reflectionWME search
    *         optimization
    */
   public List<WMEIndex> lookupReflectionWMEByUserProperty(String wmeClassName, String userPropertyName) {
      List<WMEIndex> indexedWMEsOfClass = new FullySerializableArrayList<>();
      for (WorkingMemory memory : memSet) {
         List<WME> wmesToAdd = memory.lookupReflectionWMEByUserProperty(wmeClassName, userPropertyName);
         List<WMEIndex> wmeIndicesToAdd = WMEIndex.createWMEIndices(wmesToAdd, memory);
         indexedWMEsOfClass.addAll(wmeIndicesToAdd);
      }
      return indexedWMEsOfClass;
   }

   /**
    * Given the name of a signature bearing reflection WME (e.g. "GoalStepWME")
    * and a signature name, returns a list of all WMEs sharing that signature.
    */
   public List<WMEIndex> lookupReflectionWMEBySignature(String wmeClassName, String signature) {
      List<WMEIndex> indexedWMEsOfClass = new FullySerializableArrayList<>();
      for (WorkingMemory memory : memSet) {
         List<WME> wmesToAdd = memory.lookupReflectionWMEBySignature(wmeClassName, signature);
         List<WMEIndex> wmeIndicesToAdd = WMEIndex.createWMEIndices(wmesToAdd, memory);
         indexedWMEsOfClass.addAll(wmeIndicesToAdd);
      }
      return indexedWMEsOfClass;
   }
}
