/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2013. All rights reserved.
 *
 *******************************************************************************/
package wm;

/**
 * An ordered relation, but with a float value
 */
public class OrderedRelationValuedFloatWME
      extends OrderedRelationValuedWME {

   float value;

   /**
    * @param f the value
    * @param type what the relation is
    * @param args whose part of it
    */
   public OrderedRelationValuedFloatWME(float f, String type, String... args) {
      super(type, true, args);
      value = f;
   }

   /**
    * @param f set the value to the float f
    */
   public void setValue(float f) {
      value = f;
   }

   /**
    * @return returns the float value
    */
   public float getValue() {
      return value;
   }
}
