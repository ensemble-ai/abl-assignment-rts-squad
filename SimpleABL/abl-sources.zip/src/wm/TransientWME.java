package wm;

public abstract class TransientWME
      extends WME {
   private boolean marked;

   // Marks a transient wme for deletion on the next decision cycle
   public void mark() {
      marked = true;
   }

   public boolean getMarked() {
      return marked;
   }

   @Override
   public boolean isTransient() {
      return true;
   }
}
