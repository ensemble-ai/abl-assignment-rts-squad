/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2013. All rights reserved.
 *
 *******************************************************************************/
package wm;

/**
 * The implementation of an ordered relation, that has a value, which is an int.
 */
public class OrderedRelationValuedIntWME
      extends OrderedRelationValuedWME {

   int value;

   /**
    * @param i the value
    * @param type what the relation is
    * @param args whose part of it
    */
   public OrderedRelationValuedIntWME(int i, String type, String... args) {
      super(type, true, args);
      value = i;
   }

   /**
    * @param i the int value to set
    */
   public void setValue(int i) {
      value = i;
   }

   /**
    * @return returns the value, an int
    */
   public int getValue() {
      return value;
   }

   @Override
   public String toString() {
      StringBuilder sb = new StringBuilder();

      sb.append("(");
      sb.append(type);

      for (String p : participants) {
         sb.append(" ").append(p);
      }

      sb.append(" ").append(value);

      sb.append(")");

      return sb.toString();
   }
}
