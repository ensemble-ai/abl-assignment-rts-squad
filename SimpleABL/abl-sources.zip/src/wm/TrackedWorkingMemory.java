/**
 * Copyright 2014 UCSC
 */
package wm;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Class which tracks additions and retractions to a working memory. Used for
 * keeping util memories in sync during a runRulegroup
 */
public class TrackedWorkingMemory {

   /* The memory being tracked */
   private WorkingMemory trackedMem;

   private Map<PointerEquivalencyWMEWrapper, Set<WorkingMemory>> trackingMap = new HashMap<>();

   /**
    * @param trackedMem the mem to track
    */
   public TrackedWorkingMemory(WorkingMemory trackedMem) {
      this.trackedMem = trackedMem;
   }
   
   /**
    * Convenience method which accepts a WME index
    * @param wmeIndex The index to add
    */
   public void add(WMEIndex wmeIndex) {
      add(wmeIndex.getWME(), wmeIndex.getMem());
   }

   /**
    * Add this WME to the tracking set. If it's a new addition, will be added to
    * the tracked mem.
    * 
    * @param wme The wme to add
    * @param the memory corresponding to this wme's addition
    */
   public void add(WME wme, WorkingMemory mem) {
      PointerEquivalencyWMEWrapper wmeRef = new PointerEquivalencyWMEWrapper(wme);
      /*
       * If the WME is already in the map, just add the mem to its entry. It
       * will already be in tracked mem
       */
      if (trackingMap.containsKey(wmeRef)) {
         trackingMap.get(wmeRef).add(mem);
      } else {
         /*
          * This is the first time it's being added to this tracking set, so add
          * an entry to the tracking map
          */
         Set<WorkingMemory> trackingSet = new HashSet<>();
         trackingSet.add(mem);
         trackingMap.put(wmeRef, trackingSet);
         /*
          * If the wme is already in the tracked memory, add a corresponding
          * entry to keep the tracking map in sync
          */
         if (trackedMem.containsThisWME(wme)) {
            trackingSet.add(trackedMem);
            /* The wme isn't in the tracked memory, so add it */
         } else {
            trackedMem.addWME(wme);
         }
      }
   }

   /**
    * Convenience wrapper which accepts a wmeIndex
    */
   public void remove(WMEIndex wmeIndex) {
      remove(wmeIndex.getWME(), wmeIndex.getMem());
   }
   
   public void remove(WME wme, WorkingMemory mem) {
      PointerEquivalencyWMEWrapper wmeRef = new PointerEquivalencyWMEWrapper(wme);

      /* If this isn't a tracked WME, just return */
      if (!trackingMap.containsKey(wmeRef)) {
         return;
      }

      /*
       * If the wme is being removed from the tracked mem, remove its entire
       * entry to keep the tracking map in sync
       */
      if (mem == this.trackedMem) {
         trackingMap.remove(wmeRef);
         /*
          * Just remove the corresponding memory. If the tracking set is now
          * empty, remove the wme from trackedMem
          */
      } else {
         Set<WorkingMemory> trackingSet = trackingMap.get(wmeRef);
         trackingSet.remove(mem);

         if (trackingSet.isEmpty()) {
            trackingMap.remove(wmeRef);
            /* Delete this exact wme from trackedMem, not merely one that equals it */
            trackedMem.deleteExactWME(wme);
         }
      }
   }
}
