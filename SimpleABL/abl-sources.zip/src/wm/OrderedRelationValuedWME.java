/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2013. All rights reserved.
 *
 *******************************************************************************/
package wm;

/**
 * Same as the ordered relation, but also has an associated value. this is just
 * a superclass for the particular implementations: int, float, string and
 * generic
 */
public class OrderedRelationValuedWME
      extends OrderedRelationWME {

   /**
    * @param type the type of the relation
    * @param set boolean whether it is set or not
    * @param args list of string arguments of the participants
    */
   public OrderedRelationValuedWME(String type, boolean set, String... args) {
      super(type, set, args);
   }

}
