/**
 * Copyright 2014 UCSC
 */
package wm;

/**
 * Wrapper class around WME which implements strict pointer equality checking
 */
class PointerEquivalencyWMEWrapper {
   private WME wme;

   PointerEquivalencyWMEWrapper(WME wme) {
      this.wme = wme;
   }

   @Override
   public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + ((wme == null) ? 0 : wme.hashCode());
      return result;
   }

   @Override
   public boolean equals(Object obj) {
      if (this == obj) {
         return true;
      }
      if (obj == null) {
         return false;
      }
      if (getClass() != obj.getClass()) {
         return false;
      }
      PointerEquivalencyWMEWrapper other = (PointerEquivalencyWMEWrapper) obj;
      if (wme == null) {
         if (other.wme != null) {
            return false;
         }
      } else if (wme != other.wme) {
         return false;
      }
      return true;
   }
}
