/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2013. All rights reserved.
 *
 *******************************************************************************/
package wm;

import java.util.ArrayList;
import java.util.List;

/**
 * Superclass of the relations. contains a boolean for whether the relation is
 * set or not, also contains a dictionary of arguments.
 */
public class RelationWME
      extends WME {
   // private static final Log log = LogFactory.getLog(CifRelationWME.class);

   List<String> participants;
   String type;
   boolean set;

   /**
    * @param type The type of the relation
    * @param set whether the relation is set or not
    * @param args The list of people involved in the relation
    */
   public RelationWME(String type, boolean set, String... args) {
      participants = new ArrayList<>(5);

      this.set = set;
      this.type = type;

      for (String s : args) {
         if (s != null) {
            participants.add(s);
         } else {
            System.out.println("We are ignoring a null participant passed in to this relation");
         }
      }

   }

   /*
    * Methods for getting arguments
    */
   /**
    * Get index for a value
    * 
    * @param a the input to find the index of
    * @return the index for the input a
    */
   public int getIndex(String a) {
      return participants.indexOf(a);
   }

   public String getFirstArg() {
      return participants.get(0);
   }

   /**
    * 
    * @return get the second argument
    */
   public String getSecondArg() {
      return participants.get(1);
   }

   /**
    * @return returns the third participant
    */
   public String getThirdArg() {
      return participants.get(2);
   }

   /**
    * @return the fourth participant
    */
   public String getFourthArg() {
      return participants.get(3);
   }

   /**
    * @return the fifth participant
    */
   public String getFifthArg() {
      return participants.get(4);
   }

   /**
    * 
    * @return the first argument index
    */
   public Integer getFirstArgIndex() {
      return 0;
   }

   /**
    * 
    * @return get the second argument index
    */
   public Integer getSecondArgIndex() {
      return 1;
   }

   /**
    * @return returns the third participant index
    */
   public Integer getThirdArgIndex() {
      return 2;
   }

   /**
    * @return the fourth participant index
    */
   public Integer getFourthArgIndex() {
      return 3;
   }

   /**
    * @return the fifth participant index
    */
   public Integer getFifthArgIndex() {
      return 4;
   }

   /**
    * @param i the location in the list of the participant you want
    * @return the ith participant
    */
   public String getArg(int i) {
      return participants.get(i);
   }

   /**
    * @return an int on the number of participants in the relation.
    */
   public int getArgCount() {
      return participants.size();
   }

   /**
    * @param s a string name of a character
    * @return whether that character is a participant
    */
   public boolean isAParticipant(String s) {
      return participants.contains(s);
   }

   /**
    * @return whether the relation is set or not
    */
   public boolean getSet() {
      return set;
   }

   /**
    * inverts the set state
    */
   public void setSet() {
      set = !set;
   }

   /**
    * @param b sets the set state to a specific boolean value
    */
   public void setSet(boolean b) {
      set = b;
   }

   @Override
   public String toString() {
      StringBuilder sb = new StringBuilder();

      sb.append("(");
      sb.append(type);

      for (String p : participants) {
         sb.append(" ").append(p);
      }

      sb.append(" ").append(set);

      sb.append(")");

      return sb.toString();
   }
}
