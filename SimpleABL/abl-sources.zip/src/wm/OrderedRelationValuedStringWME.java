/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2013. All rights reserved.
 *
 *******************************************************************************/
package wm;

/**
 * An ordered, valued relation, where the value is a string
 */
public class OrderedRelationValuedStringWME
      extends OrderedRelationValuedWME {

   String value;

   /**
    * @param s the value
    * @param type what the relation is
    * @param args whose part of it
    */
   public OrderedRelationValuedStringWME(String s, String type, String... args) {
      super(type, true, args);
      value = s;
   }

   /**
    * @param s set the value to the string s
    */
   public void setValue(String s) {
      value = s;
   }

   /**
    * @return returns the string value
    */
   public String getValue() {
      return value;
   }

}
