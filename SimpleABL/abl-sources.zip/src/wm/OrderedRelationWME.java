/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2013. All rights reserved.
 *
 *******************************************************************************/
package wm;

/**
 * The implementation of the ordered relation in cif.
 */
public class OrderedRelationWME
      extends RelationWME {

   /**
    * @param type what the relation is
    * @param set whether the relation is set or not
    * @param args who is in it
    */
   public OrderedRelationWME(String type, boolean set, String... args) {
      super(type, set, args);
   }

}
