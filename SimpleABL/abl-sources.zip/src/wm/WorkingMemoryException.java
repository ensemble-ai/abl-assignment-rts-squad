// Superclass for all working memory exceptions.

package wm;

public class WorkingMemoryException
      extends Exception {
   public WorkingMemoryException() {
      super();
   }

   public WorkingMemoryException(String s) {
      super(s);
   }
}
