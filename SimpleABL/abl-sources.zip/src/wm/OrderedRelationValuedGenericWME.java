/*******************************************************************************
 * Copyright (c) Raytheon BBN Technologies 2013. All rights reserved.
 *
 *******************************************************************************/
package wm;

/**
 * An ordered, Valued relation, where the value is any object
 */
public class OrderedRelationValuedGenericWME
      extends OrderedRelationValuedWME {
   Object value;

   /**
    * @param o the value
    * @param type what the relation is
    * @param args whose part of it
    */
   public OrderedRelationValuedGenericWME(Object o, String type, String... args) {
      super(type, true, args);
      value = o;
   }

   /**
    * @param o the generic object to set the value to
    */
   public void setValue(Object o) {
      value = o;
   }

   /**
    * @return get the generic object that is the value
    */
   public Object getValue() {
      return value;
   }

}
