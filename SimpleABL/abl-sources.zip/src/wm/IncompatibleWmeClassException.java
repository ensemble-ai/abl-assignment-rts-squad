package wm;

public class IncompatibleWmeClassException
      extends WorkingMemoryException {
   private static final String errorString = "Attempt to modify a WME with an incompatible WME class";

   public IncompatibleWmeClassException() {
      super(errorString);
   }

   public IncompatibleWmeClassException(String s) {
      super(errorString + ": " + s);
   }
}
