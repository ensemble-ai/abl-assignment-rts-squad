/**
 * Copyright 2014 UCSC
 */
package wm;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Random;

public abstract class ScorableWME
      extends WME
      implements Comparable<ScorableWME> {
   private int score;

   /**
    * @return this ScorableWME's score
    */
   public int getScore() {
      return score;
   }

   /**
    * @param score new score to set
    */
   public void setScore(int score) {
      this.score = score;
   }

   /**
    * @param amt Amt to add to score
    */
   public void addScore(int amt) {
      score += amt;
   }

   @Override
   public String toString() {
      return this.getClassname() + ", score: " + score;
   }

   @Override
   public int compareTo(ScorableWME other) {
      if (this.score < other.score) {
         return -1;
      } else if (this.score == other.score) {
         return 0;
      }
      return 1;
   }

   /**
    * Leaves only the highest scoring ScorableWME in mem - not necessarily
    * ordered If there are fewer than n scorables in mem, leaves all present.
    * Also returns those chosen in a list.
    * 
    * @param mem the workingMemory to apply on
    * @param n How many scorables to leave
    * @return the n best in a list
    */
   public static List<ScorableWME> pickBestN(WorkingMemory mem, int n) {
      List<ScorableWME> scorables = mem.lookupWME(ScorableWME.class);

      /* Clear the mem */
      mem.clear();

      /*
       * If there are no scorables, or none are requested, just return an empty
       * memory
       */
      if (scorables == null || scorables.isEmpty() || n == 0) {
         return new ArrayList<>();
      }

      if (scorables.size() <= n) {
         mem.addWMEs(scorables);
         return new ArrayList<>();
      }

      PriorityQueue<ScorableWME> bestNScorables = new PriorityQueue<>(n);
      for (ScorableWME scorable : scorables) {
         if (bestNScorables.size() < n) {
            bestNScorables.add(scorable);
         } else if (bestNScorables.peek().getScore() < scorable.getScore()) {
            bestNScorables.remove();
            bestNScorables.add(scorable);
         }
      }

      mem.addWMEs(bestNScorables);
      return new ArrayList<>(bestNScorables);
   }

   /**
    * Leaves only the single highest scoring ScorableWME in mem, and returns it.
    * Returns null if mem contains no scorableWMEs.
    * 
    * @param mem the workingMemory to apply on
    * @return the highest scored WME
    */
   public static ScorableWME pickBest(WorkingMemory mem) {
      List<ScorableWME> scorables = mem.lookupWME(ScorableWME.class);

      /* Clear the mem */
      mem.clear();

      /*
       * If there are no scorables, just return an empty memory
       */
      if (scorables == null || scorables.isEmpty()) {
         return null;
      }

      ScorableWME best = scorables.get(0);
      for (int i = 1; i < scorables.size(); i++) {
         ScorableWME nominee = scorables.get(i);
         if (nominee.getScore() > best.getScore()) {
            best = nominee;
         }
      }

      mem.addWME(best);
      return best;
   }

   /**
    * Leaves only a single random ScorableWME in mem, and returns it. Returns
    * null if mem contains no scorableWMEs.
    * 
    * @param mem the workingMemory to apply on
    * @return the random WME chosen
    */
   public static ScorableWME pickRandom(WorkingMemory mem) {
      List<ScorableWME> scorables = mem.lookupWME(ScorableWME.class);

      /* Clear the mem */
      mem.clear();

      /*
       * If there are no scorables, just return an empty memory
       */
      if (scorables == null || scorables.isEmpty()) {
         return null;
      }

      int randIndex = new Random().nextInt(scorables.size());
      ScorableWME randScorable = scorables.get(randIndex);
      mem.addWME(randScorable);
      return randScorable;
   }

   /**
    * Leaves only ScorableWMEs with score >= threshold in mem Also returns the
    * list of ScorableWMEs above threshold.
    * 
    * @param mem the workingMemory to apply on
    * @param threshold the minimum score to leave in mem
    */
   public synchronized static List<ScorableWME> threshold(WorkingMemory mem, int threshold) {
      List<ScorableWME> scorables = mem.lookupWME(ScorableWME.class);

      /* Clear the mem */
      mem.clear();

      /*
       * If there are no scorables, just return an empty memory
       */
      if (scorables == null) {
         return new ArrayList<>();
      }

      /*
       * If a scorable is greater or equal to threshold, add it back into mem,
       * otherwise, remove it from the list
       */
      Iterator<ScorableWME> scorableIt = scorables.iterator();
      while (scorableIt.hasNext()) {
         ScorableWME scorable = scorableIt.next();
         if (scorable.getScore() >= threshold) {
            mem.addWME(scorable);
         } else {
            scorableIt.remove();
         }
      }
      /* Only those greater than or equal to the threshold will remain at this point */
      return scorables;
   }

   /**
    * Leaves any ScorableWMEs in mem. Other WMEs are removed. Returns those
    * remaining in a list.
    * 
    * @param mem the workingMemory to apply on
    * @return the list of ScorableWMEs remaining in mem
    */
   public static List<ScorableWME> pickAll(WorkingMemory mem) {
      List<ScorableWME> scorables = mem.lookupWME(ScorableWME.class);

      /* Clear the mem */
      mem.clear();

      /*
       * If there are no scorables, just return an empty memory
       */
      if (scorables == null || scorables.isEmpty()) {
         return new ArrayList<>();
      }

      mem.addWMEs(scorables);
      return scorables;
   }
}
