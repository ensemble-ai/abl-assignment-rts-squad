// All episodic WMEs inherit from TimeStampedWME

package wm;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JComboBox;

public abstract class TimeStampedWME
      extends WME
      implements Comparable<TimeStampedWME> {
   private long timestamp;

   private static final SimpleDateFormat formatter;

   static {
      formatter = new SimpleDateFormat("MM.dd.yyyy hh:mm:ss:S a");
   }

   public TimeStampedWME(long timestamp) {
      this.timestamp = timestamp;
   }

   public TimeStampedWME() {
      timestamp = 0;
   }

   public synchronized long getTimestamp() {
      return timestamp;
   }

   public synchronized void setTimestamp(long timestamp) {
      this.timestamp = timestamp;
   }

   public synchronized String formatTimestamp() {
      return formatter.format(new Date(getTimestamp()));
   }

   private final static String[] menuItems = {
      "Set current time"
   };

   private class TimestampEditor
         extends JComboBox<String>
         implements WMEFieldEditor {

      TimestampEditor() {
         super(menuItems);
         setEditable(true);
         if (getTimestamp() != 0) {
            setSelectedItem(formatTimestamp());
         } else {
            setSelectedItem("");
         }
         addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               // Only one menu item, so if an action fires we know it is this
               // item
               setFieldValue(Long.toString(System.currentTimeMillis()));
            }
         });
      }

      @Override
      public String getFieldValue() {
         try {
            return Long.toString(formatter.parse(getSelectedItem().toString()).getTime());
         } catch (ParseException e) {
            System.err.println("Parse error: " + e.getMessage() + " in TimestampEditor.getTimeValue(). Returning null.");
            return null;
         }
      }

      // s is a string representation of a long
      @Override
      public void setFieldValue(String s) {
         setSelectedItem(formatter.format(new Date(Long.parseLong(s))));
      }

   }

   public WMEFieldEditor _getTimestampEditor() {
      return new TimestampEditor();
   }

   // Comparable implementation
   @Override
   public int compareTo(TimeStampedWME o) {
      TimeStampedWME wmeToCompare = o;
      if (getTimestamp() < wmeToCompare.getTimestamp()) {
         return -1;
      } else if (getTimestamp() > wmeToCompare.getTimestamp()) {
         return 1;
      } else {
         return 0;
      }
   }
}
