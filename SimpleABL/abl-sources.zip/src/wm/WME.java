package wm;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import abl.runtime.AblRuntimeError;

public abstract class WME
      implements Cloneable, Serializable {

   // TODO: Will need to enforce the definition of equals if working memory
   // modification routines are written which
   // allow a user to modify memory with WME descriptions rather than WME
   // references. Currently working memory
   // can only be modified by WME references.
   /*
    * Overrides equals(Object o) on class Object. The default equality test
    * returns true if the two objects are precisely the same object (to
    * references pointing to the same object in memory. Each concrete WME should
    * redefine equals such that two WMEs are equal if they are the same class
    * and their fields are equal. WME field equality should recursively depend
    * only on value, not on reference identity.
    */
   // public abstract boolean equals(Object Obj);

   private final PropertyChangeSupport __support = new PropertyChangeSupport(this);

   private final static String BOLD_TAG = "<B>";
   private final static String UNBOLD_TAG = "</B>";

   public static String lowercaseFirstCharacter(String s) {
      StringBuilder tempStringBuffer = new StringBuilder(s);
      tempStringBuffer.setCharAt(0, Character.toLowerCase(tempStringBuffer.charAt(0)));
      return tempStringBuffer.toString();
   }

   public static String uppercaseFirstCharacter(String s) {
      StringBuilder tempStringBuffer = new StringBuilder(s);
      tempStringBuffer.setCharAt(0, Character.toUpperCase(tempStringBuffer.charAt(0)));
      return tempStringBuffer.toString();
   }

   /**
    * FIXME should use standard Java introspection.
    */
   public Method[] _getSetMethods() {
      try {
         Class<? extends WME> thisClass = this.getClass();
         Method[] wmeMethods = thisClass.getMethods();
         List<Method> wmeSetMethods = new ArrayList<>(wmeMethods.length);

         for (Method wmeMethod : wmeMethods) {
            String methodName = wmeMethod.getName();
            if (methodName.substring(0, 3).equals("set") && wmeMethod.getParameterTypes().length == 1) {
               // The public method begins with the substring "get", and takes
               // one parameter,
               // hence it is a set accessor.

               wmeSetMethods.add(wmeMethod);
            }
         }
         Method[] wmeSetMethodArray = new Method[wmeSetMethods.size()];
         return wmeSetMethods.toArray(wmeSetMethodArray);
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
   }

   /**
    * FIXME should use standard Java introspection.
    */
   public Method[] _getGetMethods() {
      try {
         Class<? extends WME> thisClass = this.getClass();
         Method[] wmeMethods = thisClass.getMethods();
         List<Method> wmeGetMethods = new ArrayList<>(wmeMethods.length);

         for (Method wmeMethod : wmeMethods) {
            String methodName = wmeMethod.getName();
            if (methodName.substring(0, 3).equals("get") && !methodName.equals("getClass")
                && wmeMethod.getParameterTypes().length == 0) {
               // The public method begins with the substring "get", takes no
               // parameters and is not "getClass";
               // hence it is a get accessor.

               wmeGetMethods.add(wmeMethod);
            }
         }
         Method[] wmeGetMethodArray = new Method[wmeGetMethods.size()];
         return wmeGetMethods.toArray(wmeGetMethodArray);
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
   }

   /**
    * FIXME should use standard Java introspection.
    */
   public String[] _getFieldNames() {
      Method[] getMethods = _getGetMethods();
      String[] fieldNames = new String[getMethods.length];
      for (int i = 0; i < getMethods.length; i++) {
         fieldNames[i] = lowercaseFirstCharacter(getMethods[i].getName().substring(3));
      }
      return fieldNames;
   }

   /**
    * FIXME should use standard Java introspection.
    */
   public Class<?>[] _getFieldTypes() {
      Method[] getMethods = _getGetMethods();
      Class<?>[] fieldTypes = new Class[getMethods.length];
      for (int i = 0; i < getMethods.length; i++) {
         fieldTypes[i] = getMethods[i].getReturnType();
      }
      return fieldTypes;
   }

   /**
    * FIXME should use standard Java introspection.
    */
   public Method _getGetMethod(String fieldName)
         throws NoSuchFieldException {
      String getMethodName = "get" + uppercaseFirstCharacter(fieldName);
      try {
         return this.getClass().getMethod(getMethodName, (Class[]) null);
      } catch (NoSuchMethodException e) {
         throw new NoSuchFieldException(fieldName);
      }
   }

   /**
    * FIXME should use standard Java introspection.
    */
   public Method _getSetMethod(String fieldName, Class<?> fieldType)
         throws NoSuchFieldException {
      String setMethodName = "set" + uppercaseFirstCharacter(fieldName);
      try {
         return this.getClass().getMethod(setMethodName, fieldType);
      } catch (NoSuchMethodException e) {
         throw new NoSuchFieldException(fieldName);
      }
   }

   // Returns a string representation of the WME field values.
   @Override
   public String toString() {
      String[] fieldNames = _getFieldNames();
      Method[] getMethods = _getGetMethods();
      StringBuilder wmeString = new StringBuilder();
      wmeString.append("(");
      try {
         for (int i = 0; i < fieldNames.length; i++) {
            wmeString.append(fieldNames[i]).append(": ");

            String formatFieldMethodName = "format" + uppercaseFirstCharacter(fieldNames[i]);

            // fixme: quick and dirty fix for avoiding cycles when creating
            // string representation of a wme;
            // don't recursively call WME.toString() on WMEs. Eventually fix
            // with something that really avoids
            // cycles.
            if (!Class.forName("wm.WME").isAssignableFrom(getMethods[i].getReturnType())) {
               // The return type of the get accessor is not a WME; safe to
               // implicitly evoke toString()
               // on the return type.

               // If there is a special formatter for the field use it,
               // otherwise do a default toString()
               try {
                  Method formatFieldMethod = this.getClass().getMethod(formatFieldMethodName, (Class[]) null);
                  wmeString.append(formatFieldMethod.invoke(this, (Object[]) null));
               } catch (NoSuchMethodException e) {
                  wmeString.append(getMethods[i].invoke(this, (Object[]) null));
               }
            } else {
               // The return type of the get accessor *is* assignable to a WME

               // If there is a special formatter for the field use it,
               // otherwise use the super (default)
               // string represetation for the WME or "null" if the return value
               // is null.
               try {
                  Method formatFieldMethod = this.getClass().getMethod(formatFieldMethodName, (Class[]) null);
                  wmeString.append(formatFieldMethod.invoke(this, (Object[]) null));
               } catch (NoSuchMethodException e) {
                  WME tempWME = (WME) getMethods[i].invoke(this, (Object[]) null);
                  if (tempWME == null) {
                     wmeString.append(tempWME);
                  } else {
                     wmeString.append(tempWME.objectToString());
                  }
               }
            }
            if (i + 1 != fieldNames.length) {
               wmeString.append(", ");
            }
         }
         wmeString.append(")");
         return wmeString.toString();
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
   }

   // Returns a formatted (html) string representation of the WME field values.
   public String toString_HTML() {
      String[] fieldNames = _getFieldNames();
      Method[] getMethods = _getGetMethods();
      StringBuilder wmeString = new StringBuilder();

      wmeString.append("<font size = \"-1\" face=\"Helvetica, Arial, sans-serif\">");
      wmeString.append("(");
      try {
         for (int i = 0; i < fieldNames.length; i++) {
            wmeString.append(fieldNames[i]).append(": ");

            String formatFieldMethodName = "format" + uppercaseFirstCharacter(fieldNames[i]);

            // fixme: quick and dirty fix for avoiding cycles when creating
            // string representation of a wme;
            // don't recursively call WME.toString() on WMEs. Eventually fix
            // with something that really avoids
            // cycles.
            if (!Class.forName("wm.WME").isAssignableFrom(getMethods[i].getReturnType())) {
               // The return type of the get accessor is not a WME; safe to
               // implicitly evoke toString()
               // on the return type.

               // If there is a special formatter for the field use it,
               // otherwise do a default toString()
               try {
                  Method formatFieldMethod = this.getClass().getMethod(formatFieldMethodName, (Class[]) null);
                  wmeString.append(BOLD_TAG).append(formatFieldMethod.invoke(this, (Object[]) null)).append(UNBOLD_TAG);
               } catch (NoSuchMethodException e) {
                  wmeString.append(BOLD_TAG).append(getMethods[i].invoke(this, (Object[]) null)).append(UNBOLD_TAG);
               }
            } else {
               // The return type of the get accessor *is* assignable to a WME;

               // If there is a special formatter for the field use it,
               // otherwise use the super (default)
               // string represetation for the WME or "null" if the return value
               // is null.
               try {
                  Method formatFieldMethod = this.getClass().getMethod(formatFieldMethodName, (Class[]) null);
                  wmeString.append(BOLD_TAG).append(formatFieldMethod.invoke(this, (Object[]) null)).append(UNBOLD_TAG);
               } catch (NoSuchMethodException e) {
                  WME tempWME = (WME) getMethods[i].invoke(this, (Object[]) null);
                  if (tempWME == null) {
                     wmeString.append(BOLD_TAG).append(tempWME).append(UNBOLD_TAG);
                  } else {
                     wmeString.append(BOLD_TAG).append(tempWME.objectToString()).append(UNBOLD_TAG);
                  }
               }

            }

            if (i + 1 != fieldNames.length) {
               wmeString.append(", ");
            }
         }
         wmeString.append(")");
         return wmeString.toString();
      } catch (Exception e) {
         throw new WmeReflectionError(e);
      }
   }

   // Returns the default (Object.toString()) string representation of the WME
   protected String objectToString() {
      return super.toString();
   }

   // Support for property change listeners
   public void addPropertyChangeListener(PropertyChangeListener lis) {
      __support.addPropertyChangeListener(lis);
   }

   public void removePropertyChangeListener(PropertyChangeListener lis) {
      __support.removePropertyChangeListener(lis);
   }

   public void addPropertyChangeListener(String propName, PropertyChangeListener lis) {
      __support.addPropertyChangeListener(lis);
   }

   public void removePropertyChangeListener(String propName, PropertyChangeListener lis) {
      __support.removePropertyChangeListener(propName, lis);
   }

   // Transient wmes should override this and return true.
   public boolean isTransient() {
      return false;
   }

   // Assign the values of the argument WME to this one
   public void assign(WME wmeToAssign) {
      Method[] getMethods = wmeToAssign._getGetMethods();
      @SuppressWarnings("unused")
      Class<?>[] fieldTypes = wmeToAssign._getFieldTypes();
      for (Method getMethod : getMethods) {
         try {
            String fieldName = lowercaseFirstCharacter(getMethod.getName().substring(3));
            Class<?> argType = getMethod.getReturnType();
            try {
               Method setMethod = this._getSetMethod(fieldName, argType);
               Object[] setArgs = {
                   getMethod.invoke(wmeToAssign, (Object[]) null)
               };
               setMethod.invoke(this, setArgs);
            } catch (NoSuchFieldException e) {
            } // If the attempt to grab setMethod generates a
            // NoSuchFieldException (thrown by _getSetMethod), just move on.
            // The newly created WME will have the default value for this
            // field, rather than the edited value.
         } catch (Exception e) {
            throw new WmeReflectionError(e);
         }
      }
   }

   /**
    * @return the short name of the W
    * Added by Gillian Smith, 06-08-10.
    */
   public String getClassname() {
      return WorkingMemory.wmeShortName(this);
   }
   
   /**
    * @return a field-by-field clone of this WME
    */
   @Override
   public WME clone() {
      WME clonedWME;
      Class<? extends WME> thisClass = getClass();
      try {
         clonedWME = thisClass.newInstance();
      } catch (InstantiationException | IllegalAccessException e) {
         throw new AblRuntimeError("WME.clone() was unable to instantiate a new instance of class " + getClass(), e);
      }
      
      WME.copyAllFieldsForThisWMETypeHierarchy(thisClass, this, clonedWME);
      
      return clonedWME;
   }
      
   public boolean shallowEquals(WME otherWME) {
      if(this==otherWME) {
         return true;
      }
      if (otherWME == null) {
         return false;
      }
      if (getClass() != otherWME.getClass()) {
         return false;
      }
      
      return WME.shallowEqualsForThisWMEHierarchy(getClass(), this, otherWME);
   }
   
   /**
    * @return true if these two wmes have shallow-equivalent fields for this and any superclasses, up to the WME abstract class 
    */
   private static <T extends WME> boolean shallowEqualsForThisWMEHierarchy(Class<T> klazz, WME wme1, WME wme2) {
      // both WMEs must be instances of this class
      if (!(klazz.isInstance(wme1)  && klazz.isInstance(wme2))) {
         return false;
      }
      
      // If we reach the WME abstract class, return true
      if (klazz.equals(WME.class)) {
         return true;
      }
      
      Field[] classFields = klazz.getDeclaredFields();
      // set the fields in the class accessible
      AccessibleObject.setAccessible(classFields, true);
      for(Field f : classFields) {
         try {
            Object wme1ValForField = f.get(wme1);
            Object wme2ValForField = f.get(wme2);
            // They're both non-null, so compare the values
            if (wme1ValForField != null && wme2ValForField != null) {
               // If it's a primitive type, use object equals
               if(f.getType().isPrimitive()) {
                  if(!wme1ValForField.equals(wme2ValForField)) {
                     return false;
                  }
               // If it's an object instance, use a memory reference check
               } else {
                  if (wme1ValForField != wme2ValForField) {
                     return false;
                  }
               }
            // Catch case where one WME has field null, while other doesn't
            } else if (wme1ValForField != wme2ValForField) {
               return false;
            }
         } catch (IllegalArgumentException | IllegalAccessException e) {
            throw new AblRuntimeError("WME.shallowEqualsForTypeHierarchy() was unable to access a field for class " + klazz, e);
         }
      }
      Class<? super T> superClass = klazz.getSuperclass();
      // If the class has a superclass, recurse. Otherwise, the hierarchy should cap out at WME, which would have been caught up top.
      if (superClass != null) {
         // Confirm that the superclass still extends WME
         Class<? extends WME> superClassAsWMESubClass = superClass.asSubclass(WME.class);
         return WME.shallowEqualsForThisWMEHierarchy(superClassAsWMESubClass, wme1, wme2);
      } else {
         // If somehow the hierarchy extends beyond WME, throw an error
         throw new AblRuntimeError("WME.shallowEqualsForTypeHierarchy() reached beyond a class extending WME  " + klazz);
      }
   }
   
   public static <T extends WME> void copyAllFieldsForThisWMETypeHierarchy(Class<T> klazz, WME originWME, WME copiedWME) {
      // both WMEs must be instances of this class
      if (!(klazz.isInstance(originWME)  && klazz.isInstance(copiedWME))) {
         throw new AblRuntimeError("WME.copyAllFieldsForThisWMETypeHierarchy() called with WMEs that were not both instances of class " + klazz);
      }
      
      // If we reach the WME abstract class, return
      if (klazz.equals(WME.class)) {
         return;
      }
      
      Field[] classFields = klazz.getDeclaredFields();
      // set the fields in the class accessible
      AccessibleObject.setAccessible(classFields, true);
      for(Field f : classFields) {
         try {
            Object originWMEValForField = f.get(originWME);
            f.set(copiedWME, originWMEValForField);
         } catch (IllegalArgumentException | IllegalAccessException e) {
            throw new AblRuntimeError("WME.copyAllFieldsForThisWMETypeHierarchy() was unable to access a field for class " + klazz, e);
         }
      }
      Class<? super T> superClass = klazz.getSuperclass();
      // If the class has a superclass, recurse. Otherwise, the hierarchy should cap out at WME, which would have been caught up top.
      if (superClass != null) {
         // Confirm that the superclass still extends WME
         Class<? extends WME> superClassAsWMESubClass = superClass.asSubclass(WME.class);
         WME.copyAllFieldsForThisWMETypeHierarchy(superClassAsWMESubClass, originWME, copiedWME);
      } else {
         // If somehow the hierarchy extends beyond WME, throw an error
         throw new AblRuntimeError("WME.copyAllFieldsForThisWMETypeHierarchy() reached beyond a class extending WME  " + klazz);
      }
   }
}
