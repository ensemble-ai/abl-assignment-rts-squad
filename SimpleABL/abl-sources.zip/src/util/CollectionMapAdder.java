/**
 * Copyright 2014 UCSC
 */
package util;

import java.util.Collection;
import java.util.Map;

public class CollectionMapAdder<K, T, C extends Collection<T>> {

   /**
    * Destructively add one map with collections as values to another
    * 
    * @param mapToAddTo the map to add to
    * @param mapToAdd the map to add
    */
   public synchronized void add(Map<K, C> mapToAddTo, Map<K, C> mapToAdd) {
      for (Map.Entry<K, C> otherEntry : mapToAdd.entrySet()) {
         K key = otherEntry.getKey();
         C collectionToAdd = otherEntry.getValue();

         /* If the key is in this entry's table, just add the contents */
         if (mapToAddTo.containsKey(key)) {
            mapToAddTo.get(key).addAll(collectionToAdd);
         } else {
            mapToAddTo.put(key, collectionToAdd);
         }
      }
   }
}
