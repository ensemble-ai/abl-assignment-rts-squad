/**
 * Copyright 2014 UCSC
 */
package abl.runtime;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.junit.Before;
import org.junit.Test;

/**
 * Try to ensure that the Iterator are working correctly
 */
public class TestSerializableArray {

   private List<Integer> testList;

   /**
    * Create an array to test against
    */
   @Before
   public void setup() {
      testList = new FullySerializableArrayList<>();
   }

   /**
    * Test remove functionality in basic Iterator
    */
   @Test
   public void testSimpleIteratorRemove() {
      testList.add(1);
      testList.add(2);
      testList.add(3);
      Iterator<Integer> it = testList.iterator();
      while (it.hasNext()) {
         it.next();
         it.remove();
      }
      assertTrue(testList.isEmpty());
   }

   /**
    * Test add and remove functionality in ListIterator
    */
   @Test
   public void testListItrAddRemove() {
      testList.add(1);
      testList.add(2);
      testList.add(3);
      ListIterator<Integer> it = testList.listIterator();
      it.add(4);
      assertEquals(4, testList.size());

      it = testList.listIterator();
      while(it.hasNext()) {
         it.next();
         it.remove();
      }
      assertTrue(testList.isEmpty());
   }
}
