package ablTestPackage;

public class TestClass {

	int i;

	public TestClass(int i) {
		this.i = i;
	}

	public int getI() {
		return i;
	}

}
