package ablTestPackage;



public enum EnumTest {
TEST;
}
