// An interface defining debug constants

package abl.compiler; 

public interface AblDebuggerConstants {
    static final byte GUI_DEBUGGER = 2; // Debug level for full GUI debugger.
    static final byte DEBUG_WITHOUT_GUI = 1; // Debug level for mental act hang and joint goal negotiation tracing only.
    static final byte NO_DEBUG = 0; // No debugging.
}
