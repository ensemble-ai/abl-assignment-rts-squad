package abl.compiler;

public class ASTVariableDeclaratorID extends AblParseNode {
  public ASTVariableDeclaratorID(int id) {
    super(id);
  }

  public ASTVariableDeclaratorID(AblParser p, int id) {
    super(p, id);
  }

}
