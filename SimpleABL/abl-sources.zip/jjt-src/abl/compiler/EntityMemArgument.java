/**
 * Copyright 2014 UCSC
 */
package abl.compiler;

import wm.WorkingMemory;

public class EntityMemArgument
      extends AblArgument {
   public static final String workingMemoryTypeString = wm.WorkingMemory.class.getSimpleName();
   public static final String entityLookupString = "BehavingEntity.getBehavingEntity().getWorkingMemory()";

   public EntityMemArgument() {
      super(null, workingMemoryTypeString);
   }

   public String toString() {
      return entityLookupString;
   }
}
