// CompileableToStream objects must implement a transform that generates implementation code and writes it to a PrintStream

package abl.compiler;

import java.io.PrintStream;

public interface CompileableToStream {

    public void compileToJava(PrintStream codeStream) throws CompileException;
}
