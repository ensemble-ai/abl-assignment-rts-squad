package abl.compiler;

import java.util.*;

/* Utility class associating primitive action objects with lists
 of their argument types. */

class RegisteredAction {
	/* Name of the concrete PrimitiveAction class. */
	final String actionClass; 
	
	/* List of argument types for this action. Argument types are
	 represented as fully qualified String type names. */
	final List<String> argTypes;
	
	RegisteredAction(String arg_actionClass, List<String> arg_argTypes)
	{
		actionClass = arg_actionClass;
		argTypes = arg_argTypes;
	}
}

