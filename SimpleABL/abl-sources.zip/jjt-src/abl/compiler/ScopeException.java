package abl.compiler;

public class ScopeException extends CompileException {
    private static final String errorString = "Undeclared variable";
    public ScopeException() {
	super(errorString);
    }

    public ScopeException(String s) {
	super(errorString + ": " + s);
    }
}
