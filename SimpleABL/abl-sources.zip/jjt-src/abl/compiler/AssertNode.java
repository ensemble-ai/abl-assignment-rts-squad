package abl.compiler;

import java.util.Set;

import jd.JavaCodeDescriptor;

/**
 * 
 * @author reid
 *
 */
public abstract class AssertNode extends AblParseNode {
	AssertNode(int id) { super(id); }
    AssertNode(AblParser p, int id) { super(p, id); }
    private ASTWMEAssertSequence parentAssertSequence;

    void setParentAssertSequence(ASTWMEAssertSequence parentAssertSequence) {
       this.parentAssertSequence = parentAssertSequence;
    } 
    
    protected ASTWMEAssertSequence getParentAssertSequence() {
       return parentAssertSequence;
    }

	// Returns a set of the variables bound within the test. 
	abstract Set<String> getBoundVariables(); 
	
	// Returns a Set of the explicitly declared variables (declared in behavior or global?? scope) referenced by this test.
	abstract Set getExplicitlyDeclaredVariableReferences();
		
    abstract JavaCodeDescriptor compileToJava() throws CompileException;
}
