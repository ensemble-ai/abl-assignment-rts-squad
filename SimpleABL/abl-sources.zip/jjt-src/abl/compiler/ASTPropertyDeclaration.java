// Parse tree node for property declarations

package abl.compiler;

public class ASTPropertyDeclaration extends AblParseNode {

    private String propertyName; // name of the property

    public ASTPropertyDeclaration(int id) {
	super(id);
    }
    
    public ASTPropertyDeclaration(AblParser p, int id) {
	super(p, id);
    }

    // Returns the property type (as a String)
    public String getPropertyType() { return ((AblParseNode)jjtGetChild(0)).dumpTokens(); }
	
    // public accessors for property name.
    public void setPropertyName(String propertyName) { this.propertyName = propertyName; }
    public String getPropertyName() { return propertyName; }
}
