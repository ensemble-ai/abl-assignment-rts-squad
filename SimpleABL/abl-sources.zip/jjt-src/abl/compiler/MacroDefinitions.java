/* Interface defining macro definitions used in compiler */

package abl.compiler;

public interface MacroDefinitions {
    String eol = System.getProperty("line.separator");
    
    String sensorActivationMacroString =
	"definemacro sensorActivation(sensorClassName)" +
	"new SensorActivation(new sensorClassName(), null)";

    String behaviorUnitBehaviorRegistrationMacroString = 
	"definemacro behaviorUnitBehaviorRegistration(signature, signatures, behaviorID, factory, precondition, preconditionSensorFactory, teamMembers, specificity, codeMethodName)" +
	"behaviorLibrary.registerBehavior(new __BehaviorDesc(behaviorID, factory, precondition, preconditionSensorFactory, \"signature\", signatures, teamMembers, (short)specificity), __$codeMethodName@_rfield);";

    String behaviorUnitBehaviorRegistrationCallMacroString = 
	"definemacro behaviorUnitBehaviorRegistrationCall(callCounter, behaviorLibrary)" + 
	"registerBehaviors_callCounter@(behaviorLibrary);";

    String behaviorUnitCodeMethodReflectionFieldNameMacroString =
	"definemacro behaviorUnitCodeMethodReflectionFieldName(codeMethodName)" +
	"__$codeMethodName@_rfield";

    String behaviorUnitInitCodeMethodReflectionFieldMacroString =
	"definemacro behaviorUnitInitCodeMethodReflectionField(methodFieldName, classFieldName, methodName, argArray)" +
	"methodFieldName = classFieldName.getDeclaredMethod(\"methodName\", argArray);";

    String behaviorUnitSetAssignableCodeMethodReflectionFieldMacroString =
	"definemacro behaviorUnitSetAssignableCodeMethodReflectionField(methodFieldName)" +
	"methodFieldName.setAccessible(true);";

    String behaviorUnitInitCodeClassReflectionFieldMacroString =
	"definemacro behaviorUnitInitCodeClassReflectionField(classFieldName, className, packageName)" +
	"classFieldName = Class.forName(\"packageName.className\");";

    String testExpressionSenseOneShotMacroString = 
	"definemacro testExpressionSenseOneShot(sensor)" +
	"sensor.getUniqueInstance().senseOneShot(null);";

    String wmeConstructorAssignmentMacroString = 
	"definemacro wmeConstructorAssignmentBlock(fieldName)" + 
	"this.fieldName = fieldName;";

    String wmeGetAccessorBodyMacroString = 
	"definemacro wmeGetAccessorBody(fieldName)" +
	"return fieldName;";

    String wmeSetAccessorBodyMacroString = 
	"definemacro wmeSetAccessorBody(fieldName)" +
	"this.fieldName = fieldName;";

    String wmeTestGetWMEListNoMemoryMacroString = 
	"definemacro wmeTestGetWMEListNoMemory(wmeCount, wmeClassName)" +
	"List wmeList@wmeCount;" + eol +
	"ListIterator wmeIter@wmeCount;" + eol +
	"wmeList@wmeCount = BehavingEntity.getBehavingEntity().lookupWME(\"wmeClassName\");" + eol + 
	"wmeIter@wmeCount = wmeList@wmeCount.listIterator();";

    String wmeTestGetWMEListMemoryMacroString =
	"definemacro wmeTestGetWMEListMemory(wmeCount, wmeClassName, memoryName)" +
	"List wmeList@wmeCount;" + eol +
	"ListIterator wmeIter@wmeCount;" + eol +
	"wmeList@wmeCount = WorkingMemory.lookupWME(\"memoryName\", \"wmeClassName\");" + eol +
	"wmeIter@wmeCount = wmeList@wmeCount.listIterator();";

    String wmeTestGetWMEListNoMemorySignatureOptMacroString = 
	"definemacro wmeTestGetWMEListNoMemorySigantureOpt(wmeCount, wmeClassName, signature)" +
	"List wmeList@wmeCount;" + eol +
	"ListIterator wmeIter@wmeCount;" + eol +
	"wmeList@wmeCount = BehavingEntity.getBehavingEntity().lookupReflectionWMEBySignature(\"wmeClassName\", signature);" + eol + 
	"wmeIter@wmeCount = wmeList@wmeCount.listIterator();";

    String wmeTestGetWMEListMemorySignatureOptMacroString =
	"definemacro wmeTestGetWMEListMemorySignatureOpt(wmeCount, wmeClassName, memoryName, signature)" +
	"List wmeList@wmeCount;" + eol +
	"ListIterator wmeIter@wmeCount;" + eol +
	"wmeList@wmeCount = WorkingMemory.lookupReflectionWMEBySignature(\"memoryName\", \"wmeClassName\", signature);" + eol +
	"wmeIter@wmeCount = wmeList@wmeCount.listIterator();";

    String wmeTestGetWMEListNoMemoryPropertyOptMacroString = 
	"definemacro wmeTestGetWMEListNoMemoryPropertyOpt(wmeCount, wmeClassName, propertyName)" +
	"List wmeList@wmeCount;" + eol +
	"ListIterator wmeIter@wmeCount;" + eol +
	"wmeList@wmeCount = BehavingEntity.getBehavingEntity().lookupReflectionWMEByUserProperty(\"wmeClassName\", \"propertyName\");" + eol + 
	"wmeIter@wmeCount = wmeList@wmeCount.listIterator();";

    String wmeTestGetWMEListMemoryPropertyOptMacroString =
	"definemacro wmeTestGetWMEListMemoryPropertyOpt(wmeCount, wmeClassName, memoryName, propertyName)" +
	"List wmeList@wmeCount;" + eol +
	"ListIterator wmeIter@wmeCount;" + eol +
	"wmeList@wmeCount = WorkingMemory.lookupReflectionWMEByUserProperty(\"memoryName\", \"wmeClassName\", \"propertyName\");" + eol +
	"wmeIter@wmeCount = wmeList@wmeCount.listIterator();";
	
    String wmeTestWhileRuleNegationMacroString = 
    "definemacro wmeTestWhileRuleNegation(wmeCount)" +
    "while(!__$negationFailed@wmeCount && wmeIter@wmeCount.hasNext()) {";
    
    String wmeTestWhileMacroString = 
	"definemacro wmeTestWhile(wmeCount)" +
	"while(wmeIter@wmeCount.hasNext()) {";

    String wmeTestWhileNextAssignMacroString = 
	"definemacro wmeTestWhileNext(wmeCount, wmeClassName, wmeAssignVar)" +
	"wmeClassName wme__@wmeCount = (wmeClassName)wmeIter@wmeCount.next();" + eol +
	"wmeAssignVar = wme__@wmeCount;";

    String wmeTestWhileNextNoAssignMacroString = 
	"definemacro wmeTestWhileNext(wmeCount, wmeClassName)" +
	"wmeClassName wme__@wmeCount = (wmeClassName)wmeIter@wmeCount.next();";
    
    /* Macros used by Rule ASTWMETests */
    
    String wmeTestGetWMEListMemSetArgRuleMacroString = 
   "definemacro wmeTestGetWMEListSearchMemRule(wmeCount, wmeClassName, memSetArg)" +
   "List<WMEIndex> wmeList@wmeCount;" + eol +
   "ListIterator<WMEIndex> wmeIter@wmeCount;" + eol +
   "wmeList@wmeCount = memSetArg.lookupWMEIndices(\"wmeClassName\");" + eol + 
   "wmeIter@wmeCount = wmeList@wmeCount.listIterator();";
    
    String wmeTestGetWMEListMemoryRuleMacroString =
   "definemacro wmeTestGetWMEListMemoryRule(wmeCount, wmeClassName, memoryName)" +
   "List<WMEIndex> wmeList@wmeCount;" + eol +
   "ListIterator<WMEIndex> wmeIter@wmeCount;" + eol +
   "wmeList@wmeCount = WorkingMemory.lookupWMEIndices(\"memoryName\", \"wmeClassName\");" + eol +
   "wmeIter@wmeCount = wmeList@wmeCount.listIterator();";
    
    String wmeTestGetWMEListMemSetArgSignatureOptRuleMacroString = 
   "definemacro wmeTestGetWMEListSearchMemSignatureOptRule(wmeCount, wmeClassName, memSetArg, signature)" +
   "List<WMEIndex> wmeList@wmeCount;" + eol +
   "ListIterator<WMEIndex> wmeIter@wmeCount;" + eol +
   "wmeList@wmeCount = memSetArg.lookupReflectionWMEBySignature(\"wmeClassName\", signature);" + eol + 
   "wmeIter@wmeCount = wmeList@wmeCount.listIterator();";
    
    String wmeTestGetWMEListMemorySignatureOptRuleMacroString =
   "definemacro wmeTestGetWMEListMemorySignatureOptRule(wmeCount, wmeClassName, memoryName, signature)" +
   "List<WMEIndex> wmeList@wmeCount;" + eol +
   "ListIterator<WMEIndex> wmeIter@wmeCount;" + eol +
   "wmeList@wmeCount = WorkingMemory.lookupReflectionWMEIndicesBySignature(\"memoryName\", \"wmeClassName\", signature);" + eol +
   "wmeIter@wmeCount = wmeList@wmeCount.listIterator();";
    
    String wmeTestGetWMEListMemSetArgPropertyOptRuleMacroString = 
   "definemacro wmeTestGetWMEListSearchMemPropertyOptRule(wmeCount, wmeClassName, memSetArg, propertyName)" +
   "List<WMEIndex> wmeList@wmeCount;" + eol +
   "ListIterator<WMEIndex> wmeIter@wmeCount;" + eol +
   "wmeList@wmeCount = memSetArg.lookupReflectionWMEByUserProperty(\"wmeClassName\", \"propertyName\");" + eol + 
   "wmeIter@wmeCount = wmeList@wmeCount.listIterator();";

    String wmeTestGetWMEListMemoryPropertyOptRuleMacroString =
   "definemacro wmeTestGetWMEListMemoryPropertyOptRule(wmeCount, wmeClassName, memoryName, propertyName)" +
   "List<WMEIndex> wmeList@wmeCount;" + eol +
   "ListIterator<WMEIndex> wmeIter@wmeCount;" + eol +
   "wmeList@wmeCount = WorkingMemory.lookupReflectionWMEIndicesByUserProperty(\"memoryName\", \"wmeClassName\", \"propertyName\");" + eol +
   "wmeIter@wmeCount = wmeList@wmeCount.listIterator();";
    
    String wmeTestWhileNextFromWMEIndexAssignRuleMacroString = 
   "definemacro wmeTestWhileNextFromWMEIndexRuleAssign(wmeCount, wmeClassName, wmeIndexVar, wmeAssignVar)" +
   "WMEIndex wmeIndexVar = wmeIter@wmeCount.next();" + eol +
   "wmeClassName wme__@wmeCount = (wmeClassName)wmeIndexVar.getWME();" + eol +
   "wmeAssignVar = wme__@wmeCount;";
    
    String wmeTestWhileNextFromWMEIndexNoAssignRuleMacroString = 
   "definemacro wmeTestWhileNextFromWMEIndexRuleNoAssign(wmeCount, wmeClassName)" +
   "wmeClassName wme__@wmeCount = (wmeClassName)wmeIter@wmeCount.next().getWME();";
    
    String modifiedMemCloneDeclarationMacroString = 
    "definemacro modifiedMemCloneDeclaration(wmeName)" +
         "WME @wmeName__$clone = null;";
    
    String modifiedMemCloneAssignmentMacroString = 
    "definemacro modifiedMemCloneDeclaration(wmeName, processedWmeVarRef)" +
    
         "@wmeName__$clone = @processedWmeVarRef.clone();";
    
    String modifiedMemCloneCheckMacroString = 
    "definemacro modifiedMemCloneCheck(wmeName, processedWmeVarRef, wmeIndex)" +
         "if (@wmeIndex.memContainsWME() && !@processedWmeVarRef.shallowEquals(@wmeName__$clone)) { " + eol +
            "__$modifiedMem.add(@wmeIndex);" + eol
            + "}";
    
    String ablEventSupportFieldInitializerMacroString = 
	"definemacro ablEventSupportFieldDef(classname)" +
	"_eventSupport = new AblEventSupport();" + eol +
	"try {" + eol +
	"    _eventSupport.setSource(Class.forName(\"classname\"));" + eol +
	"}" + eol +
	"catch (ClassNotFoundException e) { throw new RuntimeError(\"Reflection error initializing abl support \", e); }";
    
    // Rule Macros
    String wmeAssertCatchBlock = 
		"definemacro wmeAssertCatchBlock(exceptionType, wmeClassName)" +
		"catch (@exceptionType e) { throw new RuntimeError(\"Caught exception instantiating: @wmeClassName\", e); }";
}
	
