package abl.compiler;

public class ASTJavaType extends AblParseNode {
  public ASTJavaType(int id) {
    super(id);
  }

  public ASTJavaType(AblParser p, int id) {
    super(p, id);
  }

}
