/* Parse node for ABL conditional expressions
 * Syntax: if { <test> } <step>
 * OR
 *       if { <test> } [parallel] {
 *          <step>
 *          <step>
 *          ...
 *       }
 *       
 *       else <step>
 *   OR
 *       else [parallel] {
 *          <step>
 *          <step>
 *          ...
 *       }
 */
package abl.compiler;

import jd.CodeBlockDescriptor;
import jd.CodeSequenceDescriptor;
import jd.CodeStringDescriptor;
import abl.runtime.Step;

public class ASTConditionalStep
      extends GenericStep implements AblDebuggerConstants {

   private enum ConditionalBranchType {
      IF, ELSE
   }

   /*
    * Reflection field of conditional test sensor factory containing the case
    * for this step
    */
   private String conditionalTestSensorFactoryMethod_rField;
   /* Reflection field of conditional test containing the case for this step */
   private String conditionalTestMethod_rField;

   ASTTestExpression conditionalTest;
   boolean hasElse;
   String ifBehaviorType;
   String elseBehaviorType;

   public ASTConditionalStep(int id) {
      super(id);
      ifBehaviorType = elseBehaviorType = "sequential";
   }

   public ASTConditionalStep(AblParser p, int id) {
      super(p, id);
      ifBehaviorType = elseBehaviorType = "sequential";
   }

   /** Accept the visitor. **/
   public Object jjtAccept(AblParserVisitor visitor, Object data) {
      return visitor.visit(this, data);
   }

   private CodeBlockDescriptor compileStepFactory(String ifBehaviorSignature, String elseBehaviorSignature)
         throws CompileException {
      CodeBlockDescriptor stepFactory = new CodeBlockDescriptor("case " + stepID + ": {", "}");

      stepFactory.addToBlockBody(new CodeStringDescriptor("// " + getUniqueName()));

      final CodeSequenceDescriptor propertyTableInit = compilePropertyTable();
      if (propertyTableInit != null)
         stepFactory.addToBlockBody(propertyTableInit);

      StringBuffer factoryBuf = new StringBuffer(1024);
      factoryBuf.append("return ");

      if (Abl.debugLevel == GUI_DEBUGGER) {
         factoryBuf.append("new ConditionalStepDebug(");
      } else {
         factoryBuf.append("new ConditionalStep(");
      }
      factoryBuf.append(standardConstructorArguments() + ", " + getTestMethodsString() + ", " + ifBehaviorSignature + ", "
            + elseBehaviorSignature + ");");

      stepFactory.addToBlockBody(new CodeStringDescriptor(factoryBuf.toString()));

      return stepFactory;
   }

   private String getTestMethodsString() {
      String testString = getBehavingEntityField(conditionalTestMethod_rField);
      String testSensorFactoryString = null;
      if (conditionalTestSensorFactoryMethod_rField != null) {
         testSensorFactoryString = getBehavingEntityField(conditionalTestSensorFactoryMethod_rField);
      }
      return testString + ", " + testSensorFactoryString;
   }

   protected void compileConditionalTest()
         throws CompileException {
      conditionalTest.compileToJava();

      CodeBlockDescriptor conditionalTestSensorFactory = conditionalTest.compileSensorActivationFactory();

      if (conditionalTestSensorFactory != null) {
         CodeBlockDescriptor factorySwitchCase = new CodeBlockDescriptor("case " + stepID + ": {", "}");
         factorySwitchCase.addToBlockBody(conditionalTestSensorFactory);
         ASTBehaviorUnit.getBehaviorUnit().writeConditionalTestSensorActivation(factorySwitchCase, this);
      }
   }

   void compileToJava()
         throws CompileException {
      final ASTBehaviorUnit behaviorUnitNode = ASTBehaviorUnit.getBehaviorUnit();
      ASTBehaviorDefinition parentBehavior = (ASTBehaviorDefinition) jjtGetParent();

      initStep(Step.CONDITIONAL);

      compileConditionalTest();

      int firstIfStepChildIndex = getFirstIfStepChildIndex();
      int lastIfStepChildIndex = getLastIfStepChildIndex();

      // Compile and add the "if" branch
      String ifBehaviorSignature =
            addConditionalBranch(firstIfStepChildIndex, lastIfStepChildIndex, ConditionalBranchType.IF, parentBehavior);

      String elseBehaviorSignature = null;
      // If there is an else block, compile it and get the signature
      if (hasElse) {
         // The first else step will always be two after the last if. The one in between will be the else marker
         int firstElseStepChildIndex = lastIfStepChildIndex + 2;
         elseBehaviorSignature =
               addConditionalBranch(firstElseStepChildIndex, jjtGetNumChildren() - 1, ConditionalBranchType.ELSE, parentBehavior);
      }

      if (hasSuccessTest) {
         compileSuccessTest();
      }

      /*
       * Compile the step factory at the end since the factory references the
       * class and method names of the other step parts (e.g. success test,
       * sensor factories, execute).
       */
      behaviorUnitNode.writeStepFactory(compileStepFactory(ifBehaviorSignature, elseBehaviorSignature), this);

      // Add the step id and factory method to the parent's list of steps.
      parentBehavior.addStep(stepID, getStepFactoryMethod_rField());
   }

   /**
    * Find the index of the first if step, which will always be the next step
    * after the conditional test
    */
   private int getFirstIfStepChildIndex() {
      for (int i = 0; i < jjtGetNumChildren(); i++) {
         if (jjtGetChild(i).equals(conditionalTest)) {
            return i + 1;
         }
      }
      throw new CompileError("Conditional Test not found in child nodes");
   }
   
   /**
    * Find the index of the last if step
    * If there is no else portion, it's the last step of the block
    * Otherwise, it's the last step before the else marker
    */
   private int getLastIfStepChildIndex() {
      /* If there is no else block, the last if step child index is at the end of the node */
      if (!hasElse) {
         return jjtGetNumChildren() - 1;
      }
      
      /* Return 1 before the else marker */
      for (int i = 0; i < jjtGetNumChildren(); i++) {
         AblParseNode n = (AblParseNode) jjtGetChild(i);
         if (n.id == JJTCONDITIONALELSEMARKER) {
            return i - 1;
         }
      }
      throw new CompileError("Else marker not found in child nodes of conditional with else block");
   }
   

   private String addConditionalBranch(int firstStepIndex, int lastStepIndex, ConditionalBranchType branchType,
                                       ASTBehaviorDefinition parentBehavior) {
      /* create a new behavior to do the work for the conditional branch */
      ASTBehaviorDefinition branchBehavior = new ASTBehaviorDefinition(JJTBEHAVIORDEFINITION);
      /* Add the tokens, which are normally handled by AblParser */
      branchBehavior.firstToken = firstToken;
      branchBehavior.lastToken = lastToken;
      if (branchType.equals(ConditionalBranchType.IF))
         branchBehavior.setBehaviorType(ifBehaviorType);
      else {
         branchBehavior.setBehaviorType(elseBehaviorType);
      }
      // Must pass the scope through
      branchBehavior.isNestedScope = true;
      branchBehavior.jjtSetParent(parentBehavior);
      
      String stepNamesString = "";
      int behaviorChildIndex = 0;
      /* Add every node occurring within the branch behavior's bounds to the behavior */
      for (int i = firstStepIndex; i <= lastStepIndex; i++) {
         AblParseNode childToAdd = (AblParseNode) jjtGetChild(i);
         branchBehavior.jjtAddChild(childToAdd, behaviorChildIndex);
         behaviorChildIndex++;
         childToAdd.jjtSetParent(branchBehavior);
         /* If it's a compilable behavior step, add it to the descriptive name string */
         if(ASTBehaviorDefinition.isCompileableBehaviorStep(childToAdd)) {
            stepNamesString += "_" + childToAdd.toString();
         }
      }
      String branchBehaviorName =
            parentBehavior.behaviorName + "-" + parentBehavior.getBehaviorID() + "->ConditionalStep" + Integer.toString(stepID) + "_" + branchType + stepNamesString;
      branchBehavior.behaviorName = branchBehaviorName;

      // compile the branch behavior
      branchBehavior.compileToJava();

      /* Return the branch behavior signature for runtime behavior lookup */
      String branchBehaviorSignature = "\"" + branchBehaviorName + "()\"";
      return branchBehaviorSignature;
   }

   void setConditionalTestMethod_rField(String arg_conditionalTestMethod_rField) {
      if (conditionalTestMethod_rField != null)
         throw new CompileError("Attempt to set conditionalTestMethod_rField multiple times: " + arg_conditionalTestMethod_rField);

      conditionalTestMethod_rField = arg_conditionalTestMethod_rField;
   }

   void setConditionalTestSensorFactoryMethod_rField(String arg_conditionalTestSensorFactoryMethod_rField) {
      if (conditionalTestSensorFactoryMethod_rField != null)
         throw new CompileError("Attempt to set conditionalTestSensorFactoryMethod_rField multiple times: "
               + arg_conditionalTestSensorFactoryMethod_rField);

      conditionalTestSensorFactoryMethod_rField = arg_conditionalTestSensorFactoryMethod_rField;
   }

   void setConditionalTest(ASTTestExpression conditionalTest) {
      this.conditionalTest = conditionalTest;
   }

   void setHasElse(boolean hasElse) {
      this.hasElse = hasElse;
   }

   void setIfBehaviorType(String ifBehaviorType) {
      this.ifBehaviorType = ifBehaviorType;
   }

   void setElseBehaviorType(String elseBehaviorType) {
      this.elseBehaviorType = elseBehaviorType;
   }
}
/*
 * JavaCC - OriginalChecksum=4f08bfaf0cb94a0cbcbf3fb87a8bec86 (do not edit this
 * line)
 */
