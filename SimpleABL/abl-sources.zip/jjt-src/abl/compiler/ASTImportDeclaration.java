/* Parse node for import declarations. Defined to make use of dumpTokens(). */

package abl.compiler;

public class ASTImportDeclaration extends AblParseNode {
  public ASTImportDeclaration(int id) {
    super(id);
  }

  public ASTImportDeclaration(AblParser p, int id) {
    super(p, id);
  }

}
