/* Parse node for constant declarations. Defined to make use of dumpTokens(). */

package abl.compiler;

public class ASTConstantDeclaration extends AblParseNode {
  public ASTConstantDeclaration(int id) {
    super(id);
  }

  public ASTConstantDeclaration(AblParser p, int id) {
    super(p, id);
  }

}
