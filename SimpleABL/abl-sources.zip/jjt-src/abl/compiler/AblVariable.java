/**
 * Copyright 2014 UCSC
 */
package abl.compiler;

import jd.FieldDescriptor;

/**
 * For objects declarable as a variable
 */
public interface AblVariable {
      /**
       * @return the variable's name
       */
      public String getName();
      
      /**
       * @return the variable's declaration
       */
      public FieldDescriptor getVariableDeclaration();
      
      /**
       * @return the line number of the declaration
       */
      public int getDeclarationLineNumber();
}
