// fixme: eliminating the Comileable interface. There is no need for the compileToJava method to be public or
// for typing to be used. 

// CompileableToDescriptor objects must implement a transform which generates implementation code and returns it as a code descriptor. 

package abl.compiler;

import jd.JavaCodeDescriptor;

interface Compileable {
    JavaCodeDescriptor compileToJava() throws CompileException;
}


