/**
 * Copyright 2013 UCSC
 */
package test.testrunner;

import examples.Rules;

/**
 *
 */
public class RuleTestRunner {

   /**
    * @param args
    */
   public static void main(String[] args) {
      new Rules().startBehaving();
   }
}